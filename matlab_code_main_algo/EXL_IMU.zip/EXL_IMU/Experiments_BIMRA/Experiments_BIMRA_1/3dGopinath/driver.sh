if [[ $# -ne 1 ]]
then
echo "Usage: ./newget.sh INputFIleName pattern"
exit
fi


rm -rf "$1"'_dir'
mkdir "$1"'_dir'

for i in $(cat labels); do ./getAngles.sh "$1" $i; done
