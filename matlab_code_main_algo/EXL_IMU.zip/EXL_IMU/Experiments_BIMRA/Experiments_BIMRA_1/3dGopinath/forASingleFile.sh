if [[ $# -ne 1 ]]
then
echo "Usage: ./driver.sh INputFIleName"
exit
fi

echo "Make sure there is no space in the Filename"

rm -rf "$1"'_dir'
mkdir "$1"'_dir'

# Run this for the labels, passing filename and label as input
for i in $(cat labels); do ./getAngles.sh "$1" $i; done
