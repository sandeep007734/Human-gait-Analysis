#input is the filename and the label
#remove the echos to get the quiet mode

if [[ $# -ne 3 ]]
then
echo "Usage: ./getAngles.sh InputFileName pattern typeVar"
exit
fi

inpFile=$1
fileToSave=$(echo $2|sed 's/\"//g')
typeVar=$3

echo "Label:"
echo $fileToSave
echo $typeVar

if [ "$typeVar" = "0" ]
then
echo "Runnint type 0 Loop"
# This loop gets everything except the Heel Strike and Toe off for which we use the second loop (after this).
inp=$(awk -F "/>" '{print $2}' $inpFile )
a=1
while [[ -n "$inp" ]]
do
	# Get all the tags
   inp=$(awk -F "/>" '{print $'$a'}' $inpFile )
   # jrk data is present in different label tags
   jrk=$(echo $inp| grep "$2" | awk -F '<angle|<angle_band' '{print $2}' )
  
 
   if [[ -n $jrk ]]
   then
	echo $jrk
	for k in $(seq 1 16)
	do
		if [[ $k == 16 ]]
		then
			echo -e $jrk|awk -F '="|"' '{ print $'$k' }'|sed 's/[^-?[0-9] ]*//g'|sed "s/^[ \t]*//"|cut -d' ' -f2- >> $1'_dir/'$fileToSave'_data'
			echo -e $jrk|awk -F '="|"' '{ print $'$k' }'|sed 's/[^-?[0-9] ]*//g'|sed "s/^[ \t]*//" >> $1'_dir/'$2'_startTmp'
			awk '{print $1}' $1'_dir/'$2'_startTmp' >> $1'_dir/'$fileToSave'_start'
			rm $1'_dir/'$2'_startTmp'
		elif [[ $k == 14 ]]
		then
			echo -e $jrk|awk -F '="|"' '{ print $'$k' }'|sed "s/^[ \t]*//" >> $1'_dir/'$fileToSave'_scalefactor'
		else
			echo -e $jrk|awk -F '="|"' '{ print $'$k' }'|sed "s/^[ \t]*//" >> $1'_dir/'$fileToSave'_'
		fi
	done
	#echo $jrk > $2$a
   fi

   a=`expr $a + 1`
done

else
echo "Running Type 1 Loop"
# This part of the code take cares of the Heel Strike, Toe Off and the dseqStride in the data
inp=$(awk -F "/>" '{print $2}' $inpFile )
a=1
while [[ -n "$inp" ]]
do
   inp=$(awk -F "/>" '{print $'$a'}' $inpFile )
  jrk=$(echo $inp| grep "$2" | awk -F '<event|<track1d' '{print $2}' )



   if [[ -n $jrk ]]
   then
#	echo "$2:"
	echo $jrk
	for k in $(seq 1 16)
	do
		if [[ $k == 16 ]]
		then
			echo -e $jrk|awk -F '="|"' '{ print $'$k' }'|sed 's/[^-?[0-9] ]*//g'|sed "s/^[ \t]*//" >> $1'_dir/'$fileToSave'_data'
		elif [[ $k == 14 ]]
		then
			echo -e $jrk|awk -F '="|"' '{ print $'$k' }'|sed "s/^[ \t]*//" >> $1'_dir/'$fileToSave'_scalefactor'
		else
			echo -e $jrk|awk -F '="|"' '{ print $'$k' }'|sed "s/^[ \t]*//" >> $1'_dir/'$fileToSave'_'
		fi
	done
	#echo $jrk > $2$a
   fi

   a=`expr $a + 1`
done

fi
