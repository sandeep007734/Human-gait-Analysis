find -name "* *" -type f | rename 's/ /~/g'

for file in $(ls *Walking*.mdx)
do
echo $file
if [ -d "$file"'_dir' ]; then
echo "Dir present for "$file
else
mkdir "$file"'_dir'
fi

for i in $(cat labels);
do
	resFile=$(echo $file'_dir/'$i'_data'|sed 's/\"//g')
	if [  -f $resFile ];then
		echo "Result Present for: "$i
	else
		type=0;

		echo "Result Not Present for: "$i
		si=$(echo $i|sed 's/\"//g')
		if [ "$si" = "eRHS" ]; then
			type=1;
		fi
		if [ "$si" = "eRTO" ]; then
                        type=1;
                fi
		if [ "$si" = "dseqRSTRIDE" ]; then
                        type=1;
                fi

		echo "./getAngles.sh "$file" $i $type"
		./getAngles.sh "$file" $i $type

	fi
done

done
