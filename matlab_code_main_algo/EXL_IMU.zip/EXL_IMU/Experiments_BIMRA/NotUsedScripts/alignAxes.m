function [ nxa,nya,nza ] = alignAxes( j1_valf )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%% RUn

x_axis=[1;0;0];
y_axis=[0;1;0];
z_axis=[0;0;1];

nj=norm(j1_valf);

a=x_axis;
b=j1_valf/norm(j1_valf);

GG = @(A,B) [ dot(A,B) -norm(cross(A,B)) 0;
              norm(cross(A,B)) dot(A,B)  0;
              0              0           1];

FFi = @(A,B) [ A (B-dot(A,B)*A)/norm(B-dot(A,B)*A) cross(B,A) ];

UU = @(Fi,G) Fi*G*inv(Fi);

U = UU(FFi(a,b), GG(a,b));

nxa=U*x_axis;
nya=U*y_axis;
nza=U*z_axis;

end


