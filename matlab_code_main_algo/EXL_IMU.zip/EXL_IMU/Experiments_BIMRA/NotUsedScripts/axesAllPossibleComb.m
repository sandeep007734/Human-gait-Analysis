modMat = zeros(8,3);
for m =0:7
    temp = de2bi(m,'left-msb',3);
    %     temp
    temp(find(temp==1))=-1;
    temp(find(temp==0))=1;
    modMat((m+1),:) = temp;
end

% % fprintf('\n');
withModification=0;
rmse = verifyCalbration(j1_valf,j2_valf,gyro_s_first,gyro_s_second,withModification);

for r1=1:8
    for r2=1:8
        rmseCurr = verifyCalbration((j1_valf.*modMat(r1,:)'),...
            (j2_valf.*modMat(r2,:)'),...
            gyro_s_first,gyro_s_second,withModification);
        
        if(rmseCurr < rmse)
            a = j1_valf;
            b = j2_valf;
            angle = (atan2(norm(cross(a,b)), dot(a,b)));
            if(angle < 90)
                rmse = rmseCurr;
                j1_valf = (j1_valf.*modMat(r1,:)');
                j2_valf = (j2_valf.*modMat(r2,:)');
            end
        end
    end
end


fprintf('Minimum rmse: %f and angle: %f\n',rmse, rad2deg(angle));