function  [HSShank, TOShank] = calHSandTOShankOnline( inputData )
    %     disp('Custom Control on in onlineFindHSandTO');
    %     testData = gyro_s_ankle(1,startDataPoint:endDataPoint)';
    
    %% Run it
    showPlot=0;
    

    inputData = gyro_s_shank(1,rawPeakIdx:endDataPoint);
%     inputData(find(inputData>0))=0;
    showPlot=1;
    close all;

    fprintf('\nCalculating the HS and TO from the Shank data. Number of data samples: %d \n',max(size(inputData)));
    fprintf('The first 3 elements of the input data are: %f %f %f \n\n', inputData(1),inputData(2),inputData(3));
    
    freq=100;
    gyroT = 5;
    % Setting the positive peakHeight and peakDistance in th graph
    maxPeakHeight = gyroT;
    minPeakHeight = ceil(maxPeakHeight*0.2);
    minPeakDistnace = ceil(freq/5);
   
    sizeOfData = max(size(inputData));
    
    
    HSShank = [];
    TOShank = [];
    
    prev=[];
    for ti  = 1:sizeOfData
        curr = -inputData(ti);
        [isEvent, isHS, isTO ] = onlineFindHSandTOShank(curr,prev, minPeakHeight,minPeakDistnace,maxPeakHeight,ti);
        
        if(isEvent)
            if(isHS)
                if((max(size(HSShank))<3))
                    HSShank = [HSShank,ti-1];
                end
            elseif(isTO)
                if((max(size(TOShank))<2) && ~isempty(HSShank))
                    TOShank = [TOShank,ti-1];
                end
            end
        end
        
        if((max(size(HSShank))==3) &&(max(size(TOShank))==2))
            break;
        end
        
        prev = curr;
    end
    %             plot([(ti-1),(ti-1)],ylim,'color','red', 'LineWidth',1);
    
    
    
    if(showPlot)
        figure; hold on; grid on;
        plot(inputData,'linewidth',2,'color','black');
        
        for i=1:max(size(HSShank))
            nextMinIdx = HSShank(i);
            plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','blue','Marker', '.');
        end
        
        for i=1:max(size(TOShank))
            nextMinIdx = TOShank(i);
            plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','red','Marker', '.');
        end
        hold off;
        title('Shank Online Heel Strike (Blue) and Toe off (Red)')
        %         pause;
    end
end

