function [ output_args ] = calcProjetions( input_args )
    %UNTITLED Summary of this function goes here
    %   Detailed explanation goes here
    
    %% run it
    
    close all;
    clc;
    
    sensorData = gyro_s_thigh(1,:)';
    calibData = -1*j1_valf';
    
    fp = sensorData*calibData;
    sp = fp*(calibData)';
    tp = sensorData - sp;
    
    tpFirst = tp;
    
    figure;
    hold on; grid on;
    plot(tp,'linewidth',2,'color','r')
    
     sensorData = gyro_s_shank(1,:)';
    calibData = -1*j2_valf';
    
    fp = sensorData*calibData;
    sp = fp*calibData';
    tp = sensorData - sp;
    
      plot(tp,'linewidth',2,'color','b')
      
      hold off;
      
    tpSecond = tp;
    
    disp(sum(tpFirst));
    disp(sum(tpSecond));
    
    
    
end

