function [ o1_val,o2_val ] = calibPosVector( folder,calibrationFile, scale_factor,num_of_iterations,threshold,showDataGraphs,joint )
%% Run this
%Local Changes
if(1==2)
    folder='Experiments_BIMRA_2/Sofia7/';
    calibrationFile = ['S0_0013.txt';'S1_0013.txt'];
    scale_factor=1;
    num_of_iterations=50;
    threshold = 0.000001;
    close all;
    showDataGraphs=1;
end


% Exracting the name of the calibration file.
calibrationFile1 = strcat(folder,calibrationFile(1,:));
calibrationFile2 = strcat(folder,calibrationFile(2,:));

% Read data from calibration file into a structure.
disp(calibrationFile1);
data = importdata(char(calibrationFile1));
data2 = importdata(char(calibrationFile2));

% Reading the actual sensor data from the structure
tdata = data.data (1:end, :);
tdata2 = data2.data(1:end, :);

% Match the data so that the start and the end of two data matches.
[startIdx1,startIdx2,endIdx1,endIdx2] = matchData(tdata,tdata2);
data = data.data (startIdx1:endIdx1, :);
data2 = data2.data(startIdx2:endIdx2, :);

% Getting the size of the data
size_data = min(max(size(data)),max(size(data2)));

% Read the timestamp, accelerometer, gyrometer, time derivative gyro data
% and quaternion from the data.
[timestamp,acc_s_knee,gyro_s_knee,gyro_s_derv_knee,quarternion_knee] = loadData(data,size_data);
[timestamp,acc_s_shank,gyro_s_shank,gyro_s_derv_shank,quarternion_shank] = loadData(data2,size_data);

%%% Sampling of the data
gyro_s_knee = gyro_s_knee(:, 1:scale_factor:end);
gyro_s_shank = gyro_s_shank(:, 1:scale_factor:end);
acc_s_knee = acc_s_knee(:, 1:scale_factor:end);
acc_s_shank = acc_s_shank(:, 1:scale_factor:end);
gyro_s_derv_knee = gyro_s_derv_knee(:, 1:scale_factor:end);
gyro_s_derv_shank = gyro_s_derv_shank(:, 1:scale_factor:end);

% Prepare the variables for joint center axes Color Palette
cc=hsv(6);

%%%
% Intializing the symbols
% o1 is the joint center coordinates with respect to the sensor 1
% o2 is the joint center coordinates with respect to the sensor 2
syms o1x o1y o1z o2x o2y o2z;
%%%
% Gyroscope values in all the axes
syms g1x g1y g1z g2x g2y g2z;
%%%
% Gyroscope time derivative values in all the axes
syms gd1x gd1y gd1z gd2x gd2y gd2z;
%%%
% Accelerometer values in all the axes
syms a1x a1y a1z a2x a2y a2z;

%%%
% The Joint center coordinates
o1 = [o1x; o1y; o1z];
o2 = [o2x; o2y; o2z];

% The Gyro Values
g1 = [g1x; g1y; g1z];
g2 = [g2x; g2y; g2z];

% Time derivate Gyro Values
gd1 = [gd1x; gd1y; gd1z];
gd2 = [gd2x; gd2y; gd1z];

% The acceleration values
a1 = [a1x; a1y; a1z];
a2 = [a2x; a2y; a2z];


% Calculating the equation 8
rad_acc_1 = cross(g1, cross(g1,o1)) + cross(gd1, o1);
rad_acc_2 = cross(g2, cross(g2,o2)) + cross(gd2, o2);


% Calculating the Error
l1 = a1 - rad_acc_1;
l2 = a2 - rad_acc_2;

%Normalizing for all the axes
norm_l1 = sqrt( (l1(1,1)^2) + (l1(2,1)^2) + (l1(3,1)^2) );
norm_l2 = sqrt( (l2(1,1)^2) + (l2(2,1)^2) + (l2(3,1)^2) );

%Finale eror
e = norm_l1 - norm_l2;

%Same as before
jac_debydx = jacobian (e, [o1x o1y o1z o2x o2y o2z]);

% Initializing the variables
o1x_val = 1; o1y_val = 0.8; o1z_val = 1;
o2x_val = 1; o2y_val = 0.9; o2z_val = 0.5;

%%%
% _x_val_ will contains the value of the Joint center coordinates over loop iterations
% _e_val_ will contains the error This should decrease with each
% loop iterations
x_val = nan(6,num_of_iterations);
e_val = nan(size(gyro_s_knee,2), num_of_iterations);

x_val(:,1) = [o1x_val; o1y_val; o1z_val; o2x_val; o2y_val; o2z_val];

SSError = zeros(1,num_of_iterations);
SSError(1,1) = 0;
disp('Calculating Knee Joint Position Coordinate');


for k = 1 : num_of_iterations
    %     drawnow; pause(0.05);  % this innocent line prevents the Matlab hang
    Jac = nan(size(acc_s_knee,2),6);
    
    
    for i=1:size(acc_s_knee,2)
        a1_val = acc_s_knee(:,i);
        a2_val = acc_s_shank(:,i);
        
        g1_val = gyro_s_knee(:,i);
        g2_val = gyro_s_shank(:,i);
        
        gd1_val = gyro_s_derv_knee(:,i);
        gd2_val = gyro_s_derv_shank(:,i);
        
        Jac(i,:) = calib_calc_jac_debydx_posVec(x_val(1,k), x_val(2,k), x_val(3,k), g1_val(1), g1_val(2), g1_val(3), ...
            gd1_val(1), gd1_val(2), gd1_val(3),x_val(4,k), x_val(5,k), x_val(6,k), ...
            g2_val(1), g2_val(2), g2_val(3), gd2_val(1), gd2_val(2), gd2_val(3), a1_val(1), a1_val(2), a1_val(3), ...
            a2_val(1), a2_val(2), a2_val(3));
        %                 Jac(i,:) = subs(jac_debydx, [o1x, o1y, o1z, g1x, g1y, g1z, gd1x, gd1y, gd1z, o2x, o2y, o2z, ...
        %                     g2x, g2y, g2z, gd2x, gd2y, gd2z, a1x, a1y, a1z, a2x, a2y, a2z], ...
        %                     [x_val(1,k), x_val(2,k), x_val(3,k), g1_val(1), g1_val(2), g1_val(3), ...
        %                     gd1_val(1), gd1_val(2), gd1_val(3),x_val(4,k), x_val(5,k), x_val(6,k), ...
        %                     g2_val(1), g2_val(2), g2_val(3), gd2_val(1), gd2_val(2), gd2_val(3), a1_val(1), a1_val(2), a1_val(3), ...
        %                     a2_val(1), a2_val(2), a2_val(3)]);
        
        %                 Jac_T(:,i) = Jac(i,:)';
        e_val(i,k) = calib_calc_e_posVec(x_val(1,k), x_val(2,k), x_val(3,k), g1_val(1), g1_val(2), g1_val(3), ...
            gd1_val(1), gd1_val(2), gd1_val(3),x_val(4,k), x_val(5,k), x_val(6,k), ...
            g2_val(1), g2_val(2), g2_val(3), gd2_val(1), gd2_val(2), gd2_val(3), a1_val(1), a1_val(2), a1_val(3), ...
            a2_val(1), a2_val(2), a2_val(3));
        %                 e_val(i,k) = subs(e, [o1x, o1y, o1z, g1x, g1y, g1z, gd1x, gd1y, gd1z, o2x, o2y, o2z, ...
        %                     g2x, g2y, g2z, gd2x, gd2y, gd2z, a1x, a1y, a1z, a2x, a2y, a2z], ...
        %                     [x_val(1,k), x_val(2,k), x_val(3,k), g1_val(1), g1_val(2), g1_val(3), ...
        %                     gd1_val(1), gd1_val(2), gd1_val(3),x_val(4,k), x_val(5,k), x_val(6,k), ...
        %                     g2_val(1), g2_val(2), g2_val(3), gd2_val(1), gd2_val(2), gd2_val(3), a1_val(1), a1_val(2), a1_val(3), ...
        %                     a2_val(1), a2_val(2), a2_val(3)]);
        
        SSError(k) = SSError(k) + e_val(i,k)^2;
        
    end
    
    %             Jz = -Jac_T*Jac;
    %             g = Jz\Jac_T;
    %             x_val(:,k+1) = x_val(:,k)+g*e_val(:,k);
    
    % Matrix Inverse
    x_val(:,k+1) = x_val(:,k)-pinv(Jac)*e_val(:,k);
    
    if(k == 1)
        err(k) = SSError(k);
    else
        err(k) = SSError(k) - SSError(k-1);
        
        if(abs(abs(err(k))- abs(err(k-1))) < threshold)
            break;
            %         else
            %             fprintf('\nabs check %f %f\n', abs(err(k)),abs(err(k-1)));
        end
    end
    
    
    fprintf('KJCC. Iteration %d the diff is %f and SquareSumError is %f\n',k,err(k),SSError(k));
    
    if (abs(err(k)) <= threshold);
        break
    end
    
end
%%%
% Figure showing the conversion
if showDataGraphs == 1
    figure; grid;hold on;
    plot( x_val(1,1:k),'color',cc(1,:), 'LineWidth',2,'Marker', '*');
    plot( x_val(2,1:k),'color',cc(2,:), 'LineWidth',2,'Marker', '*');
    plot( x_val(3,1:k),'color',cc(3,:),'LineWidth',2,'Marker', '*');
    plot( x_val(4,1:k),'color',cc(4,:),'LineWidth',2,'Marker', '*');
    plot( x_val(5,1:k),'color',cc(5,:),'LineWidth',2,'Marker', '*');
    plot( x_val(6,1:k),'color',cc(6,:),'LineWidth',2,'Marker', '*');
    title(sprintf('Joint Position Vector for Joint: %s\n',joint),'fontsize',16);
    hold off;
end
%%%
% Getting the last values, where the equation converged
o1_val = x_val(1:3, k);
o2_val = x_val(4:6, k);

%%%
% Since the result of that optimization, denoted by o1^, o2^, refers to an arbitrary point along the
% joint axis, we shift it as close as possible to the sensors by applying:



end

