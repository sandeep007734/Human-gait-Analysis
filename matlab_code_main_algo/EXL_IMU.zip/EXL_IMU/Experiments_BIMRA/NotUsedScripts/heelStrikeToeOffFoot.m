function [heelStrike, toeOff] = heelStrikeToeOffFoot(angluralRateXComp)
    
    %% Run it
    
    showPlot=0;
    
%     disp('CUSTOM CODE CONTROL IS ON IN HEELSTRIKETOEOFFOOT');
%     angluralRateXComp = gyro_s_ankle(1,startDataPoint:endDataPoint);
%     showPlot=1;
%     
%     
    % Used during peak detection for the HS and TO
    % this is the most unstable part of the code. If there is somethng wrong
    % with the data, this will crash
    freq=100;
    gyroT = 5;
    
    try
        % Setting the positive peakHeight and peakDistance in th graph
        minPeakHeight = gyroT;
        minPeakDistnace = ceil(freq/7);
        
%         angluralRateXComp = gyro_s_ankle(1,startDataPoint:endDataPoint);
%         [posPeaks posPeaksIdx] = findpeaks(angluralRateXComp,'MinPeakHeight',minPeakHeight,'MinPeakDistance',minPeakDistnace);
        [posPeaks posPeaksIdx] = customFindPeaks(angluralRateXComp,minPeakHeight,minPeakDistnace);
       
        
        % Setting the negitive peakHeight and peakDistance in th graph
        minPeakHeight = ceil(gyroT*0.2);
        minPeakDistnace = ceil(freq/7);
        
%         [InvposPeaks InvposPeaksIdx] = findpeaks(-angluralRateXComp,'MinPeakHeight',minPeakHeight,'MinPeakDistance',minPeakDistnace);
            [InvposPeaks InvposPeaksIdx] = customFindPeaks(-angluralRateXComp,minPeakHeight,minPeakDistnace);
        heelStrikeAndToeOff = InvposPeaksIdx;
        
%         If there is peak in the front then this first is the heel strike
%         else it is a toe off. Most of the time the second case is valid.
        if(posPeaksIdx(1)<InvposPeaksIdx(1))
            heelStrike = heelStrikeAndToeOff(1:2:end);
            toeOff = heelStrikeAndToeOff(2:2:end);
        else
            heelStrike = heelStrikeAndToeOff(2:2:end);
            toeOff = heelStrikeAndToeOff(3:2:end);
        end
    catch ME
        disp('Error while finding HS and TO in Heel Strike and Toe Off algorithm detection from the foot.')
        heelStrike =-1;
        toeOff =-1;
        return;
    end
    
    
    
    %%% Plot
    if(  showPlot)
        figure; hold on; grid on;
        plot(angluralRateXComp,'linewidth',2,'color','black');
        
        for i=1:size(heelStrike,2)
            nextMinIdx = heelStrike(i);
            plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','blue','Marker', '.');
        end
        
        for i=1:size(toeOff,2)
            nextMinIdx = toeOff(i);
            plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','red','Marker', '.');
        end
        hold off;
        title('Heel Strike (Blue) and Toe off (Red)')
        %         pause;
    end
end







