%% Run this code
jdx = subs(jac_debydx, [phi1, theta1, phi2, theta2, g1x, g1y, g1z, g2x, g2y, g2z],[1, 2, 1, 2, 1, 2, 1, 2, 1, 3]);
eval(jdx)

jdxe = subs(e, [phi1, theta1, phi2, theta2, g1x, g1y, g1z, g2x, g2y, g2z],[1, 2, 3, 2, 1, 2, 1, 2, 1, 3]);
eval(jdxe)