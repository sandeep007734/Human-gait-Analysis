%% Introduction
% We compare the result calculated using the IMU data to the results
% calculated by the Optical System at BIMRA. We are currently focussing on
% Knee Flexion Extension, Ankle Flexion Extension, Heel Strike, Toe off and
% Distance travelled by the subject.

% Clear everythign from all the past runs and make sure that we are at the
% correct position.
clear all;
clear all;
clear all;

close all;

cd '/home/sandeep/IMU/EXL_IMU/Experiments_BIMRA';
addpath('/home/sandeep/IMU/EXL_IMU/Experiments_BIMRA/processMDXFiles');
addpath('/home/sandeep/IMU/EXL_IMU/Experiments_BIMRA/Utils');
addpath('/home/sandeep/IMU/EXL_IMU/Experiments_BIMRA/Scripts');

%% Intialize the Parameters and select the Experiment
% Here we define the values of the various tuning parameters which will be
% used during the evaluation of the results. Such as which experiment to
% run, whether to use all the walks or just one, location of the raw data
% etc.

experimentId = 4;       %1 for Prof Gopi, 2 for Sandeep, 3 for Litizia, 4 for Sopihia and so on
compareWithBimra = 0;
runCalibrationAnyWay=1;
useWalkasCalibration=1;
peakPresent=1;

calibrationType=1;      % There are more than one calibration file. Select the one which is to be selected. 1 for one plane, 2 for random

plotAll = 1;    % Plot al figures?
saveImagesToFile = 1;   % Whether to save the images to the file.

% Fine Control: which Plots to Plot

plotOptical = saveImagesToFile;
plotstartRawIdandEnd  = saveImagesToFile;
plotstartEndPointsFromKneeFE = saveImagesToFile;

plotacmRKFEandacRKFE = saveImagesToFile;

plotFinalRMSE = saveImagesToFile;
plotHS = saveImagesToFile;
plotTO =saveImagesToFile;

plotImuKnee =saveImagesToFile;
plotImuAnkle =saveImagesToFile;

plotAlignFigure = saveImagesToFile;

% TODO calculate the orientation of the Joint axis automatically
% Some manual changes to correct the direction of the axis of the axes
% obtained during the calibration process.
makeChanges = 1;

PELVIS=1;
KNEE=2;
ANKLE=3;

% Print extra message in the debug mode
global isDebug;
isDebug=0;

% This is set to 1 by checkMDX function, which is used to verify the MDX
% files.
checkMdx=0;

% This setting is related to phone app
% Retrieving the corresponding data file based on the setting.
isJson = 0;
expName = 'phoneData';

%% Start the Experiment

disp('Reading the IMU data files');

% Get the relvant files for the experiment
[folder,bimraFolder,bimraFiles,...
    rightKneeRawCalibFile,rightKneeProcessedCalibFile,...
    rightFootRawCalibFile,rightFootProcessedCalibFile,...
    rightThighDataFile,rightShankDataFile,rightFootDataFile]=...
    getDataFiles(experimentId,calibrationType,checkMdx,isJson,expName);

% [folder,bimraFolder,bimraFile,kneeRawCalib, kneeProcessedCalib,footRawCalib,footProcessedCalib,dataFileThigh,dataFileShank,dataFileFoot]

% Check whether we got the foot data. If not make sure that it is not used
% in the future calculations.
% Foot data will be present if we have placed a sensor on the foor during
% the experiments. Typically when 3 sensors are placed on one leg.
rightThighDataPresent=0;
rightShankDataPresent=0;
rightFootDataPresent=0;

if(~isempty(rightThighDataFile))
    rightThighDataPresent=1;
else
    disp('Right Thigh Data Present');
end
if(~isempty(rightShankDataFile))
    rightShankDataPresent=1;
    else
    disp('Right Shank Data Present');
end
if(~isempty(rightFootDataFile))
    rightFootDataPresent=1;
    else
    disp('Right Foot Data Present');
end

proceRightKneeJoint = 0;
processRightFootJoint = 0;

if(rightThighDataPresent && rightShankDataPresent)
    proceRightKneeJoint = 1;
end
if(rightFootDataPresent && rightShankDataPresent)
    processRightFootJoint = 1;
end

if(isempty(bimraFiles) || (compareWithBimra==0))
    dseqRSTRIDE=[];
end



%%

% Get the walking trials for this experiment.
% Number of experiment files present. (Walks done).
noOfWalkingTrials = size(rightThighDataFile,1);
% The experiment are capped at 11 walks. This can be changed depending upon
% the need.
maxTrialAllowed=11;
if noOfWalkingTrials > maxTrialAllowed
    noOfWalkingTrials = maxTrialAllowed;
end
fprintf('Number of Walking Trials %d\n',noOfWalkingTrials);

% Custom control. Set it to 1 to run only one walk. Set which walk to run
% inside the main loop custom control.

noOfWalkingTrials=1;

if(noOfWalkingTrials==1)
    
    plotstartEndPointsFromKneeFE = 0;
    plotOptical = 0;
    plotacmRKFEandacRKFE = 0;
    plotFinalRMSE = 0;
    plotHS = 0;
    plotTO=0;
    plotAlignFigure = 0;
    plotImuKnee =0;
    plotImuAnkle =0;
    plotstartRawIdandEnd=0;
end


if(plotAll)
    plotstartEndPointsFromKneeFE = 1;
    plotOptical = 1;
    plotacmRKFEandacRKFE = 1;
    plotFinalRMSE = 1;
    plotHS = 1;
    plotTO=1;
    plotAlignFigure = 1;
    plotImuKnee =1;
    plotImuAnkle =1;
    plotstartRawIdandEnd = 1;
end

%% Calculate the Gait Parameters

% Steps involved in the process:
for num = 1:noOfWalkingTrials
    % If maxItem is set to one then it will only run for one walk. The ID of the walk can be set here.;
    if(noOfWalkingTrials==1)
        disp('Running the code for a single walk. Debug Purpose')
        if(isJson==1)
            num=1;
        elseif(experimentId==4) % Sophia
            num=1;
        elseif(experimentId==3) % Letizia
            num=1;
        elseif(experimentId==1) % Gopinath Sir
            num=1;
        end
    end
    
    %This makes sure that the accessed file is within the limits.
    if(num > size(rightThighDataFile,1))
        disp('Accessing index more than files present');
        break;
    end
    % ===========================
    %%%
    % * Get the names of the raw data files which are to be processed in
    % this loop.
    rightThighFile = char(strcat(folder,rightThighDataFile(num,:)));
    rightShankFile = char(strcat(folder,rightShankDataFile(num,:)));
    if(rightFootDataPresent)
        rightAnkleFile = strcat(folder,rightFootDataFile(num,:));
    else
        rightAnkleFile=[];
    end
    if(isempty(bimraFiles)||(compareWithBimra==0))
        corresPondingBimraFile=[];
    else
        corresPondingBimraFile = strcat(bimraFolder,bimraFiles(num,:));
    end
    % ======================== CALIBRATION Starts============
    %% Calibration of the Sensors.
    % Calibration process basically gives us a rough estimate of the positon of
    % the sensors with respect to the joints, which will be used later in
    % determining the various Gait Parameters, such as Knee Flexion Extension,
    % Ankle Flexion Extension etc. This is the most costly step in the execution of the code, so make sure
    % to run it when this is absolutely necessary.
    
    % Check whether the calibration has been done before. If not do the calibration.
    %
    num_of_iterations =500;
    threshold = 0.00001;
    if(useWalkasCalibration)
        rightKneeRawCalibFile = [rightThighDataFile(num,:);rightShankDataFile(num,:)];
        rightFootRawCalibFile = [rightShankDataFile(num,:);rightFootDataFile(num,:)];
        disp('=======================Using walk as calibration=======================');
    end
    
    % Check if the calibration file exists.
    % If not then run the calibration code else just use the saved result.
    if (exist(rightKneeProcessedCalibFile, 'file') == 2 && (runCalibrationAnyWay==0))
        disp('Calibration File Found for Knee Joint');
    else
        disp('Doing Knee Calibration');
        joint = 'Knee';   % Unused for now, add _knee to save the calib result as j1_valf_knee
        doCalibration(folder,rightKneeRawCalibFile,rightKneeProcessedCalibFile,...
            num_of_iterations,threshold,joint);
        disp('Calibration Done');
    end
    load(rightKneeProcessedCalibFile);
    j1_valf_knee = j1_valf;
    j2_valf_knee = j2_valf;
    
    
    if(rightFootDataPresent)
        %    Check the calibration of the foot sensors
        if (exist(rightFootProcessedCalibFile, 'file') == 2 && (runCalibrationAnyWay==0))
            disp('Calibration File Found for Ankle Joint');
        else
            disp('Doing Ankle Calibration');
            joint = 'Ankle';   % Unused for now, add _knee to save the calib result as j1_valf_knee
            doCalibration(folder,rightFootRawCalibFile,rightFootProcessedCalibFile,num_of_iterations,threshold,joint);
            disp('Calibration Done');
        end
        load(rightFootProcessedCalibFile);
        j1_valf_foot = j1_valf;
        j2_valf_foot = j2_valf;
    end
    
    % ======================== CALIBRATION ENDS============
    
    
    % Display the filename, for the ease of the user.
    fprintf('Walk number: %d\n',num);
    fprintf('Running for the IMU file:\n %s \nand BIMRA file: %s\n',rightThighFile,corresPondingBimraFile);
    
    %%%
    % * Set the path to save the results and create the location if not
    % already present.
    
    pathToSave = strcat(folder,num2str(num),'_result/');
    disp(pathToSave);
    if(exist(pathToSave,'dir')== 0)
        mkdir(pathToSave);
    end
    
    %%
    % * Load the sensors data from the file.
    [ rightThighData, rightShankData, rightAnkleData, size_data ] = ...
        getDataFilesAndSize( rightThighFile, rightShankFile, rightAnkleFile,rightFootDataPresent );
    
    
    % Removal of two markers special case
    if(experimentId==4 && num==2) % Sophia
        rightThighData =   rightThighData(258:max(size(rightThighData)),:);
        rightShankData =   rightShankData(258:max(size(rightShankData)),:);
        rightAnkleData =   rightAnkleData(258:max(size(rightAnkleData)),:);
        size_data = size_data-258;
    end
    
    
    
    % Load the Thigh data from the Sensors
    [timestamp,acc_s_thigh,gyro_s_thigh,gyro_s_derv_thigh,quarternion_thigh] = loadData(rightThighData,max(size(rightThighData)));
    
    % Load the Shank data from the Sensors
    [timestamp,acc_s_shank,gyro_s_shank,gyro_s_derv_shank,quarternion_shank] = loadData(rightShankData,max(size(rightShankData)));
    
    % Load the Foot data from the Sensors
    [timestamp,acc_s_foot,gyro_s_foot,gyro_s_derv_foot,quarternion_foot] = loadData(rightAnkleData,max(size(rightAnkleData)));
    
    fprintf('Size of the data loaded: %d\n',max(max(size(acc_s_foot)),max(size(acc_s_shank))));
    
    %%
    % * Sampling of the data
    
    %Sampling rate 1 does nothng to the data.
    sample_rate = 1;
    fprintf('Sampling Rate: %d \n\n',sample_rate);
    
    if(sample_rate >1)
        [ gyro_s_thigh, gyro_s_shank,gyro_s_foot, gyro_s_derv_thigh,...
            gyro_s_derv_shank, gyro_s_derv_foot, acc_s_thigh, acc_s_shank,...
            acc_s_foot, timestamp ] ...
            = sampleData( gyro_s_thigh, gyro_s_shank,gyro_s_foot, gyro_s_derv_thigh,...
            gyro_s_derv_shank, gyro_s_derv_foot, acc_s_thigh, acc_s_shank, acc_s_foot, timestamp, sample_rate, rightFootDataPresent );
    end
    
    
    %%
    if(~isempty(bimraFiles) && compareWithBimra)
        % * Process the MDX file (Processed results from the Opticl system)
        % and get all the info needed from it.
        
        
        % JRK data is what is used by the BIMRA algorithms to calculate the
        % Knee flexion extension angle. The values along the z axis, is
        % used for this purpose.
        bimraFileName = bimraFiles(num,:);
        structMdxData = getMDXData(bimraFiles(num,:),bimraFolder);
        if(~isempty(structMdxData.jrkDataZ))
            validBimraData=1;
        else
            validBimraData=0;
        end
        fprintf('Optical Data summary:\n\n');
        disp(structMdxData);
        v2struct(structMdxData);
        
        if(plotOptical)
            bimradataFig = figure();
            grid on;
            hold on;
            plot( jrkDataZ,'color','black', 'LineWidth',2);
            legendstr='jrkDataZ';
            
            for i=1:size(HSOptical,2)
                plot([HSOptical(i),HSOptical(i)],ylim,'color','red', 'LineWidth',2);
                legendstr = char(legendstr,strcat('Heel Strike ',num2str(i)));
            end
            
            for i=1:size(TOOptical,2)
                plot([TOOptical(i),TOOptical(i)],ylim,'color','blue', 'LineWidth',2);
                legendstr = strvcat(legendstr,strcat('Toe Off ',num2str(i)));
            end
            
            
            if(isempty(opticalMarkerIdx))
                title(sprintf('jrkDataZ plot for BIMRA file name: %s\n Folder: %s\n Peak is missing in Optical data',...
                    bimraFiles(num,:),bimraFolder),'fontsize',16);
            else
                plot([opticalMarkerIdx,opticalMarkerIdx],ylim,'color','green', 'LineWidth',2);
                legendstr = strvcat(legendstr,strcat('Marker ',num2str(i)));
                title(sprintf('jrkDataZ plot for BIMRA file name: %s\n Folder: %s\n Peak is present in Optical data',...
                    bimraFiles(num,:),bimraFolder),'fontsize',16);
            end
            legend(legendstr,'Location','northeast');
            hold off;
            
            saveFigToFile(pathToSave,'bimradataFig', 'Optical Data',bimradataFig);
        end
    else
        compareWithBimra = 0;
        validBimraData=0;
        fprintf('Optical Data is missing for this particular experiment\n\n');
    end
    %%
    
    % HS and TO as it depends on the raw dat and not on anything else
    % Make sure the foot data is present.
    if(rightFootDataPresent && (compareWithBimra||peakPresent))
        
        % Detecting start and end point will not be required in the Final Implementation
        % These end points corresponds to the actual start of the walk, and
        % not the start of the recording of the data. If there is a peak
        % present in the data, then it provides the start point after it.
        
        %%
        % * Get Start, Peak and End point in the IMU Data.
        
        %         Make this independednt
        disp('Getting the Starting and Ending Point of the data automatically.')
        [ startDataPoint, endDataPoint,rawPeakIdx ] = findStartAndEndPoints(gyro_s_foot(1,:));
        %         [ mainStart, peakIdx, startDataPoint, endDataPoint ] = newfindStartAndEndPoints(gyro_s_foot(1,:));
        disp(fprintf('End points are as follow, start: %d, rawPeakIdx: %d end: %d',startDataPoint,rawPeakIdx,endDataPoint));
        
        if(plotstartRawIdandEnd)
            rawStartPeakEndFig=[];
            rawStartPeakEndFig = figure; grid on;hold on;
            plot( gyro_s_foot(1,:),'color','black', 'LineWidth',2);
            plot([startDataPoint,startDataPoint],ylim,'color','red', 'LineWidth',2);
            plot([rawPeakIdx,rawPeakIdx],ylim,'color','green', 'LineWidth',2);
            plot([endDataPoint,endDataPoint],ylim,'color','red', 'LineWidth',2);
            legend('Input Data','Start Point','Peak', 'End Point','Location','northeast');
            title(sprintf('Raw Idx\nStart, Peak and End Limit of the Data. File: %s', rightThighDataFile(num,:)),'FontSize',20);
            hold off;
            
            saveFigToFile(pathToSave,'rawStartPeakEndFig', 'RawStartPeakEnd',rawStartPeakEndFig);
        end
        %         startDataPoint = rawPeakIdx;
    else
        startDataPoint = 1;
        rawPeakIdx=1;
        endDataPoint = max(size(gyro_s_thigh));
    end
    %     rightShankDataPresent
    
    
    if(rightFootDataPresent)
        %%
        % * Get the Heel Strike and Toe Off from the Foot sensors.
        
        %         TODO Make this online.
        %         [HSFoot, TOFoot] = heelStrikeToeOffFoot(gyro_s_foot(1,startDataPoint:endDataPoint));
        [HSFoot, TOFoot] = calHSandTOFootOnline(gyro_s_foot(1,rawPeakIdx:endDataPoint));
        
        % If there was an erro during the calculation of the Heel Strike
        % and Toe off it is most likely that there was some problem with
        % thye data. The Knee Flexion Extension angle plot should look
        % normal for the data to be clean.
        
        if(isempty(HSFoot))
            disp('Error while getting HS and TO from the foot sensors');
            disp('Something wrong with the DATA. Plotting the Knee Flextion Angle as calculated by IMU sensors. This should look normal.');
            
            
        else
            % The calculates heel strike and toe off are wrt to data from
            % start point to end point. Need to add the startpoint to match
            % it to whole of the data.
            HSFoot = HSFoot+rawPeakIdx;
            TOFoot = TOFoot+rawPeakIdx;
            
        end
    else
        fprintf('Right Leg Foot data is missing. Cannot Calculat the Foot Heel Strike and Foot Toe Off\n\n');
        HSFoot=[];
        TOFoot=[];
        
    end
    %%
    if(rightShankDataPresent)
        %%%
        % * Get Strike and Toe Off from the Shank Sensors.
        
        % Calculate Heel Strike and Toe Off Data from the shank. The
        % values should be similar to what was caculated earlier using the
        % Foot sensor data.
        
        [HSShank, TOShank] = heelStrikeToeOffShank(gyro_s_shank(1,rawPeakIdx:endDataPoint));
        %         [HSShank, TOShank] = calHSandTOShankOnline(gyro_s_shank(1,rawPeakIdx:endDataPoint));
        if(isempty(HSShank))
            disp('Error while getting HS and TO from the shank sensors');
            disp('Something wrong with the DATA. Plotting the Knee Flextion Angle as calculated by IMU sensors. This should look normal.');
            plots = [0,0,0,1,0,0,1];
            %             plotGraphs(angle_FE,angle_FE2,angle_rot_mat,angle_joint_axes,angle_joint_centre,angle_FE3, plots,thighFile);
            plotGraphs(angle_rot_mat,imuRightKneeFE,angle_joint_centre_knee, plots,rightThighFile);
        else
            % The calculates heel strike and toe off are wrt to data from
            % start point to end point. Need to add the startpoint to match
            % it to whole of the data.
            HSShank = HSShank+rawPeakIdx;
            TOShank = TOShank+rawPeakIdx;
        end
    else
        disp('Right Leg Shank data is missing. Cannot Calculat the Shank Heel Strike and Shank Toe Off')
        HSShank=[];
        TOShank = [];
    end
    
    
    %%
    if(rightThighDataPresent && rightShankDataPresent)
        % * Calculating the Knee Flexion and Extension Angle Values from Joint Center and Joint Center axis
        forAnkle = 0;
        
        [angle_joint_centre_knee,imuRightKneeFE ] =  jointCenterAndAxes(gyro_s_thigh,gyro_s_derv_thigh,gyro_s_shank,...
            gyro_s_derv_shank,acc_s_thigh,acc_s_shank,makeChanges,rightKneeProcessedCalibFile,forAnkle);
        
        % Calculating the Knee Flexion Extension Angle Values from the Rotation Matrix
        [angle_rot_mat] = rotationMatrix(gyro_s_thigh,quarternion_thigh,quarternion_shank,makeChanges,rightKneeProcessedCalibFile);
        
        % Online angle_joint_axes calculation
        % TODO the error seesm to be higher in the online version. Please fix
        % it.
        if(false)
            imuRightKneeFE  = [];
            prevJointAxisAngle = 0;
            for i=2:size(gyro_s_thigh,2)
                forAnkle = 0;
                [ currJointAxisAngle ] = onlineJointCenterAndAxes( j1_valf_knee, j2_valf_knee,prevJointAxisAngle,...
                    gyro_s_thigh(:,i-1),gyro_s_shank(:,i-1),makeChanges,forAnkle );
                
                imuRightKneeFE = [imuRightKneeFE, currJointAxisAngle];
                prevJointAxisAngle = currJointAxisAngle;
                
            end
            imuRightKneeFE = imuRightKneeFE(2:end);
            endDataPoint = endDataPoint-2;
        end
        
        
        %%
        % * Find the Marker (Peak) in the data. (This will be different from
        % the early marked in the Raw data. We will used this marker to sync
        % the results from the two system.
        % MARKER is the peak in the graph of Knee Flextion and Extension
        % angle graph because of the leg raise action in the beginning of
        % the walk. This is captured by both, the IMU system and the
        % Optical system and can be used to synchronise the results from
        % both of them.
        
        %This will make the marker the starting point so that we can
        %compare it with the Optical system where the marker is shown at
        %the same place.
        if(compareWithBimra)
            peaksData = imuRightKneeFE(startDataPoint:endDataPoint);
            imuMarkerIdx = findIMUMarker( peaksData );
            imuMarkerIdx = imuMarkerIdx+startDataPoint;
        else
            imuMarkerIdx=1;
        end
        
        showPlot = 0;
        
    else
        imuRightKneeFE=[];
    end
    
    
    %%
    % * Calculate Ankle Dorsi Flexion Angle
    if(rightFootDataPresent && rightShankDataPresent)
        % Same for the foot
        forAnkle = 1;
        [angle_joint_centre_foot,imuRightAnkleFE ] =  jointCenterAndAxes(gyro_s_shank,gyro_s_derv_shank,gyro_s_foot,...
            gyro_s_derv_foot,acc_s_shank,acc_s_foot,makeChanges,rightFootProcessedCalibFile,forAnkle);
        
        if(isempty(imuRightAnkleFE))
            disp('THERE IS SOMETHING WRONG');
            return;
        end
        
        
        
        if(rightFootDataPresent)
            if(plotImuAnkle)
                imuAnkleFigure=figure; grid on;hold on;
                plot( imuRightAnkleFE,'color','black', 'LineWidth',2);
                title(sprintf('Ankle Flexion Extension. File: %s', rightThighDataFile(num,:)),'FontSize',20);
                hold off;
                saveFigToFile(pathToSave,'imuAnkleFigure', 'IMUAnkleFE',imuAnkleFigure);
            end
        end
    else
        disp('')
        imuRightAnkleFE = [];
    end
    
    % Plotting the starting and the end point which is calculated
    % automatically. TODO This is not full proof and the user check is
    % required whether the calculated start and end points are correct.
    if(plotstartEndPointsFromKneeFE)
        startEndPointsFromKneeFEFig = figure; grid on;hold on;
        plot( imuRightKneeFE,'color','black', 'LineWidth',2);
        plot([startDataPoint,startDataPoint],ylim,'color','red', 'LineWidth',2);
        plot([imuMarkerIdx,imuMarkerIdx],ylim,'color','green', 'LineWidth',2);
        plot([endDataPoint,endDataPoint],ylim,'color','red', 'LineWidth',2);
        legend('Input Data','Start Point','Peak', 'End Point','Location','northeast');
        title(sprintf('Knee FE\nStart, Peak and End Limit of the Data. File: %s', char(rightThighDataFile(num,:))),'FontSize',20);
        hold off;
        
        saveFigToFile(pathToSave,'startEndPointsFromKneeFEFig', 'PeakinRightKneeFE',startEndPointsFromKneeFEFig);
    end
    
    
    
    
    
    
    %%
    % * Realign all the results (Knee FE, Ankle FE, HS and TO) according to the marker detected.
    
    % Aligning the IMU data and the system data using the marker from
    % both of the systems. It just adds zero to the data where the
    % marker appears first.
    if(validBimraData && compareWithBimra)
        diffinData = abs(opticalMarkerIdx - imuMarkerIdx);
        zm = zeros(1,diffinData);
        if(imuMarkerIdx < opticalMarkerIdx)
            
            % adjust the heel strike and toe off values accordingly
            HSFoot = HSFoot+diffinData;
            TOFoot = TOFoot+diffinData;
            HSShank = HSShank+diffinData;
            TOShank = TOShank+diffinData;
            
            % The optical data has more points, so adjust the IMU data
            % accordingly.
            imuRightKneeFE = [zm , imuRightKneeFE];
            imuRightAnkleFE = [zm , imuRightAnkleFE];
            %             jrkDataZ = jrkDataZ;
            
            minSize = min(size(imuRightKneeFE,2),size(jrkDataZ,2));
            
            imuRightKneeFE = imuRightKneeFE(1:minSize);
            imuRightAnkleFE = imuRightAnkleFE(1:minSize);
            jrkDataZ = jrkDataZ(1:minSize);
        else
            %             The IMU data has more points, so adjust the optocal data
            %             accordingly.
            % add zeros to the Optical
            jrkDataZ = [zm, jrkDataZ];
            
            
            % adjust the heel strike and toe off values accordingly
            HSOptical = HSOptical + diffinData;
            TOOptical = TOOptical+diffinData;
        end
        
        if(plotAlignFigure && ~isempty(jrkDataZ) && ~isempty(imuRightKneeFE))
            alignFigure = figure();
            hold on; grid on;
            plot(jrkDataZ,'color','black', 'LineWidth',2);
            plot(imuRightKneeFE,'color','blue', 'LineWidth',2);
            legend('Optical Data','IMU Data','Location','northeast');
            title(sprintf('Optical and IMU Data Alignment.\n File: %s', rightThighDataFile(num,:)),'FontSize',20);
            hold off;
            saveFigToFile(pathToSave,'alignFigure', 'IMUOpticalDataAlign',alignFigure);
        end
        
    else
        % We cannot sync the data.
        disp('Cannot sync the data as there is some problem with the bimra data');
        imuRightKneeFE = imuRightKneeFE;
        imuRightAnkleFE = imuRightAnkleFE;
        minSize = max(size(imuRightKneeFE));
        
    end
    
    %     return;
    
    %%%
    % * Heel Strike and Toe off, Comparsion between IMU and Optical System
    if(validBimraData && compareWithBimra)
        isSynced = opticalMarkerIdx;
    else
        HSOptical=[];
        TOOptical=[];
        isSynced=[];
    end
    result = HSandTOSummary( HSFoot,TOFoot,HSShank,TOShank,HSOptical,TOOptical,isSynced, pathToSave);
    
    
    %%
    
    % Plot HS and TO
    % Plot the HS
    
    if(plotHS)
        heelStrikeFig = figure();
        hold on; grid on;
        plot( imuRightKneeFE(1,:),'color','black', 'LineWidth',2);
        if(rightFootDataPresent)
            
            if(size(HSFoot,1)>0)
                for hsfi = 1:size(HSFoot,2)
                    plot( [HSFoot(hsfi), HSFoot(hsfi)],ylim,'color','blue', 'LineWidth',2);
                end
            end
        end
        if(size(HSShank,1)>0)
            for hssi = 1:size(HSShank,2)
                plot( [HSShank(hssi), HSShank(hssi)],ylim,'color','Red', 'LineWidth',2);
            end
        end
        
        if(~isempty(HSOptical))
            for hsoi = 1:size(HSOptical,2)
                plot( [HSOptical(hsoi), HSOptical(hsoi)],ylim,'color','Green', 'LineWidth',2);
            end
        end
        title(sprintf('Heel Strike on Graphs. File: %s \n Foot:Blue Shank:Red Optical:Green',char(rightThighDataFile(num,:))),'fontsize',20);
        hold off;
        saveFigToFile(pathToSave,'heelStrike', 'Heel Strikes',heelStrikeFig);
        
    end
    
    if(plotTO)
        toeOffFig = figure();
        hold on; grid on;
        
        plot( imuRightKneeFE(1,:),'color','black', 'LineWidth',2);
        %             plot( angle_joint_axes_aligned,'color','blue', 'LineWidth',2);
        if(rightFootDataPresent)
            if(size(TOFoot,1)>0)
                for hsfi = 1:size(TOFoot,2)
                    plot( [TOFoot(hsfi), TOFoot(hsfi)],ylim,'color','blue', 'LineWidth',2);
                end
            end
        end
        
        if(size(TOShank,1)>0)
            for hssi = 1:size(TOShank,2)
                plot( [TOShank(hssi), TOShank(hssi)],ylim,'color','Red', 'LineWidth',2);
            end
        end
        
        if(~isempty(TOOptical))
            for hsoi = 1:size(TOOptical,2)
                plot( [TOOptical(hsoi), TOOptical(hsoi)],ylim,'color','Green', 'LineWidth',2);
            end
        end
        title(sprintf('Toe off on Graphs. File: %s \n Foot:Blue Shank:Red Optical:Green',char(rightThighDataFile(num,:))),'fontsize',20);
        hold off;
        saveFigToFile(pathToSave,'toeOffFig', 'Toe Offs in Data',toeOffFig);
        
        
    end
    
    
    %%
    % * Calculating the average IMU Step using the Heel Strike data
    % ca[tured using the IMU raw data.
    % TODO DECIDE WHICH TO USE BASED ON DIFFERENCE
    
    if(~isempty(HSFoot) && ~isempty(HSShank))
        if(mean(diff(HSFoot)) > mean(diff(HSShank)))
            [ avgKneeFEIMU ] = calcuateAverageIMUData( imuRightKneeFE, HSFoot );
            [ avgFootFEIMU ] = calcuateAverageIMUData( imuRightAnkleFE, HSFoot );
        else
            [ avgKneeFEIMU ] = calcuateAverageIMUData( imuRightKneeFE, HSShank );
            [ avgFootFEIMU ] = calcuateAverageIMUData( imuRightAnkleFE, HSShank );
        end
    else
        if(~isempty(HSFoot))
            [ avgKneeFEIMU ] = calcuateAverageIMUData( imuRightKneeFE, HSFoot );
            [ avgFootFEIMU ] = calcuateAverageIMUData( imuRightAnkleFE, HSFoot );
        elseif(~isempty(HSShank))
            [ avgKneeFEIMU ] = calcuateAverageIMUData( imuRightKneeFE, HSShank );
            [ avgFootFEIMU ] = calcuateAverageIMUData( imuRightAnkleFE, HSShank );
        else
            avgKneeFEIMU=[];
            avgFootFEIMU=[];
        end
    end
    
    if(compareWithBimra==0)
        structMdxData=[];
    end
    
    [ avgKneeAnglex,avgKneeAngley,avgKneeAnglez,avgacrkfe,avgacrkaa,avgacrkie ] = ...
        quaternionsAngles( quarternion_thigh,quarternion_shank,0,KNEE, HSFoot,HSShank,structMdxData );
    
    [ avgAnkleAnglex,avgAnkleAngley,avgAnkleAnglez,avgacrafe,avgacraaa,avgacraie ] = ...
        quaternionsAngles( quarternion_shank,quarternion_foot,0,ANKLE, HSFoot,HSShank,structMdxData );
    
    
    
    if(isempty(avgKneeFEIMU))
        disp('Error while getting Average Knee Flexion Extension Angle')
    end
    if(isempty(avgFootFEIMU))
        disp('Error while getting Average Foot Flexion Extension Angle')
    end
    
    avgKneeFEIMU = interpolateData(avgKneeFEIMU,101);
    avgFootFEIMU = interpolateData(avgFootFEIMU,101);
    
    if(isempty(bimraFiles) || (compareWithBimra==0))
        avgFEJrk=[];
        avgacrkfe = [];
        acmrkfe=[];
        avgarafe=[];
        avgacrafe=[];
        acmrafe = [];
    end
    
    %%
    % * Compare the results obtained from the IMU data to that of the
    % Optical system.
    if(plotFinalRMSE)
        %%%
        % Knee Result Summary
        avgIMUData = avgKneeFEIMU;
        avgBIMRArawData =avgFEJrk;
        avgacBIMRAData = avgacrkfe;
        acmBIMRAData = acmrkfe;
        [ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure ] =...
            showAndPlotFinalResult( avgIMUData, avgBIMRArawData, avgacBIMRAData, acmBIMRAData, ...
            num,bimraFiles,rightThighDataFile,'Right Knee Flexion Extension' );
        
        desc ='Knee';
        saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
        saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
        saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
        
        %%%
        % Foot result summary
        avgIMUData = avgFootFEIMU;
        avgBIMRArawData =avgarafe;
        avgacBIMRAData = avgacrafe;
        acmBIMRAData = acmrafe;
        [ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure ] = ...
            showAndPlotFinalResult( avgIMUData, avgBIMRArawData, avgacBIMRAData, acmBIMRAData, ...
            num,bimraFiles,rightThighDataFile,'Right Ankle Dorsi Flexion' );
        
        desc ='Foot';
        saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
        saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
        saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
        
        %         ===========================
        
        [ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure ] = ...
            showAndPlotFinalResult( avgKneeAnglex, avgacrkfe, [], [], ...
            num,bimraFiles,rightThighDataFile,'Q: Right Knee Flexion Extension' )
        desc ='QRKFE';
        saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
        saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
        saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
        
        [ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure ] = ...
            showAndPlotFinalResult( avgKneeAngley, avgacrkaa, [], [], ...
            num,bimraFiles,rightThighDataFile,'Q: Right Knee Abduction Adduction' )
        desc ='QRKAA';
        saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
        saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
        saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
        
        [ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure ] = ...
            showAndPlotFinalResult( avgKneeAnglez, avgacrkie, [], [], ...
            num,bimraFiles,rightThighDataFile,'Q: Right Knee Interior Exterior Rotation' )
        desc ='QRKIE';
        saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
        saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
        saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
        
        [ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure ] = ...
            showAndPlotFinalResult( avgAnkleAnglex, avgacrafe, [], [], ...
            num,bimraFiles,rightThighDataFile,'Q: Right Ankle Flexion Extension' )
        desc ='QRAFE';
        saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
        saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
        saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
        
        [ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure ] = ...
            showAndPlotFinalResult( avgAnkleAnglez, avgacraie, [], [], ...
            num,bimraFiles,rightThighDataFile,'Q: Right Ankle Interior Exterior Rotation' )
        desc ='QRAIE';
        saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
        saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
        saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
    end
    
    %%
    % * Calculate the Distance travelled.
    vel_n=[];
    pos_n=[];
    if(rightFootDataPresent)
        [ vel_n, pos_n ] = getDistance( gyro_s_foot(:,rawPeakIdx:end),acc_s_foot(:,rawPeakIdx:end) );
        HSData = HSFoot;
        
    end
    
    if(~isempty(vel_n))
        %     distanceFigure = figure();
        yAxisPos = pos_n(2,:);
        %     hold on; grid on;
        %     plot(yAxisPos,'color','black', 'LineWidth',2);
        heelStrikeLength = 0;
        imuStride = [];
        for hsfi = 2:size(HSData,2)
            %         fprintf('Right Stride Length (HS to HS): %f cm\n',(yAxisPos(HSFoot(hsfi))-yAxisPos(HSFoot(hsfi-1)))*100);
            distancediff = (yAxisPos(HSData(hsfi)-rawPeakIdx)-yAxisPos(HSData(hsfi-1)-rawPeakIdx));
            imuStride = [imuStride,distancediff];
            heelStrikeLength = heelStrikeLength+distancediff;
            
        end
        
        fprintf('Stride Compare (cm)\n\n')
        if(isempty(dseqRSTRIDE))
            dseqRSTRIDE = zeros(1,max(size(imuStride)));
        end
        imuStride =imuStride*100;
        dseqRSTRIDE = dseqRSTRIDE*100;
        rightStrideCompare = table(imuStride',dseqRSTRIDE',...
            'VariableNames',{'IMU_Stride_Right_Leg' 'Optical_Stride_Right_Leg' });
        
        strideError = abs(imuStride-dseqRSTRIDE);
        rightStrideCompareError = table(strideError',...
            'VariableNames',{'Stride_Error'});
        
        disp(rightStrideCompare);
        disp(rightStrideCompareError);
        
        writetable(rightStrideCompare,strcat(pathToSave,'Stride.txt'),'Delimiter',',');
        writetable(rightStrideCompareError,strcat(pathToSave,'StrideError.txt'),'Delimiter',',');
        
        sideWaysDistance = abs(pos_n(1,end));
        forwardDistance = abs(pos_n(2,end));
        elevationGained = abs(pos_n(3,end));
        
        fprintf('Distance Travelled (Total Data) (m)\n\n')
        distanceTavelled = table(forwardDistance',sideWaysDistance',elevationGained',...
            'VariableNames',{'Forward_Distance' 'Sideways_Distance' 'Elevaton_Gained' });
        distanceTavelled.Properties.VariableUnits = {'m' 'm'  'm'};
        writetable(distanceTavelled,strcat(pathToSave,'DistanceTravelled.txt'),'Delimiter',',');
        disp(distanceTavelled);
        
    end
    %%
    % * Save the results
    
    % Add the data files used here.
    fid = fopen(strcat(pathToSave,'dataFiles.txt'),'wt');
    fprintf(fid, strcat(corresPondingBimraFile,'\n'));
    fprintf(fid, strcat(rightThighFile,'\n'));
    fprintf(fid, strcat(rightShankFile,'\n'));
    if(rightFootDataPresent)
        fprintf(fid, rightAnkleFile);
    end
    fclose(fid);
    
    
    
end