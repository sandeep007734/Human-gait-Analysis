function [isEvent, isHSv, isTOv ] = onlineFindHSandTOShank(curr,prev, minPeakHeight,minPeakDistnace,maxPeakHeight,ti )
    
    %%
    global isIncreasing;
    global isNearby;
    global isHS;
    global isTO;
    global valsAllowed;
    global haveWeSeenaPeak;
    
    
    isEvent = 0;
    
    if(isempty(prev))
        isIncreasing=0;
        isNearby=0;
        isHS = 0;
        isTO = 0;
        valsAllowed = 0;
        haveWeSeenaPeak = 0;
        
        isHSv = isHS;
        isTOv = isTO;
        
        return;
    end
    
    
    if(isNearby > 0)
        isNearby = isNearby-1;
    end
    if(curr > prev)
        isIncreasing =1;
    end
    
    
    
    
    if(curr<prev && prev >= minPeakHeight && isIncreasing && (isNearby==0) &&(isHS || isTO))
        isIncreasing = 0;
        isNearby = minPeakDistnace;
        if(haveWeSeenaPeak)
            if(valsAllowed >0)
                isEvent = 1;
                
                if(isHS)
                    isTO=1;
                    isHS = 0;
                elseif(isTO)
                    isHS=1;
                    isTO=0;
                end
                
                isHSv = isHS;
                isTOv = isTO;
                valsAllowed = valsAllowed-1;
                return;
            else
                isEvent = 0;
                isHSv = 0;
                isTOv = 0;
                
                valsAllowed =2;
                return;
            end
        end
        
    end
    
      if(-prev < maxPeakHeight && (haveWeSeenaPeak==0))
%         fprintf('We just saw a peak at val %f\n',ti);
        haveWeSeenaPeak=1;
        
      end
    
    
    if(haveWeSeenaPeak)
        if(-curr > maxPeakHeight && isHS==0 && isTO==0)
            isTO = 1;
            valsAllowed = 1;
        end
    end
    
    isHSv = 0;
    isTOv = 0;
    
    
    
    
end

