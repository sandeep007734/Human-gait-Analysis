function [ currJointAxisAngle ] = onlineJointCenterAndAxes( j1_valf, j2_valf,prevJointAxisAngle,...
        gyro_s_thigh_val,gyro_s_shank_val,makeChanges ,forAnkle )

    %%
%     disp('Local Change Active in OnlineJointCenterAndAxes');
%     forAnkle=0;
%     makeChanges=1;
%     gyro_s_thigh_val = gyro_s_thigh(:,1);
%     gyro_s_shank_val = gyro_s_shank(:,1);
%     prevJointAxisAngle =10;
   
      if makeChanges ==1
        
        %                 j1_valf =[ -0.9427;       0.3061;     -0.1325];
        %                 j2_valf =    [ -0.8964;    0.1597 ;    0.4135];
        
        % Obtained from the Mesh Grids
        %         j1_valf = [ 0.9027; -0.3817; 0.1987];
        %         j2_valf = [ 0.9027; -0.1830 ;-0.3894];
        
%         Obtained from java code
%                 j1_valf = [ 0.8915101923504168, 0.011273280733363564, 0.4528603427954688];
%                 j2_valf = [0.8657219777129791, 0.4877391620711688, 0.11240981757320966];
                
        
        if(j1_valf(1)<0)
            j1_valf =  -j1_valf;
        end
        if(j2_valf(1)<0)
            j2_valf =  -j2_valf;
        end
%         
%         if(forAnkle)
%             j1_valf =  -j1_valf;
%             j2_valf =  -j2_valf;
%         end
        
      end
    
    currJointAxisAngle = prevJointAxisAngle + radtodeg((dot(gyro_s_thigh_val, j1_valf) - dot(gyro_s_shank_val, j2_valf)) * 0.01);
%     disp(gyro_s_thigh_val');
%     disp(gyro_s_shank_val');
%     disp(currJointAxisAngle);
    
end

