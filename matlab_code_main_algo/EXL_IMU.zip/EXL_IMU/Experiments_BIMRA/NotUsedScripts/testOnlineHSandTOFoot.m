    disp('Custom Control on in testonlineFindHSandTO');
    testData = gyro_s_ankle(1,startDataPoint:endDataPoint)';
    
    freq=100;
    gyroT = 5;
    % Setting the positive peakHeight and peakDistance in th graph
    maxPeakHeight = gyroT;
    minPeakHeight = ceil(maxPeakHeight*0.2);
    minPeakDistnace = ceil(freq/7);
    
    
    
    
    
    if(size(testData,2)>1)
        sizeOfData = size(testData,2);
    else
        sizeOfData = size(testData,1);
    end
    
%     %%% plot
%     %     end
    figure;
    hold on; grid on;
    plot(testData,'color','black', 'LineWidth',2);

    
    prev=[];
    for ti  = 1:sizeOfData
        curr = -testData(ti);
        [isEvent, isHS, isTO ] = onlineFindHSandTOFoot(curr,prev, minPeakHeight,minPeakDistnace,maxPeakHeight );
        
        if(isEvent)
            if(isHS)
                plot([ti,ti],ylim,'color','blue', 'LineWidth',2);
%                 HSFoot = [HSFoot,ti];
            elseif(isTO)
                plot([ti,ti],ylim,'color','red', 'LineWidth',2);
%                 TOFoot = [TOFoot,ti];
            end
        end
        
        prev = curr;
    end
    %             plot([(ti-1),(ti-1)],ylim,'color','red', 'LineWidth',1);
    
    
    
    hold off;
