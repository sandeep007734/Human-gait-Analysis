%%run this
a=-10;
b=10;
if(abs(a)==abs(b))
    c =1
else
    c=0
end