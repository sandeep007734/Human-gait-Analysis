%%
clear all;
load('Results/LetiziaHSTO.mat')

totHSShankOptical   = HSShankOptical;
totHSShankFoot      = HSShankFoot;
totHSFootOptical    = HSFootOptical;
totTOShankOptical   = TOShankOptical;
totTOShankFoot      = TOShankFoot;
totTOFootOptical    = TOFootOptical;

%%
load('Results/SophiaHSTO.mat')

totHSShankOptical   = [totHSShankOptical ; HSShankOptical];
totHSShankFoot      = [totHSShankFoot    ; HSShankFoot];
totHSFootOptical    = [totHSFootOptical  ; HSFootOptical];
totTOShankOptical   = [totTOShankOptical ; TOShankOptical];
totTOShankFoot      = [totTOShankFoot    ; TOShankFoot];
totTOFootOptical    = [totTOFootOptical  ; TOFootOptical];


%%
fprintf('HS Shank Optical: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(totHSShankOptical)), mean(totHSShankOptical),std(totHSShankOptical));
fprintf('HS Shank Foot: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(totHSShankFoot)), mean(totHSShankFoot),std(totHSShankFoot));
fprintf('HS Foot Optical: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(totHSFootOptical)), mean(totHSFootOptical),std(totHSFootOptical));

fprintf('TO Shank Optical: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(totTOShankOptical)), mean(totTOShankOptical),std(totTOShankOptical));
fprintf('TO Shank Foot: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(totTOShankFoot)), mean(totTOShankFoot),std(totTOShankFoot));
fprintf('TO Foot Optical: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(totTOFootOptical)), mean(totTOFootOptical),std(totTOFootOptical));

