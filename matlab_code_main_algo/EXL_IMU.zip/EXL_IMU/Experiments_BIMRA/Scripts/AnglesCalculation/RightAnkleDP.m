%%
%  Calculate Ankle Dorsi Flexion Angle
if(rightFootDataPresent && rightShankDataPresent)
    % Same for the foot
    forAnkle = 1;
    joinId = 3;

    shankAnglex = 2*acosd(quarternion_shank(2,1));
    footAnglex = 2*acosd(quarternion_foot(2,1));
    startAngle = 90-abs(shankAnglex-footAnglex);
   
    imuRightAnkleDP =  jointCenterAndAxes(gyro_s_shank,gyro_s_derv_shank,gyro_s_foot,...
        gyro_s_derv_foot,acc_s_shank,acc_s_foot,rightFootProcessedCalibFile,...
        forAnkle,joinId,startAngle,plotAxesChange);
   
else
    imuRightAnkleDP = [];
end