%%
%  Calculate Ankle Dorsi Flexion Angle
if(rightThighDataPresent && rightShankDataPresent)
    % Same for the foot
    forAnkle = 0;
    angleAxis = 'UNUSED';
    startAngle = 0;
    imuRightAnkleIE =  jointCenterAndAxesTop(gyro_s_shank,gyro_s_derv_shank,gyro_s_foot,...
        gyro_s_derv_foot,acc_s_shank,acc_s_foot,rightFootProcessedCalibFile,...
        forAnkle,angleAxis,startAngle,plotAxesChange);
    
    if(isempty(imuRightAnkleIE))
        disp('THERE IS SOMETHING WRONG');
        return;
    end
    
    %         if(plotImuAnkleFE)
    %             plotImuAnkleFECode();
    %         end
else
    imuRightAnkleIE = [];
end