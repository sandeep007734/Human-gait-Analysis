%%
if(rightThighDataPresent && rightShankDataPresent)
    % * Calculating the Knee Flexion and Extension Angle Values from Joint Center and Joint Center axis
    forAnkle = 0;
    joinId = 1;
    
    thighAnglex = 2*acosd(quarternion_thigh(2,1));
    shankAnglex = 2*acosd(quarternion_shank(2,1));
      startAngle = abs(shankAnglex-thighAnglex);    
    
    imuRightHipFE  =  jointCenterAndAxes(gyro_s_thigh,gyro_s_derv_thigh,gyro_s_shank,...
        gyro_s_derv_shank,acc_s_thigh,acc_s_shank,rightKneeProcessedCalibFile,...
        forAnkle,joinId,startAngle,plotAxesChange);
    
    % Calculating the Knee Flexion Extension Angle Values from the Rotation Matrix
    %         [angle_rot_mat] = rotationMatrix(gyro_s_thigh,quarternion_thigh,quarternion_shank,makeChanges,rightKneeProcessedCalibFile);
    
    % TODO onlineCode
    
else
    imuRightKneeFE=[];
end