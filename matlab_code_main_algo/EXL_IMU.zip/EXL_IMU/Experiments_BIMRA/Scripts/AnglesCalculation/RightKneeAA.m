%%
%  Calculate Ankle Dorsi Flexion Angle
if(rightThighDataPresent && rightShankDataPresent)
    % Same for the foot
    forAnkle = 0;
    isKnee = 1;
    startAngle = 0;
    imuRightKneeAA =  jointCenterAndAxesFrontal(gyro_s_thigh,gyro_s_derv_thigh,gyro_s_shank,...
        gyro_s_derv_shank,acc_s_thigh,acc_s_shank,rightKneeProcessedCalibFile,...
        forAnkle,isKnee,startAngle,plotAxesChange);
    
    if(isempty(imuRightKneeAA))
        disp('THERE IS SOMETHING WRONG');
        return;
    end
    
    %         if(plotImuAnkleFE)
    %             plotImuAnkleFECode();
    %         end
else
    imuRightKneeAA = [];
end