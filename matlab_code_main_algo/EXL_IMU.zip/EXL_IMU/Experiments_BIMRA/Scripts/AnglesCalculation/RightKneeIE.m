%%
%  Calculate Ankle Dorsi Flexion Angle
if(rightThighDataPresent && rightShankDataPresent)
    % Same for the foot
    forAnkle = 0;
    angleAxis = 1;
    startAngle = 0;
    imuRightKneeIE =  jointCenterAndAxesTop(gyro_s_thigh,gyro_s_derv_thigh,gyro_s_shank,...
        gyro_s_derv_shank,acc_s_thigh,acc_s_shank,rightKneeProcessedCalibFile,...
        forAnkle,angleAxis,startAngle,plotAxesChange);
    
    if(isempty(imuRightKneeIE))
        disp('THERE IS SOMETHING WRONG');
        return;
    end
    
    %         if(plotImuAnkleFE)
    %             plotImuAnkleFECode();
    %         end
else
    imuRightKneeIE = [];
end