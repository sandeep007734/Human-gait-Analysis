    if(rightFootDataPresent)

%          [HSFoot, TOFoot] = heelStrikeToeOffFoot(gyro_s_foot(1,rawPeakIdx:endDataPoint));
        [HSFoot, TOFoot] = calHSandTOFootOnline(gyro_s_foot(1,rawPeakIdx:endDataPoint));
        
        if(isempty(HSFoot))
            disp('Error while getting HS and TO from the foot sensors');
            disp('Something wrong with the DATA. Plotting the Knee Flextion Angle as calculated by IMU sensors. This should look normal.');   
        else
            % The calculates heel strike and toe off are wrt to data from
            % start point to end point. Need to add the startpoint to match
            % it to whole of the data.
            HSFoot = HSFoot+rawPeakIdx;
            TOFoot = TOFoot+rawPeakIdx;
            
        end
    else
        fprintf('Right Leg Foot data is missing. Cannot Calculat the Foot Heel Strike and Foot Toe Off\n\n');
        HSFoot=[];
        TOFoot=[];
        
    end