    %%
    if(rightShankDataPresent)
        % Calculate Heel Strike and Toe Off Data from the shank. The
        % values should be similar to what was caculated earlier using the
        % Foot sensor data.
        
        [HSShank, TOShank] = heelStrikeToeOffShank(gyro_s_shank(1,rawPeakIdx:endDataPoint));
        %         [HSShank, TOShank] = calHSandTOShankOnline(gyro_s_shank(1,rawPeakIdx:endDataPoint));
        if(isempty(HSShank))
            disp('Error while getting HS and TO from the shank sensors');
            disp('Something wrong with the DATA. Plotting the Knee Flextion Angle as calculated by IMU sensors. This should look normal.');
%             plots = [0,0,0,1,0,0,1];
%             plotGraphs(angle_rot_mat,imuRightKneeFE,angle_joint_centre_knee, plots,rightThighFile);
        else
            % The calculates heel strike and toe off are wrt to data from
            % start point to end point. Need to add the startpoint to match
            % it to whole of the data.
            HSShank = HSShank+rawPeakIdx;
            TOShank = TOShank+rawPeakIdx;
        end
    else
        disp('Right Leg Shank data is missing. Cannot Calculat the Shank Heel Strike and Shank Toe Off')
        HSShank=[];
        TOShank = [];
    end