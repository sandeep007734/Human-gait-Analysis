function [angle_joint_axes, angle_joint_centre ] =  jointCenterAndAxesFrontal(gyro_s_first,gyro_s_derv_first,gyro_s_second,...
    gyro_s_derv_second,acc_s_first,acc_s_second,calibrationDataFile,forAnkle,axis,startAngle,plotAxesChange)

if(isempty(calibrationDataFile))
    
    angle_joint_centre=[];
    angle_joint_axes=[];
    return;
end

%% Calculating the Angle Values from Joint Center and Joint Center axis


% Read the Joint center axis and the joint center form the calibration
% results file
if (exist(calibrationDataFile, 'file') == 2)
    load(char(calibrationDataFile));
else
    disp('Calibration File not found. Cannot calculate the angles.');
    angle_joint_centre = [];
    angle_joint_axes = [];
    return;
end


j1_valf = j1_valf_x;
j2_valf = j2_valf_x;


%%%
% When the Joint center axes are calculated by the algorithm mentioned in
% the CalirabtionFile, then it gives two axis, one each with respect to the
% sensors placed.
%
% Now it does not say anything about the direction of the axes. There are
% four posibilities, taking into consideration the positive and the negative
% direction of both of the axes.
%
% We are adjusting this manually at the runtime, (by looking at the graphs).


[j1_valf, j2_valf] = modifyCalibVector(j1_valf,j2_valf,forAnkle);
[ j1_valf_y, j1_valf_z] = getNewAxises(j1_valf);
[ j2_valf_y, j2_valf_z] = getNewAxises(j2_valf);

if(plotAxesChange)
    h= figure();
    drawVector([j1_valf_y,j2_valf_y],{'a','b'});
    hold on;
    if(forAnkle)
        title('Ankle');
    else
        title('Knee Frontal Plane');
    end
    %     legend('Original','','Modified','');
    hold off;
end
drawnow;
% pause();
% return;

angle_joint_axes = zeros(1,min(max(size(gyro_s_first)),max(size(gyro_s_second))));

% TODO Manual starting. Remove this
angle_joint_axes(1) = startAngle ; %acosd(CosTheta);
% j1_valf_z = -j1_valf_z;
% j2_valf_z
dataPoints = min(max(size(gyro_s_first)),max(size(gyro_s_second)));
for i=2:dataPoints
    angle_joint_axes (i) = angle_joint_axes (i-1) +...
        radtodeg(...
        (dot(gyro_s_first(:,i-1), j1_valf_z) -...
        dot(gyro_s_second(:,i-1), j2_valf_z))...
        * 0.01);
    % .001 is because we ae recording data at 100Hz. This should ideally me multiplied ...
    % sampling factor, but as that is also 1 it will not matter.
    
%               angle_joint_axes (i) = angle_joint_axes (i-1) +...
%                 radtodeg(...
%                 (dot(gyro_s_first(:,i-1), j1_valf_y))...
%                 * 0.01);
    
%         angle_joint_axes (i) = angle_joint_axes (i-1) +...
%             radtodeg(...
%             (dot(gyro_s_second(:,i-1), j2_valf_y))...
%             * 0.01);
end

angle_joint_centre=[];


