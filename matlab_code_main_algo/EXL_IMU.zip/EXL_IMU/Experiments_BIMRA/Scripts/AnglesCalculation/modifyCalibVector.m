function [j1_valf, j2_valf] = modifyCalibVector(j1_valf,j2_valf,forAnkle)
%%
if(forAnkle)
    if(j1_valf(1)>0)
        j1_valf = -1*j1_valf;
    end
    
    if(j2_valf(1)>0)
        j2_valf =  -1*j2_valf;
    end
    
        if(j1_valf(1)>0)
            j1_valf(1) =  -j1_valf(1);
        end
        if(j1_valf(2)<0)
            j1_valf(2) =  -j1_valf(2);
        end
        if(j1_valf(3)>0)
            j1_valf(3) =  -j1_valf(3);
        end
    
    
        if(j2_valf(1)>0)
            j2_valf(1) =  -j2_valf(1);
        end
        if(j2_valf(2)<0)
            j2_valf(2) =  -j2_valf(2);
        end
        if(j2_valf(3)>0)
            j2_valf(3) =  -j2_valf(3);
        end
else
%     if(j1_valf(1)<0)
%         j1_valf = -1*j1_valf;
%     end
%     
%     if(j2_valf(1)<0)
%         j2_valf =  -1*j2_valf;
%     end
        if(j1_valf(1)<0)
            j1_valf(1) =  -j1_valf(1);
        end
        if(j1_valf(2)<0)
            j1_valf(2) =  -j1_valf(2);
        end
        if(j1_valf(3)>0)
            j1_valf(3) =  -j1_valf(3);
        end
    
    
        if(j2_valf(1)<0)
            j2_valf(1) =  -j2_valf(1);
        end
        if(j2_valf(2)>0)
            j2_valf(2) =  -j2_valf(2);
        end
        if(j2_valf(3)>0)
            j2_valf(3) =  -j2_valf(3);
        end
end
end