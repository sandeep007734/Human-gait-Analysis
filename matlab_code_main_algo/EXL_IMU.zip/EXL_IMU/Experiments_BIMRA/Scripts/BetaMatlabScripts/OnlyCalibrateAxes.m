%function [j1_valf, j2_valf] = doCalibration(folder,calibrationFile, calibrationDataFile)
%% Load data
% 
calibrationDataFile = 'Gopinath/calibration_onlyCalibrateAxes.mat';
calibrationFile = ['S0_0008.txt';'S1_0008.txt'];
folder = 'Gopinath/';

% if exist(calibrationDataFile, 'file') == 2
%     delete(calibrationDataFile);
% end

if exist(calibrationDataFile, 'file') == 2
    disp('Calibration File Found');
    load(calibrationDataFile);
else
    disp('Doing Calibration');
    disp('Loading the data');
    
    num_of_iterations = 50;
    threshold = .0001;
    sample_rate=10;
    
    
    %%%
    % Preparing the variables, which will be used in the calculation
    
    %%%
    % Exracting the name of the calibration file.
    calibrationFile1 = strcat(folder,calibrationFile(1,:));
    calibrationFile2 = strcat(folder,calibrationFile(2,:));
    
    %%%
    % Close any open plots. If _showDataGraphs_ is set to 1, then relevant
    % plots will be plotted during execution.
    % 
    showDataGraphs = 1;
    
    %%%
    % Read data from calibration file into a structure.
    data = importdata(calibrationFile1);
    data2 = importdata(calibrationFile2);
    
    %%%
    % Reading the actual sensor data from the structure
    tdata = data.data (1:end, :);
    tdata2 = data2.data(1:end, :);
    
    %%%
    % Some residue data points from previous trails may creep into this one. We
    % need to clear it. Mostly in the beginning and then match the data, so
    % that the data from two sensors synchronize properly based on theire
    % timestamp data.
    % Match the data so that the start and the end of two data matches.
    [startIdx1,startIdx2,endIdx1,endIdx2] = matchData(tdata,tdata2);
    data = data.data (startIdx1:endIdx1, :);
    data2 = data2.data(startIdx2:endIdx2, :);
    
    %%%
    % Getting the size of the data
    size_data = size(data,1);
    
    
    %%%
    % Read the timestamp, accelerometer, gyrometer, time derivative gyro data
    % and quaternion from the data.
    % Quaternions provide a convenient mathematical notation for represneting
    % orientations and rotations of objects in three dimensions.
    % Compared to Euler angles they are simpler to compose and avoid the problem of gimbal lock.
    % Compared to rotation matrices they are more numerically stable and may be more efficient.
    % A gyroscope is a device that uses Earth’s gravity to help determine orientation.
    % measure the rate of rotation around a particular axis
    
    [timestamp,acc_s_knee,gyro_s_knee,gyro_s_derv_knee,quarternion_knee] = loadData(data,size_data);
    [timestamp,acc_s_shank,gyro_s_shank,gyro_s_derv_shank,quarternion_shank] = loadData(data2,size_data);
    
    %%% Sampling of the data
    % sample_rate is the sampling frequency. Here we are taking 10 samples per second for
    % the calculation
    
    gyro_s_knee = gyro_s_knee(:, 1:sample_rate:end);
    gyro_s_shank = gyro_s_shank(:, 1:sample_rate:end);
    gyro_s_derv_knee = gyro_s_derv_knee(:, 1:sample_rate:end);
    gyro_s_derv_shank = gyro_s_derv_shank(:, 1:sample_rate:end);
    acc_s_knee = acc_s_knee(:, 1:sample_rate:end);
    acc_s_shank = acc_s_shank(:, 1:sample_rate:end);
    timestamp=timestamp(1:sample_rate:end);
    
    %% Data Analysis
    
    norm_gyro_s_knee = zeros(1,size(gyro_s_knee,2));
    for i=1:size(gyro_s_knee,2)
        norm_gyro_s_knee(1,i) = norm(gyro_s_knee(:,i));
    end
    
    norm_gyro_s_shank = zeros(1,size(gyro_s_shank,2));
    for i=1:size(gyro_s_shank,2)
        norm_gyro_s_shank(1,i) = norm(gyro_s_shank(:,i));
    end
    
    % 
    figure;
    hold on; grid on;
    plot(radtodeg(norm_gyro_s_knee),'color','Black', 'LineWidth',2,'Marker', '*');
    plot(radtodeg(norm_gyro_s_shank),'color','Blue', 'LineWidth',2,'Marker', '*');
    ylabel('Angle');
    xlabel('TimeStamp');
    legend('Thigh Angular Velocity','Shank Angular Velocity','Location','northeast');
    hold off;
    
    %% Doing the calculation for the Joint axes.
    %%%
    % Prepare the variables for joint center axes
    % Color Palette
    cc=hsv(6);
    %%%
    % Arguments for which the funcions need to be minimized. Ψ(φ1,φ2, θ1, θ2)
    syms phi1 theta1 phi2 theta2;
    
    %%%
    % The spherical coordinates representation of the j1 and j2
    j1 = [cos(phi1)*cos(theta1); cos(phi1)*sin(theta1); sin(phi1)];
    j2 = [cos(phi2)*cos(theta2); cos(phi2)*sin(theta2); sin(phi2)];
    
    %%%
    % The angluar velocity split into its x,y and z coordinates
    syms g1x g1y g1z g2x g2y g2z;
    g1 = [g1x; g1y; g1z];
    g2 = [g2x; g2y; g2z];
    
    %%%
    % l1 and l2 is the projection of angular velocities of the respective
    % sensors, in the joint place (The plane to which the joint center axes is
    % normal). Kinematics constraints say that both of this should be equal (in
    % magnitude). Direction will differ.
    % l1 and l2 whose difference sqaure is summed up in the equation 6
    % ei = ||g1(ti)×j1||2 −||g2(ti)×j2||2
    % on right side the first term is e1 and the second one is e2
    
    l1 = cross(g1, j1);
    l2 = cross(g2, j2);
    %%%
    % Normalizing over the all the axes.
    norm_l1 = sqrt( (l1(1,1)^2) + (l1(2,1)^2) + (l1(3,1)^2) );
    norm_l2 = sqrt( (l2(1,1)^2) + (l2(2,1)^2) + (l2(3,1)^2) );
    %%%
    % There difference finally gives the e
    e = norm_l1 - norm_l2;
    
    %%%
    % jacobian(f,v) computes the Jacobian Matrix of f with respect to v.
    % The (i,j) element of the result is
    % ∂f(i)
    % _____
    % ∂v(j)
    %
    % syms x y z
    % jacobian([x*y*z, y^2, x + z], [x, y, z])
    % ans =
    % [ y*z, x*z, x*y]
    % [   0, 2*y,   0]
    % [   1,   0,   1]
    
    
    %%%
    % Calculating the Jacobain using the e and the arguements
    jac_debydx = jacobian (e, [phi1 theta1 phi2 theta2]);
    
    
    %% Running the loop for the Joint center axes
    % Setting up the intial value of the variable Joint center axes
    phi1_val = pi/6; theta1_val = pi/3;
    phi2_val = pi/3; theta2_val = pi/6;
    
    %%%
    % In reality the difference never goes to zero because of the noise present
    % in the data, so we define some threshold. If the difference is eqaul or
    % less than this, its good enough.
    
    %%%
    % _x_val_ will contains the value of the phi and theta over loop iterations
    % _e_val_ will contains the error (the difference in the length of the
    % projections over the persiod of the time). This should decrease with each
    % loop iterations
    x_val = zeros(4,num_of_iterations);
    e_val = zeros(size(gyro_s_knee,2), num_of_iterations);
    squareSummationError = zeros(1,num_of_iterations);
    err = zeros(1,num_of_iterations);
    
    j1_val = zeros(3,num_of_iterations);
    j2_val = zeros(3,num_of_iterations);
    
    x_val(:,1) = [phi1_val; theta1_val; phi2_val; theta2_val];
    
    squareSummationError(1,1) = 0;
    
    %%%
    % Calculating Joint Center Axes coordinates
    for k = 1 : num_of_iterations
        
        Jac = nan(size(gyro_s_knee,2),4);
        Jac_T =  nan(4, size(gyro_s_knee,2));
        
        %%%
        % Extracting the respective theta and phi for hte joint axes
        % jVal, given the theta and phi returns the axes in the spherical
        % coordinates
        j1_val(:,k) = jVal(x_val(1,k), x_val(2,k));
        j2_val(:,k) = jVal(x_val(3,k), x_val(4,k));
        
        %%%
        % This iterates over all the data points and calculat the sqaure of the
        % total error. As mentioned in the equation 6
        
        for i=1:size(gyro_s_knee,2)
            g1_val = gyro_s_knee(:,i);
            g2_val = gyro_s_shank(:,i);
            
            Jac(i,:) = subs(jac_debydx, [phi1, theta1, phi2, theta2, g1x, g1y, g1z, g2x, g2y, g2z], ...
                [x_val(1,k), x_val(2,k), x_val(3,k), x_val(4,k), g1_val(1), g1_val(2), g1_val(3), g2_val(1),...
                g2_val(2), g2_val(3)]);
            
            Jac_T(:,i) = Jac(i,:)';
            
            e_val(i,k) = subs(e, [phi1, theta1, phi2, theta2, g1x, g1y, g1z, g2x, g2y, g2z], ...
                [x_val(1,k), x_val(2,k), x_val(3,k), x_val(4,k), g1_val(1), g1_val(2), g1_val(3), g2_val(1),...
                g2_val(2), g2_val(3)]);
            
            squareSummationError(1,k) = squareSummationError(1,k) + e_val(i,k)^2;
            
        end
        
        %%%
        % Matrix multiplication. Not sure what Jz represents here TODO
        Jz = -Jac_T*Jac;
        
        %%%
        % mldivide solves system of linear equations
        % x = mldivide(A,B), solves Ax = B
        % g should be the moore -penrose inverse as given in the paper
        
        g = mldivide(Jz,Jac_T);
        x_val(:,k+1) = x_val(:,k)-pinv(Jac)*e_val(:,k);
        
        if(k == 1)
            err(k) = squareSummationError(1,k);
        else
            err(k) = squareSummationError(1,k) - squareSummationError(1,k-1);
        end
        
        disp(sprintf('JAS. Iteration %d the diff is %f and SquareSumError is %f',k,err(k),squareSummationError(1,k)));
        
        if (abs(err(k)) <= threshold);
            break
        end
    end
    
    %%%
    % Plot the figure showing the conversion..
    if showDataGraphs == 1
        figure; grid;hold on;
        plot( j1_val(1,:),'color',cc(1,:), 'LineWidth',2,'Marker', '*');
        plot( j1_val(2,:),'color',cc(2,:), 'LineWidth',2,'Marker', '*');
        plot( j1_val(3,:),'color',cc(3,:),'LineWidth',2,'Marker', '*');
        plot( j2_val(1,:),'color',cc(4,:),'LineWidth',2,'Marker', '*');
        plot( j2_val(2,:),'color',cc(5,:),'LineWidth',2,'Marker', '*');
        plot( j2_val(3,:),'color',cc(6,:),'LineWidth',2,'Marker', '*');
    end
    
    %%%
    % The value generated in the last iteration, where everything convreged is
    % the joint center axes.
    j1_valf = j1_val(:,k);
    j2_valf = j2_val(:,k);
    
    save(calibrationDataFile,'j1_valf','j2_valf','squareSummationError');
end

%% Error Analysis Analysis
% 
length1 = nan(1,size(gyro_s_knee,2));
length2 = nan(1,size(gyro_s_knee,2));
diff = nan(1,size(gyro_s_knee,2));
for i=1:size(gyro_s_knee,2)
    
    length1(i) = norm(cross(j1_valf,gyro_s_knee(:,i))) ;
    length2(i) = norm(cross(j2_valf,gyro_s_shank(:,i)));
    diff(i) = length1(i)-length2(i);
    
end

figure;grid;hold on;
plot(timestamp, length1','color','Black', 'LineWidth',2,'Marker', '*');
plot(timestamp, length2','color','Blue', 'LineWidth',2,'Marker', '*');
plot(timestamp, diff','color','Red', 'LineWidth',2,'Marker', '*');
title(sprintf('Plotting the Error in Difference. Sample Rate: %d',sample_rate),'FontSize',20);
xlabel('Timestamp','FontSize',20);
ylabel('Difference','FontSize',20);
set(gca,'fontsize',20)

