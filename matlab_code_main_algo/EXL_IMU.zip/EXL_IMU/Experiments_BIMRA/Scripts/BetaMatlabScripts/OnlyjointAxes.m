%function [angle_joint_axes ] =  jointCenterAndAxes(gyro_s_knee,gyro_s_derv_knee,gyro_s_shank,gyro_s_derv_shank,acc_s_knee,acc_s_shank,makeChanges,calibrationDataFile)
%% Calculating the Angle Values from Joint Center and Joint Center axis
% Read the Joint center axis and the joint center form the calibration
% results file
% 
load(calibrationDataFile);

%%%
% When the Joint center axes are calculated by the algorithm mentioned in
% the CalirabtionFile, then it gives two axis, one each with respect to the
% sensors placed.
%
% Now it does not say anything about the direction of the axes. There are
% four posibilities, taking into consideration the positive and the negative
% direction of both of the axes.
%
% We are adjusting this manually at the runtime, (by looking at the graphs).
if makeChanges ==1
    j1_valf =  j1_valf;
    j2_valf = j2_valf;
end

%%%
% Intializing the variables.

angle_joint_axes = nan(1, size(gyro_s_knee,2));
proj1 = nan(1, size(gyro_s_knee,2)-1);
proj2 = nan(1, size(gyro_s_knee,2)-1);

dproj1 = nan(1, size(gyro_s_knee,2)-1);
dproj2 = nan(1, size(gyro_s_knee,2)-1);

angle_joint_axes(1) = 0;

t = .01;


for i=2:size(gyro_s_knee,2)
    proj1(i-1) = dor(gyro_s_knee(:,i-1), j1_valf) ;
    proj2(i-1) = dot(gyro_s_shank(:,i-1), j2_valf);
    dproj1(i-1) = radtodeg(dot(gyro_s_knee(:,i-1), j1_valf));
    dproj2(i-1) = radtodeg(dot(gyro_s_shank(:,i-1), j2_valf));
    
    angle_joint_axes (i) = angle_joint_axes (i-1) +...
        radtodeg((proj2(i-1) - proj1(i-1)) * t);
end


figure; grid;hold on;
plot( angle_joint_axes,'color','black', 'LineWidth',2,'Marker', '*');
title(sprintf('Proj1 %s',filename1),'fontsize',20)
xlabel('Timestamp','fontsize',20)
ylabel('Knee Joint Angle','fontsize',20)
  set(gca,'fontsize',20);



