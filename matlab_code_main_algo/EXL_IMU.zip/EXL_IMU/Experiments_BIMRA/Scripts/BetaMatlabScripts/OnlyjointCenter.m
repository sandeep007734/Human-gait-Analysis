function [yy4 ] =  OnlyjointCenter(gyro_s_knee,gyro_s_derv_knee,gyro_s_shank,gyro_s_derv_shank,acc_s_knee,acc_s_shank,makeChanges,calibrationDataFile,timestamp)
%% Calculating the Angle Values from Joint Center and Joint Center axis
% Read the Joint center axis and the joint center form the calibration
% results file
% 
load(calibrationDataFile);

%%%
% When the Joint center axes are calculated by the algorithm mentioned in
% the CalirabtionFile, then it gives two axis, one each with respect to the
% sensors placed.
%
% Now it does not say anything about the direction of the axes. There are
% four posibilities, taking into consideration the positive and the negative
% direction of both of the axes.
%
% We are adjusting this manually at the runtime, (by looking at the graphs).
if makeChanges ==1
      j1_valf =[ -0.9427;       0.3061;     -0.1325];
         j2_valf =    [ -0.8964;    0.1597 ;    0.4135];
         
        j1_valf =  -j1_valf;
        j2_valf =  j2_valf;
end

%%%
% Intializing the variables.
angle_joint_centre = nan(1, size(gyro_s_knee,2));

% Here c = [1,0,0]'
x1_axis = cross(j1_valf,[1,0,0]');
y1_axis = cross(j1_valf, x1_axis);

x2_axis = cross(j2_valf,[1,0,0]');
y2_axis = cross(j2_valf, x2_axis);

r_acc_1 = cross(gyro_s_knee(:,1), cross(gyro_s_knee(:,1),o1_f)) + cross(gyro_s_derv_knee(:,1), o1_f);
r_acc_2 = cross(gyro_s_shank(:,1), cross(gyro_s_shank(:,1),o2_f)) + cross(gyro_s_derv_shank(:,1), o2_f);

a1_hat = acc_s_knee(:,1) - r_acc_1;
a2_hat = acc_s_shank(:,1) - r_acc_2;


u = [dot(a1_hat, x1_axis); dot(a1_hat, y1_axis)];
v = [dot(a2_hat, x2_axis); dot(a2_hat, y2_axis)];
CosTheta = dot(u,v)/(norm(u)*norm(v));

%%%
%  acosd  Inverse cosine, result in degrees.
angle_joint_centre(1) = acosd(CosTheta);



for i=2:size(gyro_s_knee,2)

    %%%
    % for angle joint centre
    % It uses both the gyron and acceleration values but there is a lot of
    % noise present in the data (or something else?) which makes the result
    % bad.
    r_acc_1 = cross(gyro_s_knee(:,i), cross(gyro_s_knee(:,i),o1_f)) + cross(gyro_s_derv_knee(:,i), o1_f);
    r_acc_2 = cross(gyro_s_shank(:,i), cross(gyro_s_shank(:,i),o2_f)) + cross(gyro_s_derv_shank(:,i), o2_f);
    a1_hat = acc_s_knee(:,i) - r_acc_1;
    a2_hat = acc_s_shank(:,i) - r_acc_2;
    
    u = [dot(a1_hat, x1_axis); dot(a1_hat, y1_axis)];
    v = [dot(a2_hat, x2_axis); dot(a2_hat, y2_axis)];
    CosTheta = dot(u,v)/(norm(u)*norm(v));
    
    angle_joint_centre(i) = acosd(CosTheta);
    
end

% TODO: These signs need to be modified based on the sensors
% orientation. Need to automate this
angle_joint_centre = (angle_joint_centre - angle_joint_centre(1));
% angle_joint_axes = - angle_joint_axes;

sf = 0.01;
yy4 = smooth(timestamp',angle_joint_centre,sf,'loess')';
%  yy4 = angle_joint_centre;

% figure; grid;hold on;
% plot( yy4,'color','black', 'LineWidth',2,'Marker', '*');
% filename1='Joint Ceter using Acc';
% title(sprintf('Joint Axes for the File %s',filename1));
% xlabel('Timestamp');
% ylabel('Knee Joint Angle');
