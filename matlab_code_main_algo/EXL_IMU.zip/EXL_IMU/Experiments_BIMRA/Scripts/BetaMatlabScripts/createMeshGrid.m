%This function is used to create the mesh plots of the Sqaure summation of
%error, of jval1 and jval2 SEPRARTELY over a period of range. It takes a
%lot of time to calculate the data points for the complete mesh. For a 36 X
%36 matrix it will take about half a day. Some saved values are in folder
%summation.
%It calls calcSSE internally, where the actual calculation is done.
%% Calc


phi1_val =  3.3337; theta1_val = -0.3743;
[phi2_val,theta2_val] = meshgrid(-2:.2:2);

j2_val = zeros(size(theta2_val,1),size(theta2_val,2),3);
summation = zeros(size(theta2_val,1),size(theta2_val,2));

totalruns = size(summation,2) * size(summation,2);
currrun = 1;
for x=1:size(summation,2)
    for y=1:size(summation,2)
        
        %         j1_val = jVal(x_val(1,k), x_val(2,k));
        j2_val(x,y,:) = jVal(phi2_val(x,y), theta2_val(x,y));
        
%         % Knee
%         summation(x,y) = calcSSE(gyro_s_thigh,gyro_s_shank,...
%             phi1_val,theta1_val,phi2_val(x,y),theta2_val(x,y));
        
        % Ankle
        summation(x,y) = calcSSE(gyro_s_shank,gyro_s_thigh,...
            phi1_val,theta1_val,phi2_val(x,y),theta2_val(x,y));
        
        fprintf('Run: %d / %d phi2: %f theta2: %f RSME: %f\n',currrun, totalruns,phi2_val(x,y),theta2_val(x,y),summation(x,y));
        currrun = currrun +1;
    end
end

disp('Create Mesh Done');

minMatrix = min(summation(:));
[row,col] = find(summation==minMatrix);
x_val = [phi1_val; theta1_val; phi2_val(row,col); theta2_val(row,col)];
j1_val = jVal(x_val(1), x_val(2));
j2_val = jVal(x_val(3), x_val(4));
% surf(summation);
