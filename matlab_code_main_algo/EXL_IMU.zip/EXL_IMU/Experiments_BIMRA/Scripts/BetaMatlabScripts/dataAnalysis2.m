%function [j1_valf, j2_valf] = doCalibration(folder,calibrationFile, calibrationDataFile)
%% Load data

calibrationDataFile = 'Experiments BIMRA_1/Gopinath/calibration_onlyCalibrateAxes.mat';
% These are the calibration file. Subject does not move anywhere while
% doing this. They stand at there positions
calibrationFile = ['S0_0007.txt';'S1_0007.txt'];
folder = 'Experiments_BIMRA_1/Gopinath/';


disp('Doing Data Analysis');
disp('Loading the data');

num_of_iterations = 50;
threshold = .0001;
sample_rate=10;
deltaT = sample_rate/100;
showPlot=1;


%%%
% Preparing the variables, which will be used in the calculation

%%%
% Exracting the name of the calibration file.
calibrationFile1 = strcat(folder,calibrationFile(1,:));
calibrationFile2 = strcat(folder,calibrationFile(2,:));

%%%
% Close any open plots. If _showDataGraphs_ is set to 1, then relevant
% plots will be plotted during execution.
% 
showDataGraphs = 1;

%%%
% Read data from calibration file into a structure.
data = importdata(calibrationFile1);
data2 = importdata(calibrationFile2);

%%%
% Reading the actual sensor data from the structure
tdata = data.data (1:end, :);
tdata2 = data2.data(1:end, :);

%%%
% Some residue data points from previous trails may creep into this one. We
% need to clear it. Mostly in the beginning and then match the data, so
% that the data from two sensors synchronize properly based on theire
% timestamp data.
% Match the data so that the start and the end of two data matches.
[startIdx1,startIdx2,endIdx1,endIdx2] = matchData(tdata,tdata2);
data = data.data (startIdx1:endIdx1, :);
data2 = data2.data(startIdx2:endIdx2, :);

%%%
% Getting the size of the data
size_data = size(data,1);


%%%
% Read the timestamp, accelerometer, gyrometer, time derivative gyro data
% and quaternion from the data.
% Quaternions provide a convenient mathematical notation for represneting
% orientations and rotations of objects in three dimensions.
% Compared to Euler angles they are simpler to compose and avoid the problem of gimbal lock.
% Compared to rotation matrices they are more numerically stable and may be more efficient.
% A gyroscope is a device that uses Earth’s gravity to help determine orientation.
% measure the rate of rotation around a particular axis

[timestamp,acc_s_thigh,gyro_s_thigh,gyro_s_derv_thigh,quarternion_thigh] = loadData(data,size_data);
[timestamp,acc_s_shank,gyro_s_shank,gyro_s_derv_shank,quarternion_shank] = loadData(data2,size_data);

%%% Sampling of the data
% sample_rate is the sampling frequency. Here we are taking 10 samples per second for
% the calculation

gyro_s_thigh = gyro_s_thigh(:, 1:sample_rate:end);
gyro_s_shank = gyro_s_shank(:, 1:sample_rate:end);
gyro_s_derv_thigh = gyro_s_derv_thigh(:, 1:sample_rate:end);
gyro_s_derv_shank = gyro_s_derv_shank(:, 1:sample_rate:end);
acc_s_thigh = acc_s_thigh(:, 1:sample_rate:end);
acc_s_shank = acc_s_shank(:, 1:sample_rate:end);
timestamp=timestamp(1:sample_rate:end);
timestamp = timestamp';

size(timestamp)
size(gyro_s_thigh)
size(gyro_s_shank)
%% Remove Drift
%% Filter


% timestamp = timestamp';
dataIn = gyro_s_thigh;

idx = find(timestamp > 1251);
dataIn = dataIn(:,idx);
timestamp_m = timestamp(idx);

% IIR
[b,a] = butter(6,0.4);
dataOut = filter(b,a,dataIn);


% OFFSET
modeVal = mode(dataOut')';
dataOut(1,:) = dataOut(1,:)-modeVal(1);
dataOut(2,:) = dataOut(2,:)-modeVal(2);
dataOut(3,:) = dataOut(3,:)-modeVal(3);

% DDI
% dataOut = dataIn;
dx = diff(dataOut');
dx=dx';
dt = diff(timestamp_m);

derv1 = zeros(size(dx));
% derv1 = dx'/dt';
derv1(1,:) = dx(1,:)./dt(1);
derv1(2,:) = dx(2,:)./dt(2);
derv1(3,:) = dx(3,:)./dt(3);

dx2 = diff(derv1');
dx2=dx2';

derv2 = zeros(size(dx2));
% derv1 = dx'/dt';
derv2(1,:) = dx2(1,:)./dt(1);
derv2(2,:) = dx2(2,:)./dt(2);
derv2(3,:) = dx2(3,:)./dt(3);

integ1 = cumtrapz(timestamp_m(1:size(derv2,2)),derv2,2);
integ2 = cumtrapz(timestamp_m(1:size(integ1,2)),integ1,2);

figure;
hold on; grid on;
plot((dataIn(3,:)),'color','Black', 'LineWidth',2,'Marker', '*');
plot((dataOut(3,:)),'color','Blue', 'LineWidth',2,'Marker', '*');
% plot((integ1(3,:)),'color','Green', 'LineWidth',2,'Marker', '*');
% plot((integ2(3,:)),'color','Red', 'LineWidth',2,'Marker', '*');
hold off;

gyro_s_thigh_m = integ2;



%% Getting Angles Thigh
% thighAngle = cumtrapz(timestamp(1:size(gyro_s_thigh_m,2)),gyro_s_thigh_m,2);
% plot((thighAngle(3,:)),'color','Red', 'LineWidth',2,'Marker', '*');

%% Getting Angles Shank
% shankAngle = cumtrapz(timestamp(1:size(gyro_s_shank,2)),gyro_s_shank,2);



%% Filter
% 
% 
% % timestamp = timestamp';
% dataIn = gyro_s_thigh(3,:);
% 
% idx = find(timestamp > 1251);
% dataIn = dataIn(idx);
% timestamp = timestamp(idx);
% 
% % IIR
% [b,a] = butter(4,0.24);
% dataOut = filter(b,a,dataIn);
% 
% 
% % OFFSET
% dataOut = dataOut -mode(dataOut);
% 
% % DDI
% % dataOut = dataIn;
% dx = diff(dataOut);
% dt = diff(timestamp);
% 
% derv1 = dx./dt;
% 
% dx = diff(derv1);
% 
% derv2 = dx./dt(1:size(dx,2));
% 
% integ1 = cumtrapz(timestamp(1:size(derv2,2)),derv2);
% integ2 = cumtrapz(timestamp(1:size(integ1,2)),integ1);
% 
% % figure;
% % hold on; grid on;
% % plot(timestamp(1:size(dataIn,2)),(dataIn),'color','Red', 'LineWidth',2,'Marker', '*');
% % plot(timestamp(1:size(dataOut,2)),(dataOut),'color','Red', 'LineWidth',2,'Marker', '*');
% % plot(timestamp(1:size(derv1,2)),(derv1),'color','Black', 'LineWidth',2,'Marker', '*');
% % plot(timestamp(1:size(derv2,2)),(derv2),'color','Black', 'LineWidth',2,'Marker', '*');
% % plot(timestamp(1:size(integ1,2)),(integ1),'color','Blue', 'LineWidth',2,'Marker', '*');
% % plot(timestamp(1:size(integ2,2)),(integ2),'color','Blue', 'LineWidth',2,'Marker', '*');
% % ylabel('Angle Thigh');
% % xlabel('TimeStamp');
% % % legend('Angles Z','Location','northeast');
% % title('Drift in Z axes. Thigh Angle');%
% % hold off;

