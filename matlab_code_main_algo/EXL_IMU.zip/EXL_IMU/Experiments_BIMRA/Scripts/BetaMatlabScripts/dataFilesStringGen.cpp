#include <iostream>
#include <string>

using namespace std;

int main()
{
int start = 3;
int end = 12;

string strSingle0="S0_000";
string strDouble0="S0_00";

string strSingle1="S1_000";
string strDouble1="S1_00";

string strSingle2="S2_000";
string strDouble2="S2_00";

string str1 = "dataFile1 = [";
cout<<str1;
for (int i=start;i<=end;i++){
	
	if(i<10)
	cout<<"'"<<strSingle0<<i<<".txt'";
	else
	cout<<"'"<<strDouble0<<i<<".txt'";
	
	if(i==end)
	cout<<"];\n";
	else
	cout<<";";
	
}

string str2 = "dataFile2 = [";
cout<<str2;
for (int i=start;i<=end;i++){
	
	if(i<10)
	cout<<"'"<<strSingle1<<i<<".txt'";
	else
	cout<<"'"<<strDouble1<<i<<".txt'";
	
	if(i==end)
	cout<<"];\n";
	else
	cout<<";";
	
}

string str3 = "dataFile3 = [";
cout<<str3;
for (int i=start;i<=end;i++){
	
	if(i<10)
	cout<<"'"<<strSingle2<<i<<".txt'";
	else
	cout<<"'"<<strDouble2<<i<<".txt'";
	
	if(i==end)
	cout<<"];\n";
	else
	cout<<";";
	
}


return 0;
}
