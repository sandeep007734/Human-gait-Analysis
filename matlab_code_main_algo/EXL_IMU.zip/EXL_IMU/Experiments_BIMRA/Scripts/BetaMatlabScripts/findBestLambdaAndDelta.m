%% Initialise parameters.
disp('filtering FE3');
maxJoint = max(angle_joint_axes);
maxRot = max(angle_rot_mat);
fact = maxJoint/maxRot;
fact=1;
modRot = angle_rot_mat*fact;

data_size = size(angle_joint_axes,2);
angle_FE3 = nan(1, data_size);
%     lambda = 0.01;
%     deltaT = 1; % 0.02 sec
angle_FE3(1,1) = angle_joint_axes(1,1);

disp('Custom FE3 filtering mode');

% bimraFilename = bimraFile(num,:);
% dataFileName = strcat(bimraFolder,bimraFilename,'_dir/acmRKFE_data');
% bimraData = importdata(dataFileName);
% 
% %removing zero by average
% bimraData((find(bimraData == 0))) = (bimraData(find(bimraData == 0)+1)+bimraData(find(bimraData == 0)-1))/2;
% %divide by scale factor
% scaleFactor = importdata(strcat(bimraFolder,bimraFilename,'_dir/acmRKFE_scalefactor'));
% bimraData = bimraData/scaleFactor;
% avgStepBimra = bimraData(1:2:end);

for lambda=0.1:.1:2
    for deltaT=0:.2:2.5
        angle_FE3(1,1) = angle_joint_axes(1,1);
        angle_FE3(1,2) = angle_joint_axes(1,2);
        
        % Main Loop
        for t = 3:data_size
            angle_FE3(1,t) = lambda*modRot(1,t) +(1-lambda)*(angle_FE3(1,round(t-deltaT))+...
                angle_joint_axes(1,t)-angle_joint_axes(1,round(t-deltaT)));
        end
        
%         avgStep = getSteps(angle_FE3,filename1,1,0);
%         avgStepBimraInter = interp1(1:1:size(avgStepBimra,2), avgStepBimra, 1:size(avgStepBimra,2)/...
%             (size(avgStep,2)+1):size(avgStepBimra,2));
%         rmse = sqrt(sum((avgStepBimraInter-avgStep).^2)/size(avgStep,2))
        
        
        %     avgStepBimra = getSteps(bimraData,bimraFilename,0,1);
        
    end
end
disp('Simulation Done');