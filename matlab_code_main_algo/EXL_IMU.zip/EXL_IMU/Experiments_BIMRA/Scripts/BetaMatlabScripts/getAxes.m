function[] = getAxes()
%% get data
%Physical Intrepretation of the output variables:

%j1_valf = The unit Joint axis vector wrt to the local coordinate system of
%the first segment of the gyroscope.

%j2_valf = The unit Joint axis vector wrt to the local coordinate system of
%the second segment of the gyroscope.
folder = 'Gopinath/';
calibrationFile = ['S0_0008.txt';'S0_0008.txt'];
%Calibration File
calibrationFile1 = strcat(folder,calibrationFile(1,:));
calibrationFile2 = strcat(folder,calibrationFile(2,:));

% Read data from file. Calibration Data

data = importdata(calibrationFile1);
data2 = importdata(calibrationFile2);

%ProgrNum,PacketType,AccX,AccY,AccZ,GyrX,GyrY,GyrZ,MagX,MagY,MagZ,Q0,Q1,Q2,Q3,Vbat

% Matching of the data in the two files based on their timestamp values.
tdata = data.data (1:end, :);
tdata2 = data2.data(1:end, :);

[startIdx1,startIdx2,endIdx1,endIdx2] = matchData(tdata,tdata2);

data = data.data (startIdx1:endIdx1, :);
data2 = data2.data(startIdx2:endIdx2, :);

% Getting the size of the data
size_data = size(data,1);


% for thigh data
[timestamp,acc_s_knee,gyro_s_knee,gyro_s_derv_knee,quarternion_knee] = loadData(data,size_data);
% for shank data
[timestamp,acc_s_shank,gyro_s_shank,gyro_s_derv_shank,quarternion_shank] = loadData(data2,size_data);

%% plot

gx = gyro_s_knee(1,:);
gy = gyro_s_knee(2,:);
gz = gyro_s_knee(3,:);

figure;
grid on;
plot3(gx,gy,gz);
xlabel('X axis');
ylabel('Y axis');
zlabel('Z axis');
