function [realAvgStep] = getSteps(stepData,filename1, saveToFile, isBimra)
    
    %% tewmp
    
            localRun = 0;
%             
%     
%     stepData = angle_joint_axes;
%     
%     %     stepData = bimraData;
%     isBimra = 0;
%     
%     saveToFile = 0;
%     localRun = 1;
    
 
    
    %% bimra
    if isBimra == 1
        figure;
        hold on; grid on;
        plot(stepData(101:200));
        realAvgStep = (stepData(1:100)+stepData(101:200))/2;
        plot(realAvgStep)
        
    end
    
    %% exl
    if isBimra ==0
        lowVal = min(stepData);
        timestamp = 1:size(stepData,2);
        
        %% Make everything above zero
        if lowVal < 0
            stepData = stepData+ abs(lowVal);
        end
        
        
        %% Inverse of the data to get minmas using peak.
        DataInv = 1.01*max(stepData) - stepData;
        % DataInv = angle_FE;
        
        [p pl] = findpeaks(stepData);
        avg = mean(p);
        steps = sum(p > max(p)-10);
        [p pl] = findpeaks(stepData,'MinPeakDistance',30,'MinPeakHeight',avg);
        
        % removing false peaks
        p(p < mean(p)-10)= 0;
        pl(p < mean(p)-10) = 0;
        p(p==0) = [];
        pl(pl==0) = [];
        
        [pi pli] = findpeaks(DataInv,'MinPeakDistance',30,'MinPeakHeight',5);
        
        % disp(sprintf('Numner of steps is  %d and the average was %d',steps,avg));
        
        %Normal
        temp = stepData;
        temp(timestamp) = 0;
        temp(pl) = p;
        
        %Removing additonal minimas
        pi(1:sum(pli < pl(1))-1)=0;
        pi(size(pi,2)-sum(pli > pl(size(pl,2)))+2:size(pi,2))=0;
        pli(pi==0)=0;
        
        % removing all the zero entires
        pi(pi==0) = [];
        pli(pli==0) = [];
        
        %need the complete steps, remove inbetween dips
        pi = pi(1:2:end);
        pli = pli(1:2:end);
        
        %there has to be a proper step in between two minimas
        if max(stepData(pli(size(pli,2)-1):pli(size(pli,2)))) > mean(p(1:2:end)-10)
        else
            pi = pi(1:end-1);
            pli = pli(1:end-1);
        end
        
        % Inverse
        stepStart = DataInv;
        stepStart(timestamp) = 0;
        stepStart(pli) = pi;
        
        
        % From here onwards the actual matching is done.
        % Getting the minimum position in the step size.
        minPos(1:size(pli,2)-1)=0;
        for idx = 1:size(pli,2)-1
            peaks = findpeaks(stepData(pli(idx):pli(idx+1)));
            fmax = max(peaks);
            peaks(find(peaks == max(peaks)))=0;
            smax = max(peaks);
            sid = find(stepData(pli(idx):pli(idx+1))==fmax)+pli(idx)-1;
            eid = find(stepData(pli(idx):pli(idx+1))==smax)+pli(idx)-1;
            minPos(idx) = find(stepData(pli(idx):pli(idx+1)) == min(stepData(sid:eid)))+pli(idx)-1;
        end
        stepPart = stepStart;
        stepPart(1:end) = 0;
        stepPart(minPos) = max(stepStart);
        
        
        
                 %% Drift Analysis
        driftSteps = stepData(pli(1):pli(end));
        driftAngle = .012;
        for di = 1:size(driftSteps,2)
            driftSteps(1,di) = driftSteps(1,di) +driftAngle*di;
        end
         stepData(pli(1):pli(end)) = driftSteps;
        
        %% Real Average
        
        %Getting the average step size, if there is a mis match with the Bimra data
        %then fix here.
        
        minStepSize = 9999;
        for k = 2:size(minPos,2)
            if minStepSize > (minPos(k)-minPos(k-1))
                minStepSize = (minPos(k)-minPos(k-1));
            end
        end

 
        
        %% Real Average step size
        realAvgStep(1:minStepSize+1)=0;
        for idx =2:3

            midPoint = (minPos(idx)+minPos(idx+1))/2;
            realAvgStep = realAvgStep+stepData(round(midPoint-(minStepSize/2)):round(midPoint+(minStepSize/2)));   
        end
        realAvgStep = realAvgStep/2;
        
      
        
        %% Print Steps
        h = figure;
        if localRun ==0
            set(h,'Visible','off');
        end
        hold on;
        plot(timestamp(pli(1):pli(end)), stepData(pli(1):pli(end)),'color','red', 'LineWidth',2,'Marker', '*');
        plot(timestamp(pli(1):pli(end)), stepStart(pli(1):pli(end)),'color','blue', 'LineWidth',2,'Marker', '*');
        plot(timestamp(pli(1):pli(end)), stepPart(pli(1):pli(end)),'color','black', 'LineWidth',2,'Marker', '*');
        title(sprintf('For the File %s',filename1));
        
        if saveToFile == 1
            saveas(h,'figure_steps','jpg');
        end
        
        % plot average step
        h1 = figure;
        if localRun ==0
            set(h1,'Visible','off');
        end
        hold on; grid on;
        plot(realAvgStep,'color','red', 'LineWidth',2,'Marker', '*');
        title(sprintf('Average Step for the File %s',filename1));
    end
    
    
    
