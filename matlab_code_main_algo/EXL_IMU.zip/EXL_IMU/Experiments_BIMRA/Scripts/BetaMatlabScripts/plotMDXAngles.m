function [] = plotMDXAngles(filename,bimraFile)

%% plot
bimraFile = 'test.mdx_dir';
bimraData = importdata(strcat('3dGopinath/',bimraFile,'/acRKFE_196_data'));
%removing zero by average
bimraData((find(bimraData == 0))) = (bimraData(find(bimraData == 0)+1)+bimraData(find(bimraData == 0)-1))/2;
getSteps(bimraData,'dsfsd');
% plot(bimraData);
