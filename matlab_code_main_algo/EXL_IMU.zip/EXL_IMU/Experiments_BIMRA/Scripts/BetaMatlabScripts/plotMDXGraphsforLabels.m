function [] = plotMDXGraphs(filename)

%% Get files
fNames = dir( fullfile('.','*_data') );

size (fNames,1)

%%plot
for n =1:size(fNames,1)
    filename = fNames(n).name
    data = importdata(filename);
    h = figure;
    set(h,'Visible','off');
    grid; hold on;
    plot( data,'color','red', 'LineWidth',2,'Marker', '*');
    filename = strtok(filename,'_');
    title(filename)
    saveas(h,filename,'jpg');
    
end

%% plot
data = importdata(filename);
h = figure;
set(h,'Visible','off');
grid; hold on;
plot( data,'color','red', 'LineWidth',2,'Marker', '*');
filename = strtok(filename,'_');
title(filename)
saveas(h,filename,'jpg');

