
%It Only PLOTS THE MESH.

%% Calc
load('summation/summ1.mat');
ts=summation;
titleStr='Mesh Plot Joint Axis for Sensor 1';
gifFile = 'j1Val.gif';
xTick=[-5:.2:2];
yTick=[-5:.2:2];

%% Fast PLot
% surf(xTick(1:18), yTick(1:18),ts(1:18,:));

fig = figure;
set(fig,'units','normalized','position',[0 0 1 1]);
surf(xTick, yTick,ts);
axis([-5 2 -5 2 0 max(max(ts))]);
view(3);
title(titleStr,'fontSize',20);
xlabel('Phi Values','fontSize',20);
ylabel('Theta Values','fontSize',20);
zlabel('Summation of Square Errors','fontSize',20);
set(gca,'fontSize',20);
% dim = [.4 0 .3 .3];
maxError = max(max(ts));
minError = min(min(ts));
str = strcat('Maximum Summation of Error: ',num2str(maxError),', Minimum Summation of Error: ',num2str(minError));
annotation(fig,'textbox',[0.350865229110512 0.012987012987013 0.265307277628032 0.0609390609390609],...
    'String',str,...
    'FontSize',18,...
    'FitBoxToText','off',...
    'LineStyle',':');

%% Animated one

j = 1;

fig = figure;
hold on;
set(fig,'units','normalized','position',[0 0 1 1]);
for limit=2:36
    
    surf(xTick(1:limit), yTick,ts(:,1:limit));
    axis([-5 2 -5 2 0 max(max(ts))]);
    view(3);
    title(titleStr,'fontSize',20);
    xlabel('Phi Values','fontSize',20);
    ylabel('Theta Values','fontSize',20);
    zlabel('Summation of Square Errors','fontSize',20);
    set(gca,'fontSize',20);
    maxError = max(max(ts));
    minError = min(min(ts));
    str = strcat('Maximum Summation of Error: ',num2str(maxError),', Minimum Summation of Error: ',num2str(minError));
    annotation(fig,'textbox',[0.350865229110512 0.012987012987013 0.265307277628032 0.0609390609390609],...
        'String',str,...
        'FontSize',18,...
        'FitBoxToText','off',...
        'LineStyle',':');
    
    
             frame = getframe(1);
            im = frame2im(frame);
            [A,map] = rgb2ind(im,256);
    
            if j == 1
                imwrite(A,map,gifFile,'gif', 'Loopcount',1,'DelayTime',1/24);
            else
                imwrite(A,map,gifFile,'gif','WriteMode','append','DelayTime',1/10);
            end
    
            j = 0;
    
    pause(.2);
    if(limit ~= 36)
        clf(fig);
    end
end

%% Get correct J'S
load('summation/summ2.mat');
ts=summation;

minrow = find(min(ts')==min(min(ts')));
mincol = find(min(ts)==min(min(ts)));

[phi_val,theta_val] = meshgrid(-5:.2:2);

minPhi = phi_val(minrow,mincol);
minTheta = theta_val(minrow,mincol);

jVal(minPhi,minTheta)
