%% Calc
idx = 1198;
ts = timestamp';
dFreePrev = acc_s_shank(1,idx:end);
    [b,a] = butter(4,.1);
    dFree = filter(b,a,dFreePrev);
    

figure;
hold on; grid on;
plot(ts(1,idx:end),dFree,'color','Black', 'LineWidth',2,'Marker', '*')
plot(ts(1,idx:end),dFreePrev,'color','Blue', 'LineWidth',1,'Marker', '*')

% plot(timestamp',acc_s_shank(2,:),'color','Black', 'LineWidth',2,'Marker', '*')
% plot(timestamp',acc_s_shank(3,:),'color','Black', 'LineWidth',2,'Marker', '*')
hold off;
