%The purpose of the function is to remove the lag which is present in the
%both of the sensors present.
%One sensors receive the data a little late than the other one.
%So the events in the steps are little separated.
%DO NOT USE THIS FILTER

%Primaraly used in the calibration of the data.
function[acc_s_knee_shifted,acc_s_shank_shifted,gyro_s_knee_shifted,gyro_s_shank_shifted] = val2Matching(acc_s_knee,acc_s_shank,gyro_s_knee,gyro_s_shank)
%% run
% close all
showPlot = 0;
% 1 =20

acc_s_knee_shifted = zeros(size(acc_s_knee,1),size(acc_s_knee,2));
acc_s_shank_shifted = zeros(size(acc_s_shank,1),size(acc_s_shank,2));

gyro_s_knee_shifted = zeros(size(gyro_s_knee,1),size(gyro_s_knee,2));
gyro_s_shank_shifted = zeros(size(gyro_s_shank,1),size(gyro_s_shank,2));


for row=1:3
    
    if row == 1
        
        %shifting
        shiftVal = 1;
        acc_s_shank_shift = acc_s_shank(row,shiftVal:end);
        tacc_s_knee = acc_s_knee;
        acc_s_shank_shift = [acc_s_shank_shift,zeros(1,size(acc_s_shank,2)-size(acc_s_shank_shift,2))];
        
        % making start the same
        if acc_s_knee(row,1) < acc_s_shank_shift(1,1)
            diff = acc_s_shank_shift(1,1) - acc_s_knee(row,1);
            acc_s_knee(row,:) = acc_s_knee(row,:) +diff ;
        else
            diff = acc_s_knee(row,1) - acc_s_shank_shift(1,1);
            acc_s_shank_shift = acc_s_shank_shift+diff;
        end
        
        acc_s_shank_shifted(row,:) = acc_s_shank_shift;
        acc_s_knee_shifted(row,:) = acc_s_knee(row,:);
        
        if showPlot ==1
            figure;
            hold on; grid on;
            plot(acc_s_knee(row,:));
            plot(acc_s_shank_shift(1,:),'color','red');
        end
        acc_s_knee = tacc_s_knee;
        
    elseif row ==2
        %shifting
        shiftVal = 1;
        acc_s_knee_shift = acc_s_knee(row,shiftVal:end);
        tacc_s_shank = acc_s_shank;
        acc_s_knee_shift = [acc_s_knee_shift,zeros(1,size(acc_s_shank,2)-size(acc_s_knee_shift,2))];
        
        % making start the same
        if acc_s_knee_shift(1,1) < acc_s_shank(row,1)
            diff = acc_s_shank(row,1) - acc_s_knee_shift(1,1);
            acc_s_knee_shift(1,:) = acc_s_knee_shift(1,:) +diff ;
        else
            diff = acc_s_knee_shift(1,1) - acc_s_shank(row,1);
            acc_s_shank(row,:) = acc_s_shank(row,:)+diff;
        end
        
        acc_s_knee_shifted(row,:) = acc_s_knee_shift;
        acc_s_shank_shifted(row,:) = acc_s_shank(row,:);
        
        if showPlot ==1
            figure;
            hold on; grid on;
            plot(acc_s_knee_shift(1,:),'color','red');
            plot(acc_s_shank(row,:),'color','blue');
        end
        acc_s_shank = tacc_s_shank;
    else
        %shifting
        shiftVal = 7;
        acc_s_knee_shift = acc_s_knee(row,shiftVal:end);
        tacc_s_shank = acc_s_shank;
        acc_s_knee_shift = [acc_s_knee_shift,zeros(1,size(acc_s_shank,2)-size(acc_s_knee_shift,2))];
        
        % making start the same
        if acc_s_knee_shift(1,1) < acc_s_shank(row,1)
            diff = acc_s_shank(row,1) - acc_s_knee_shift(1,1);
            acc_s_knee_shift(1,:) = acc_s_knee_shift(1,:) +diff ;
        else
            diff = acc_s_knee_shift(1,1) - acc_s_shank(row,1);
            acc_s_shank(row,:) = acc_s_shank(row,:)+diff;
        end
        
        acc_s_knee_shifted(row,:) = acc_s_knee_shift;
        acc_s_shank_shifted(row,:) = acc_s_shank(row,:);
        
        if showPlot ==1
            figure;
            hold on; grid on;
            plot(acc_s_knee_shift(1,:),'color','red');
            plot(acc_s_shank(row,:),'color','blue');
        end
        acc_s_shank = tacc_s_shank;
        
    end
end

for row=1:3
    if row == 1
        
        %shifting
        shiftVal = 1;
        gyro_s_shank_shift = gyro_s_shank(row,shiftVal:end);
        gyro_s_shank_shift = [gyro_s_shank_shift,zeros(1,size(gyro_s_shank,2)-size(gyro_s_shank_shift,2))];
        
        gyro_s_knee_shifted(row,:) = gyro_s_knee(row,:);
        gyro_s_shank_shifted(row,:) = gyro_s_shank_shift;
        
        
        if showPlot ==1
            figure;
            hold on; grid on;
            plot(gyro_s_knee(row,:));
            plot(gyro_s_shank_shift(1,:),'color','red');
        end
    elseif row ==2
        
        %shifting
        shiftVal = 3;
        gyro_s_knee_shift = gyro_s_knee(row,shiftVal:end);
        gyro_s_knee_shift = [gyro_s_knee_shift,zeros(1,size(gyro_s_shank,2)-size(gyro_s_knee_shift,2))];
        
        gyro_s_knee_shifted(row,:) = gyro_s_knee_shift;
        gyro_s_shank_shifted(row,:) = gyro_s_shank(row,:);
        
        
        if showPlot ==1
            figure;
            hold on; grid on;
            plot(gyro_s_shank(row,:),'color','red');
            plot(gyro_s_knee_shift(1,:),'color','blue');
        end
    else
        
        %shifting
        shiftVal = 7;
        gyro_s_knee_shift = gyro_s_knee(row,shiftVal:end);
        gyro_s_knee_shift = [gyro_s_knee_shift,zeros(1,size(gyro_s_shank,2)-size(gyro_s_knee_shift,2))];
        
        gyro_s_knee_shifted(row,:) = gyro_s_knee_shift;
        gyro_s_shank_shifted(row,:) = gyro_s_shank(row,:);
        
        if showPlot ==1
            figure;
            hold on; grid on;
            plot(gyro_s_shank(row,:),'color','red');
            plot(gyro_s_knee_shift(1,:),'color','blue');
        end
        
    end
end