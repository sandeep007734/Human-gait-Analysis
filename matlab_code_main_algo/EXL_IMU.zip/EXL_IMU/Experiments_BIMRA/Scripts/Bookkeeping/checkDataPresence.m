function [ rightThighDataPresent,rightShankDataPresent,rightFootDataPresent,proceRightKneeJoint,processRightFootJoint,noOfWalkingTrials ] = ...
checkDataPresence( rightThighDataFile,rightShankDataFile,rightFootDataFile,maxTrialAllowed )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% Check whether we got the foot data. If not make sure that it is not used
% in the future calculations.
% Foot data will be present if we have placed a sensor on the foor during
% the experiments. Typically when 3 sensors are placed on one leg.
rightThighDataPresent=0;
rightShankDataPresent=0;
rightFootDataPresent=0;

if(~isempty(rightThighDataFile))
    rightThighDataPresent=1;
else
    disp('Right Thigh Data Present');
end
if(~isempty(rightShankDataFile))
    rightShankDataPresent=1;
    else
    disp('Right Shank Data Present');
end
if(~isempty(rightFootDataFile))
    rightFootDataPresent=1;
    else
    disp('Right Foot Data Present');
end

proceRightKneeJoint = 0;
processRightFootJoint = 0;

if(rightThighDataPresent && rightShankDataPresent)
    proceRightKneeJoint = 1;
end
if(rightFootDataPresent && rightShankDataPresent)
    processRightFootJoint = 1;
end

%%

% Get the walking trials for this experiment.
% Number of experiment files present. (Walks done).
noOfWalkingTrials = size(rightThighDataFile,1);
% The experiment are capped at 11 walks. This can be changed depending upon
% the need.

if noOfWalkingTrials > maxTrialAllowed
    noOfWalkingTrials = maxTrialAllowed;
end

end

