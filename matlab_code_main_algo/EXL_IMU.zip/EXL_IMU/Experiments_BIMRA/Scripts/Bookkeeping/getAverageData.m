if(~isempty(HSFoot) )
    [ avgRightKneeFE ] = calcuateAverageIMUData( imuRightKneeFE, HSFoot );
    [ avgRightAnkleDP ] = calcuateAverageIMUData( imuRightAnkleDP, HSFoot );
    [ avgRightKneeAA ] = calcuateAverageIMUData( imuRightKneeAA, HSFoot );
    [ avgRightKneeIE ] = calcuateAverageIMUData( imuRightKneeIE, HSFoot );
    [ avgRightHipFE ] = calcuateAverageIMUData( imuRightHipFE, HSFoot );
    [ avgRightAnkleIE ] = calcuateAverageIMUData( imuRightAnkleIE, HSFoot );
    [ avgRightHipAA ] = calcuateAverageIMUData( imuRightHipAA, HSFoot );
    
elseif( ~isempty(HSShank))
    [ avgRightKneeFE ] = calcuateAverageIMUData( imuRightKneeFE, HSShank );
    [ avgRightAnkleDP ] = calcuateAverageIMUData( imuRightAnkleDP, HSShank );
    [ avgRightKneeAA ] = calcuateAverageIMUData( imuRightKneeAA, HSShank );
    [ avgRightKneeIE ] = calcuateAverageIMUData( imuRightKneeIE, HSShank );
    [ avgRightHipFE ] = calcuateAverageIMUData( imuRightHipFE, HSShank );
    [ avgRightAnkleIE ] = calcuateAverageIMUData( imuRightAnkleIE, HSFoot );
    [ avgRightHipAA ] = calcuateAverageIMUData( imuRightHipAA, HSFoot );
else
    avgRightKneeFE=[];
    avgRightAnkleDP=[];
    avgRightKneeAA=[];
    avgRightKneeIE=[];
    avgRightHipFE=[];
    avgRightAnkleIE=[];
    avgRightHipAA=[];
    disp('No HEEL STRIKE data PRESENT. Cannot Calculate the Average Steps');
    return;
end

avgRightKneeFE = interpolateData(avgRightKneeFE,101);
avgRightAnkleDP = interpolateData(avgRightAnkleDP,101);
avgRightKneeAA = interpolateData(avgRightKneeAA,101);
avgRightKneeIE = interpolateData(avgRightKneeIE,101);
avgRightAnkleIE =  interpolateData(avgRightAnkleIE,101);
avgRightHipAA =  interpolateData(avgRightHipAA,101);

if(isempty(bimraFiles) || (compareWithBimra==0))
    avgFEJrk=[];
    avgacrkfe = [];
    acmrkfe=[];
    avgarafe=[];
    avgacrafe=[];
    acmrafe = [];
end