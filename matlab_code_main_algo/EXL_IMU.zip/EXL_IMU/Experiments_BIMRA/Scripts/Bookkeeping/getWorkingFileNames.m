function [ rightThighFile, rightShankFile,rightAnkleFile,corresPondingBimraFile ] = getWorkingFileNames( folder, rightThighDataFiles,rightShankDataFiles,...
    rightFootDataFiles,num,bimraFolder,bimraFiles,compareWithBimra)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%%%
% * Get the names of the raw data files which are to be processed in
% this loop.
if(~isempty(rightThighDataFiles))
    rightThighFile = char(strcat(folder,rightThighDataFiles(num,:)));
else
    rightThighFile=[];
end

if(~isempty(rightShankDataFiles))
    rightShankFile = char(strcat(folder,rightShankDataFiles(num,:)));
else
    rightShankFile=[];
end

if(~isempty(rightFootDataFiles))
    rightAnkleFile = strcat(folder,rightFootDataFiles(num,:));
else
    rightAnkleFile=[];
end

if(isempty(bimraFiles)||(compareWithBimra==0))
    corresPondingBimraFile=[];
else
    corresPondingBimraFile = strcat(bimraFolder,bimraFiles(num,:));
end

end

