      % * Process the MDX file (Processed results from the Opticl system)
        % and get all the info needed from it.
        
        
        % JRK data is what is used by the BIMRA algorithms to calculate the
        % Knee flexion extension angle. The values along the z axis, is
        % used for this purpose.
        bimraFileName = bimraFiles(num,:);
        structMdxData = getMDXData(bimraFiles(num,:),bimraFolder);
        if(~isempty(structMdxData.jrkDataZ))
            validBimraData=1;
        else
            validBimraData=0;
        end
        fprintf('Optical Data summary:\n\n');
        disp(structMdxData);
        v2struct(structMdxData);
        
        if(plotOptical)
            plotOpticalCode();
        end
