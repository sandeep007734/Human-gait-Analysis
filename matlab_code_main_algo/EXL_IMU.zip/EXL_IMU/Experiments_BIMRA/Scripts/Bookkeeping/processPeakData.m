        %%
        % Detecting start and end point will not be required in the Final Implementation
        % These end points corresponds to the actual start of the walk, and
        % not the start of the recording of the data. If there is a peak
        % present in the data, then it provides the start point after it.
        
        % Get Start, Peak and End point in the IMU Data.
        
        disp('Getting the Starting and Ending Point of the data automatically.')
        [ startDataPoint, endDataPoint,rawPeakIdx ] = findStartAndEndPoints(gyro_s_foot(1,:));
        %         [ mainStart, peakIdx, startDataPoint, endDataPoint ] = newfindStartAndEndPoints(gyro_s_foot(1,:));
        fprintf('End points are as follow, start: %d, rawPeakIdx: %d end: %d\n',startDataPoint,rawPeakIdx,endDataPoint);
        
        if(plotstartRawIdandEnd)
            plotstartRawIdandEndCode();
        end
