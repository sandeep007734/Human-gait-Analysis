    % Add the data files used here.
    fid = fopen(strcat(pathToSave,'dataFiles.txt'),'wt');
    fprintf(fid, strcat(corresPondingBimraFile,'\n'));
    fprintf(fid, strcat(rightThighFile,'\n'));
    fprintf(fid, strcat(rightShankFile,'\n'));
    if(rightFootDataPresent)
        fprintf(fid, rightAnkleFile);
    end
    fclose(fid);