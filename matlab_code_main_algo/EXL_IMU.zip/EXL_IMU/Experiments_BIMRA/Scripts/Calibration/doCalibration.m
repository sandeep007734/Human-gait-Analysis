function [rmse_x] = doCalibration(folder,calibrationFile, calibrationDataFile,num_of_iterations,...
    threshold,scale_factor,joint,showDataGraphs)
%% There are different methods for doing Calibration which can be mentioned here.

%% Joint Axis Vector
axis=1;
[ j1_valf_x, j2_valf_x, rmse_x ] = gaussNewtonCalibration( folder,calibrationFile, scale_factor,...
    num_of_iterations,threshold,showDataGraphs,joint);

% [j1_valf_y,j1_valf_z] = getNewAxises(j1_valf_x);
% [j2_valf_y,j2_valf_z] = getNewAxises(j2_valf_x);

% axis=2;
% [ j1_valf_y, j2_valf_y, rmse_y ] = calibrationJointAxis( folder,calibrationFile, scale_factor,...
%     num_of_iterations,threshold,showDataGraphs,joint,axis);
% 
% axis=3;
% [ j1_valf_z, j2_valf_z, rmse_z ] = calibrationJointAxis( folder,calibrationFile, scale_factor,...
%     num_of_iterations,threshold,showDataGraphs,joint,axis);
j1_valf_y=[];
j2_valf_y = [];
j1_valf_z=[];
j2_valf_z=[];
rmse_y=[];
rmse_z=[];
%% Calculatiing Joint Center coordinates, these are in cartesian coordinates. Preparing the variables
o1_f=[];
o2_f=[];

%%
% Save the Joint center axes and coordinates in the calibration file, so
% that the next time it doesnot have to run again.

save(calibrationDataFile,'j1_valf_x','j2_valf_x',...
    'j1_valf_y','j2_valf_y',...
    'j1_valf_z','j2_valf_z',...
    'o1_f','o2_f','rmse_x','rmse_y','rmse_z');



% disp('Calibration Done');
