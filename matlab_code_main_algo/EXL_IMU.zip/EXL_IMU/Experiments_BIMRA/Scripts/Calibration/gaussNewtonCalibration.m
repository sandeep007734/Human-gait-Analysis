function [ j1_valf, j2_valf, rmse ] = gaussNewtonCalibration( folder,calibrationFile, scale_factor,num_of_iterations,threshold,showDataGraphs,joint)

%% Run this

% Exracting the name of the calibration file.
calibrationFile1 = strcat(folder,calibrationFile(1,:));
calibrationFile2 = strcat(folder,calibrationFile(2,:));

% Read data from calibration file into a structure.
data = importdata(char(calibrationFile1));
data2 = importdata(char(calibrationFile2));

% Reading the actual sensor data from the structure
tdata = data.data (1:end, :);
tdata2 = data2.data(1:end, :);

% Match the data so that the start and the end of two data matches.
[startIdx1,startIdx2,endIdx1,endIdx2] = matchData(tdata,tdata2);
data = data.data (startIdx1:endIdx1, :);
data2 = data2.data(startIdx2:endIdx2, :);

% Getting the size of the data
size_data = min(max(size(data)),max(size(data2)));

% Read the timestamp, accelerometer, gyrometer, time derivative gyro data
% and quaternion from the data.
[timestamp,acc_s_first,gyro_s_first,gyro_s_derv_first,quarternion_first] = loadData(data,size_data);
[timestamp,acc_s_second,gyro_s_second,gyro_s_derv_second,quarternion_second] = loadData(data2,size_data);



%%% Sampling of the data
if(scale_factor>1)
    gyro_s_first = gyro_s_first(:, 1:scale_factor:end);
    gyro_s_second = gyro_s_second(:, 1:scale_factor:end);
end

% Prepare the variables for joint center axes Color Palette
cc=hsv(6);

% Arguments for which the funcions need to be minimized. Ψ(φ1,φ2, θ1, θ2)
syms phi1 theta1 phi2 theta2;

% CHANGE THE AXIS of Interest HERE.

% The spherical coordinates representation of the j1 and j2.
% The axis through Saggital Plane
% %Actual
%  j1 = [cos(phi1)*cos(theta1); cos(phi1)*sin(theta1); sin(phi1)];
%  j2 = [cos(phi2)*cos(theta2); cos(phi2)*sin(theta2); sin(phi2)];

% % % as per wiki
% j1 = [sin(phi1)*cos(theta1); sin(phi1)*sin(theta1); cos(phi1)];
% j2 = [sin(phi2)*cos(theta2); sin(phi2)*sin(theta2); cos(phi2)];

% % as per wiki FLIPPED
j1 = [ cos(phi1); sin(phi1)*sin(theta1); sin(phi1)*cos(theta1)];
j2 = [ cos(phi2);sin(phi2)*sin(theta2); sin(phi2)*cos(theta2)];

% The angluar velocity split into its x,y and z coordinates
syms g1x g1y g1z g2x g2y g2z;
g1 = [g1x; g1y; g1z];
g2 = [g2x; g2y; g2z];

l1 = cross(g1, j1);
l2 = cross(g2, j2);

% Normalizing over the all the axes.
norm_l1 = sqrt( (l1(1,1)^2) + (l1(2,1)^2) + (l1(3,1)^2) );
norm_l2 = sqrt( (l2(1,1)^2) + (l2(2,1)^2) + (l2(3,1)^2) );

% There difference finally gives the e
e = norm_l1 - norm_l2;

% Calculating the Jacobain using the e and the arguements
jac_debydx = jacobian (e, [phi1 theta1 phi2 theta2]);

% Setting up the intial value of the variable Joint center axes
phi1_val = pi/6; theta1_val = pi/3;
phi2_val = pi/3; theta2_val = pi/6;

% according to the old mesh code
% phi1_val =  3.3337; theta1_val = -0.3743;
% phi2_val = -0.2000; theta2_val =  -3.2000;

x_val = zeros(4,num_of_iterations);
e_val = zeros(size(gyro_s_first,2), num_of_iterations);

j1_val = zeros(3,num_of_iterations);
j2_val = zeros(3,num_of_iterations);

x_val(:,1) = [phi1_val; theta1_val; phi2_val; theta2_val];

% Sqaure summation error
SSError = zeros(1,num_of_iterations);
SSError(1) = 0;

% if(axis==1)
%     gyro_s_first(1,:)=1;
%     gyro_s_second(1,:)=1;
% elseif (axis==2)
%     gyro_s_first(2,:)=1;
%     gyro_s_second(2,:)=1;
% elseif (axis==3)
%     gyro_s_first(3,:)=1;
%     gyro_s_second(3,:)=1;
% end

% for tryagain = 1: 2
%     if(tryagain==2)
%      x_val(:,1) =  x_val(:,num_of_iterations)
% end
for k = 1 : num_of_iterations
    Jac = nan(size(gyro_s_first,2),4);
    Jac_T =  nan(4, size(gyro_s_first,2));
    
    j1_val(:,k) = jVal(x_val(1,k), x_val(2,k));
    j2_val(:,k) = jVal(x_val(3,k), x_val(4,k));
    
    for i=1:size(gyro_s_first,2)
        
        g1_val = gyro_s_first(:,i);
        g2_val = gyro_s_second(:,i);
        
        Jac(i,:) = calib_calc_jac_debydx(x_val(1,k), x_val(2,k), x_val(3,k), x_val(4,k), g1_val(1), g1_val(2), g1_val(3), g2_val(1),...
            g2_val(2), g2_val(3));
        
        
        e_val(i,k) = calib_calc_e(x_val(1,k), x_val(2,k), x_val(3,k), x_val(4,k), g1_val(1), g1_val(2), g1_val(3), g2_val(1),...
            g2_val(2), g2_val(3));
        
        SSError(k) = SSError(k) + e_val(i,k)^2;
        
        
    end
    
    % Matrix Inverse
    x_val(:,k+1) = x_val(:,k)-pinv(Jac)*e_val(:,k);
    
    if(k == 1)
        err(k) = SSError(k);
    else
        err(k) = SSError(k) - SSError(k-1);
    end
    
    
    %     fprintf('Iter: %d: RMSE is %f \n',k, sqrt(SSError(k)/size(gyro_s_thigh,2)));
    fprintf('.');
    %     if (abs(err(k)) <= threshold);
    %         break
    %     end
end
%     end
%%%
% The value generated in the last iteration, where everything convreged is
% the joint center axes.
j1_valf = j1_val(:,k);
j2_valf = j2_val(:,k);

% if(axis==1)
%     axisName='X-axis';
% elseif(axis==2)
%     axisName='Y-axis';
% elseif(axis==3)
%     axisName='Z-axis';
% end

fprintf('\n');
withModification=0;
rmse = verifyCalbration(j1_valf,j2_valf,gyro_s_first,gyro_s_second,withModification);
fprintf(' Quality of Calibration Result: %f (close to zero is better) \n', rmse)
% withModification = 1;
% rmse = verifyCalbration(j1_valf,j2_valf,gyro_s_first,gyro_s_second,withModification);
% fprintf('%s: Quality of Calibration Result With Modifications: %f (close to zero is better) \n',axisName, rmse)

% pause(2);

%%%
% Plot the figure showing the conversion..
if showDataGraphs == 1
    figure; grid;hold on;
    plot( j1_val(1,1:k),'color',cc(1,:), 'LineWidth',2,'Marker', '*');
    plot( j1_val(2,1:k),'color',cc(2,:), 'LineWidth',2,'Marker', '*');
    plot( j1_val(3,1:k),'color',cc(3,:),'LineWidth',2,'Marker', '*');
    plot( j2_val(1,1:k),'color',cc(4,:),'LineWidth',2,'Marker', '*');
    plot( j2_val(2,1:k),'color',cc(5,:),'LineWidth',2,'Marker', '*');
    plot( j2_val(3,1:k),'color',cc(6,:),'LineWidth',2,'Marker', '*');
    title(sprintf('Joint Position Vector for Joint: %s and for Axis: %s\n',joint,axisName),'fontsize',16);
    hold off;
end



end

