%This is used to conver the spherical coordinate representation of the Knee
%Joint Position Vector to Vector again.
%Used in the calibration of the sensors
function [val] = jVal(phi, theta)
% as per the paper
% val = [cos(phi)*cos(theta); cos(phi)*sin(theta); sin(phi)];
% as per the wiki
% val = [sin(phi)*cos(theta); sin(phi)*sin(theta); cos(phi)];
% as per the wiki FLIPPED
val = [cos(phi); sin(phi)*sin(theta);sin(phi)*cos(theta)];