function [ HSShank_Optical, HSShank_Foot, HSFoot_Optical,...
    TOShank_Optical, TOShank_Foot, TOFoot_Optical] =...
    HSandTOSummary( HSFoot,TOFoot,HSShank,TOShank,HSOptical,TOOptical,isSynced, pathToSave )

HSShank_Optical=[];
HSShank_Foot=[];
HSFoot_Optical=[];
TOShank_Optical=[];
TOShank_Foot=[];
TOFoot_Optical=[];

dataPresent = 0;
if(~isempty(HSOptical))
    dataPresent = dataPresent+1;
end
if(~isempty(HSFoot))
    dataPresent = dataPresent+2;
end
if(~isempty(HSShank))
    dataPresent = dataPresent+4;
end

if(dataPresent < 2 || dataPresent ==1 || dataPresent == 2 || dataPresent ==4)
    disp('HSandTOSummary Error: There is not enough data to compare with. Aborting');
    return;
end
if(dataPresent >= 6)
    %% Shank and Foot Present
    minHSSize = min([max(size(HSShank)),max(size(HSFoot))]);
    HSShank = HSShank(1:minHSSize);
    HSFoot = HSFoot(1:minHSSize);
    
    minTOSize = min([max(size(TOShank)),max(size(TOFoot))]);
    TOShank = TOShank(1:minTOSize);
    TOFoot = TOFoot(1:minTOSize);
    
    % Self correction from the foot and the shank data.
    % Multiply by 10 to make it in ms
    HSShank_Foot = mean(abs(HSFoot - HSShank ))*10;
    TOShank_Foot = mean(abs(TOFoot - TOShank ))*10;
    
end
if(~isempty(isSynced))
    % some trickry can be used here
    
    
    if(dataPresent >= 3)
        % Optical and Foot
        [v i] = min(abs(HSFoot-min(HSOptical)));
        HSFoot(find(HSFoot < HSFoot(i)))=[];
        
        [v i] = min(abs(TOFoot-min(TOOptical)));
        TOFoot(find(TOFoot < TOFoot(i)))=[];
        
        
        minHSSize = min(max(size(HSFoot)),max(size(HSOptical)));
        HSFoot = HSFoot(1:minHSSize);
        HSOptical = HSOptical(1:minHSSize);
        
        minTOSize = min(max(size(TOFoot)),max(size(TOOptical)));
        TOFoot = TOFoot(1:minTOSize);
        TOOptical = TOOptical(1:minTOSize);
        
        HSFoot_Optical = mean(abs(HSFoot - HSOptical ))*10;
        TOFoot_Optical = mean(abs(TOFoot - TOOptical ))*10;
    end
    
    if(dataPresent >=5)
        % Optical and Shank
        
        [v i] = min(abs(HSShank-min(HSOptical)));
        HSShank(find(HSShank < HSShank(i)))=[];
        
        [v i] = min(abs(TOShank-min(TOOptical)));
        TOShank(find(TOShank < TOShank(i)))=[];
        
        minHSSize = min([max(size(HSShank)),max(size(HSOptical))]);
        HSShank = HSShank(1:minHSSize);
        HSOptical = HSOptical(1:minHSSize);
        
        minTOSize = min(max(size(TOShank)),max(size(TOOptical)));
        TOShank = TOShank(1:minTOSize);
        TOOptical = TOOptical(1:minTOSize);
        
        HSShank_Optical = mean(abs(HSShank - HSOptical ))*10;
        TOShank_Optical = mean(abs(TOShank - TOOptical ))*10;
    end
end

% writetable(HS,strcat(pathToSave,'HS.txt'),'Delimiter',',');
% writetable(TO,strcat(pathToSave,'TO.txt'),'Delimiter',',');
% writetable(HSError,strcat(pathToSave,'HSError.txt'),'Delimiter',',');
% writetable(AvgHSError,strcat(pathToSave,'AvgHSError.txt'),'Delimiter',',');
% writetable(TOError,strcat(pathToSave,'TOError.txt'),'Delimiter',',');
% writetable(AvgTOError,strcat(pathToSave,'AvgTOError.txt'),'Delimiter',',');
%%

end

