function  [HSFoot, TOFoot] = calHSandTOFootOnline( inputData )
%     disp('Custom Control on in onlineFindHSandTO');
%     testData = gyro_s_ankle(1,startDataPoint:endDataPoint)';

%% RUn it
showPlot=0;
% Setting the positive peakHeight and peakDistance in th graph
freq=100;
gyroT = 5;
maxPeakHeight = gyroT;
minPeakHeight = ceil(maxPeakHeight*0.2);
minPeakDistnace = ceil(freq/7);

sizeOfData = max(size(inputData));

HSFoot = [];
TOFoot = [];

prev=[];
for ti  = 1:sizeOfData
    curr = -inputData(ti);
    [isEvent, isHS, isTO ] = onlineFindHSandTOFoot(curr,prev, minPeakHeight,minPeakDistnace,maxPeakHeight,ti );
    
    if(isEvent)
        if(isHS)
            %                 if((max(size(HSFoot))<3))
            HSFoot = [HSFoot,ti-1];
            %                 end
        elseif(isTO)
            %                 if((max(size(TOFoot))<2) && ~isempty(HSFoot))
            if( ~isempty(HSFoot))
                TOFoot = [TOFoot,ti-1];
            end
        end
    end
    
    prev = curr;
end
%             plot([(ti-1),(ti-1)],ylim,'color','red', 'LineWidth',1);

if(showPlot)
    figure; hold on; grid on;
    plot(inputData,'linewidth',2,'color','black');
    
    for i=1:max(size(HSFoot))
        nextMinIdx = HSFoot(i);
        plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','blue','Marker', '.');
    end
    
    for i=1:max(size(TOFoot))
        nextMinIdx = TOFoot(i);
        plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','red','Marker', '.');
    end
    hold off;
    title('Online Heel Strike (Blue) and Toe off (Red)')
    %         pause;
end

end

