function [HSFoot, TOFoot] = heelStrikeToeOffShank(angluralRateXComp)
    
    %% Work Heel Strike and Toe Off
%     angluralRateXComp = gyro_s_shank(rawPeakIdx:end);
    showPlot = 0;
    freq=100;
    
    
    maxVal = max(angluralRateXComp);
    minVal = min(angluralRateXComp);
    avgVal = (maxVal)/2;
    
    gyroT = 5;
    minPeakHeight = gyroT;
    minPeakDistnace = ceil(freq/6);
    %     [posPeaks posPeaksIdx] = findpeaks(angluralRateXComp,'MinPeakHeight',minPeakHeight,'MinPeakDistance',minPeakDistnace);
    [posPeaks posPeaksIdx] = customFindPeaks(angluralRateXComp,minPeakHeight,minPeakDistnace);
    
    minPeakHeight = ceil(gyroT*0.2);
    minPeakDistnace = 1;
    %     [InvposPeaks InvposPeaksIdx] = findpeaks(-angluralRateXComp,'MinPeakHeight',minPeakHeight,'MinPeakDistance',minPeakDistnace);
    [InvposPeaks InvposPeaksIdx] = customFindPeaks(-angluralRateXComp,minPeakHeight,minPeakDistnace);
    
    heelStrikeAndToeOff = InvposPeaksIdx;
    HSFoot = [];
    TOFoot = [];
    
    % Min values between the valley
    for i=1:size(posPeaksIdx,2)-1
        val1 = posPeaksIdx(i);
        val2 = posPeaksIdx(i+1);
        [minVal minValIdx] = min(angluralRateXComp(val1:val2));
        
        minValIdx = minValIdx + val1;
        TOFoot = [TOFoot; minValIdx];
        
    end
    
    
    for i=1:size(posPeaksIdx,2)
        val = posPeaksIdx(i);
        nextMinIdx = heelStrikeAndToeOff(find((heelStrikeAndToeOff>=posPeaksIdx(i))==1,1));
        HSFoot = [HSFoot; nextMinIdx];
        
    end
    
    % BREAK CLAUSE HERE *******************88
%     HSFoot=HSFoot(2:end)';
%     TOFoot = TOFoot(2:end)';
HSFoot = HSFoot';
TOFoot = TOFoot';
    
    
    if(showPlot)
        figure; hold on; grid on;
        plot(angluralRateXComp,'linewidth',2,'color','black');
        
        for i=1:size(HSFoot,2)
            nextMinIdx = HSFoot(i);
            plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','blue','Marker', '.');
        end
        
        for i=1:size(TOFoot,2)
            nextMinIdx = TOFoot(i);
            plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','red','Marker', '.');
        end
        hold off;
        title('Heel Strike (Blue) and Toe off (Red)')
    end
end




