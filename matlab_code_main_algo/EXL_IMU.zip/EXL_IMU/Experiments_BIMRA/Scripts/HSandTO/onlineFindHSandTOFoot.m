function [isEvent, isHSv, isTOv ] = onlineFindHSandTOFoot(curr,prev, minPeakHeight,minPeakDistnace,maxPeakHeight,ti )
    
    %%
    global isIncreasing;
    global isNearby;
    global isHS;
    global isTO;
    global haveWeSeenaPeak;
    
    
    
    isEvent = 0;
    
    if(isempty(prev))
        isIncreasing=0;
        isNearby=0;
        isHS = 0;
        isTO = 0;
        haveWeSeenaPeak = 0;
        
        isHSv = isHS;
        isTOv = isTO;
        
        return;
    end
    
    
    if(isNearby > 0)
        isNearby = isNearby-1;
    end
    if(curr > prev)
        isIncreasing =1;
    end
    
    
    
    
    if(curr<prev && prev >= minPeakHeight && isIncreasing && (isNearby==0) &&(isHS || isTO))
        if(haveWeSeenaPeak)
            isIncreasing = 0;
            isNearby = minPeakDistnace;
            
            isEvent = 1;
            
            if(isHS)
                isTO=1;
                isHS = 0;
            elseif(isTO)
                isHS=1;
                isTO=0;
            end
            
            isHSv = isHS;
            isTOv = isTO;
            
            return;
            
            
            
        end
        
        
    end
    
    if(-prev < maxPeakHeight && (haveWeSeenaPeak==0))
%         fprintf('We just saw a peak at val %f\n',ti);
        haveWeSeenaPeak=1;
        
    end
    
    if(haveWeSeenaPeak)
        if(-curr > maxPeakHeight && isHS==0 && isTO==0)
            isTO = 1;
            
        end
    end
    
    isHSv = 0;
    isTOv = 0;
    
    
    
    
end

