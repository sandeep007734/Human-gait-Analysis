function [] = plotALignFigureCode(bimraRawData,imuRawData,fileName,saveImagesToFile,HSFoot,HSShank,HSOptical,plotDesc)
if(~isempty(bimraRawData) && ~isempty(imuRawData))
    alignFigure = figure();
    hold on; grid on;
    plot(bimraRawData,'color','black', 'LineWidth',2);
    plot(imuRawData,'color','blue', 'LineWidth',2);
    
%     
%     if(~isempty(HSFoot))
%         for hsfi = 1:max(size(HSFoot))
%             if(HSFoot(hsfi)<max(size(imuRawData)))
%                 plot( [HSFoot(hsfi), HSFoot(hsfi)],ylim,'color','blue', 'LineWidth',2);
%             end
%         end
%     end
%     
%     if(~isempty(HSShank))
%         for hssi = 1:max(size(HSShank))
%             if(HSShank(hssi)<max(size(imuRawData)))
%                 plot( [HSShank(hssi), HSShank(hssi)],ylim,'color','Red', 'LineWidth',2);
%             end
%         end
%     end
    
%     if(~isempty(HSOptical))
%         for hsoi = 1:max(size(HSOptical))
%             if(HSOptical(hsoi)<max(size(imuRawData)))
%                 plot( [HSOptical(hsoi), HSOptical(hsoi)],ylim,'color','Green', 'LineWidth',2);
%             end
%         end
%     end
    
    
    legend('Optical Data','IMU Data','Location','northeast');
    title(sprintf('Optical and IMU Data Alignment.\n File: %s Angle: %s \n', fileName,plotDesc),'FontSize',20);
    hold off;
    if(saveImagesToFile)
        saveFigToFile(pathToSave,'alignFigure', 'IMUOpticalDataAlign',alignFigure);
    end
end
end