function [  ] = plotFinalPlots( angle_joint_axes_aligned,kneeFlexionExtensionBIMRAAligned,heelStrikeFoot,...
        toeOffFoot,heelStrikeShank,toeOffShank,HSOptical,TOOptical,imuFileName, bimraFileName )
    
    %% run
%     
%     disp('Local settings in plotFinalPlots are enabled');
%     imuFileName = 'test';
%     bimraFileName = 'test';
    
    if(0)
        figure; grid on;hold on;
        plot( angle_joint_axes_aligned,'color','black', 'LineWidth',2,'Marker', '*');
        plot( kneeFlexionExtensionBIMRAAligned,'color','magenta', 'LineWidth',2,'Marker', '*');
        
        %From the Foot
        for i=1:size(heelStrikeFoot,2)
            nextMinIdx = heelStrikeFoot(i);
            %             plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','blue','Marker', '*');
            plot(nextMinIdx,angle_joint_axes_aligned(nextMinIdx),'linewidth',5,'color','blue','Marker', 's','MarkerSize',17);
        end
        
        for i=1:size(toeOffFoot,2)
            nextMinIdx = toeOffFoot(i);
            %             plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','red','Marker', '*');
            plot(nextMinIdx,angle_joint_axes_aligned(nextMinIdx),'linewidth',5,'color','blue','Marker', 'd','MarkerSize',17);
        end
        
        % From Shank
        for i=1:size(heelStrikeShank,1)
            nextMinIdx = heelStrikeShank(i);
            %                     plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','blue','Marker', '*');
            plot(nextMinIdx,angle_joint_axes_aligned(nextMinIdx),'linewidth',5,'color','red','Marker', 's','MarkerSize',15);
        end
        
        
        for i=1:size(toeOffShank,1)
            nextMinIdx = toeOffShank(i);
            %                     plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','red','Marker', '*');
            plot(nextMinIdx,angle_joint_axes_aligned(nextMinIdx),'linewidth',5,'color','red','Marker', 'd','MarkerSize',15);
        end
        
        if(HSOptical~=-1)
            % From the Optical System
            for i=1:size(HSOptical,2)
                nextMinIdx = HSOptical(i);
                %                     plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','red','Marker', '*');
                plot(nextMinIdx,angle_joint_axes_aligned(nextMinIdx),'linewidth',5,'color','green','Marker', 's','MarkerSize',13);
            end
            
            for i=1:size(TOOptical,2)
                nextMinIdx = TOOptical(i);
                %                     plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','blue','Marker', '*');
                plot(nextMinIdx,angle_joint_axes_aligned(nextMinIdx),'linewidth',5,'color','green','Marker', 'd','MarkerSize',13);
            end
        end
        
        %Graph Properties
        %    legend('Knee FL IMU','Knee FL BIMRA','Location','northeast');
        title(sprintf('Knee Flexion extension angle HS and TO.\n IMU file: %s, BIMRA File:%s ',imuFileName, bimraFileName)...
            ,'FontSize',20);
        xlabel('Timestamp (100 = 1sec)','fontsize',20);
        ylabel('Knee Joint Angle (deg)','fontsize',20);
        set(gca,'fontsize',20);
        
        hold off;
    end
    % ======================================================
    
    if(HSOptical~=-1)
        disp('plotFinalPlots: HSOptical Data is present, calculating the limit using it.');
        startIdx = max(1,min([min(HSOptical),min(TOOptical),min(heelStrikeFoot),min(toeOffFoot),min(heelStrikeShank),min(toeOffShank)])-1);
        endIdx = min([max(HSOptical),max(TOOptical),max(heelStrikeFoot),max(toeOffFoot),max(heelStrikeShank),max(toeOffShank)])-1;
    else
        disp('plotFinalPlots: HSOptical Data is missing, calculating the limit without it.');
        startIdx = max(1,min([min(heelStrikeFoot),min(toeOffFoot),min(heelStrikeShank),min(toeOffShank)])-1);
        endIdx = min([max(heelStrikeFoot),max(toeOffFoot),max(heelStrikeShank),max(toeOffShank)])-1;
    end
    fprintf('Start and End Indices are as follows: %d %d\n',startIdx, endIdx);
    
    
    
    heelStrikeFoot(find(heelStrikeFoot>endIdx))=[];
    toeOffFoot(find(toeOffFoot>endIdx))=[];
    heelStrikeShank(find(heelStrikeShank<endIdx))=[];
    toeOffShank(find(toeOffShank>endIdx))=[];
    
    if(HSOptical~=-1)
        HSOptical(find(HSOptical>endIdx))=[];
        TOOptical(find(TOOptical>endIdx))=[];
    end
    
    heelStrikeFoot = heelStrikeFoot-startIdx;
    toeOffFoot = toeOffFoot-startIdx;
    heelStrikeShank = heelStrikeShank-startIdx;
    toeOffShank=toeOffShank-startIdx;
    if(HSOptical~=-1)
        HSOptical=HSOptical-startIdx;
        TOOptical=TOOptical-startIdx;
    end
    
    angleCropped = angle_joint_axes_aligned(startIdx:endIdx);
    
    figure; grid on;hold on;
    plot( angleCropped,'color','black', 'LineWidth',2,'Marker', '*');
    if(HSOptical~=-1)
        plot( kneeFlexionExtensionBIMRAAligned(startIdx:endIdx),'color','magenta', 'LineWidth',2,'Marker', '*');
    end
    
    %% From the Foot
    for i=1:size(heelStrikeFoot,2)
        nextMinIdx = heelStrikeFoot(i);
        %             plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','blue','Marker', '*');
        if(nextMinIdx<size(angleCropped,2))
        plot(nextMinIdx,angleCropped(nextMinIdx),'linewidth',5,'color','blue','Marker', 's','MarkerSize',17);
        end
    end
    
    for i=1:size(toeOffFoot,2)
        nextMinIdx = toeOffFoot(i);
        %             plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','red','Marker', '*');
         if(nextMinIdx<size(angleCropped,2))
        plot(nextMinIdx,angleCropped(nextMinIdx),'linewidth',5,'color','blue','Marker', 'd','MarkerSize',17);
         end
    end
    
    % From Shank
    for i=1:size(heelStrikeShank,2)
        nextMinIdx = heelStrikeShank(i);
        %                     plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','blue','Marker', '*');
         if(nextMinIdx<size(angleCropped,2))
        plot(nextMinIdx,angleCropped(nextMinIdx),'linewidth',5,'color','red','Marker', 's','MarkerSize',15);
         end
    end
    
    
    for i=1:size(toeOffShank,2)
        nextMinIdx = toeOffShank(i);
        %                     plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','red','Marker', '*');
         if(nextMinIdx<size(angleCropped,2))
        plot(nextMinIdx,angleCropped(nextMinIdx),'linewidth',5,'color','red','Marker', 'd','MarkerSize',15);
         end
    end
    
    % From the Optical System
    if(HSOptical~=-1)
        for i=1:size(HSOptical,2)
            nextMinIdx = HSOptical(i);
            %                     plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','red','Marker', '*');
            plot(nextMinIdx,angleCropped(nextMinIdx),'linewidth',5,'color','green','Marker', 's','MarkerSize',13);
        end
        
        for i=1:size(TOOptical,2)
            nextMinIdx = TOOptical(i);
            %                     plot([nextMinIdx,nextMinIdx],ylim,'linewidth',2,'color','blue','Marker', '*');
            plot(nextMinIdx,angleCropped(nextMinIdx),'linewidth',5,'color','green','Marker', 'd','MarkerSize',13);
        end
    end
    
    %Graph Properties
    %    legend('Knee FL IMU','Knee FL BIMRA','Location','northeast');
    title(sprintf('Knee Flexion extension angle HS and TO.\n IMU file: %s, BIMRA File:%s ',imuFileName, bimraFileName)...
        ,'FontSize',20);
    xlabel('Timestamp (100 = 1sec)','fontsize',20);
    ylabel('Knee Joint Angle (deg)','fontsize',20);
    set(gca,'fontsize',20);
    hold off;
    
    % TODO How to add it ?
    %     bimraAvgData = (kneeFlexionExtensionBIMRAAligned(HSOptical(1):HSOptical(2))+kneeFlexionExtensionBIMRAAligned(HSOptical(2):HSOptical(3)))/2;
    
    
    
end

