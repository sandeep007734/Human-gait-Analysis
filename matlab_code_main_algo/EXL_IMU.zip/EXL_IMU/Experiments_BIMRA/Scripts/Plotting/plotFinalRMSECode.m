%%%

[ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure, rmse_rkfe_noOffset,rmse_rkfe_Offset ] =...
    showAndPlotFinalResult( avgRightKneeFE, avgacRKFE,[],[], ...
    num,bimraFiles,rightThighDataFiles,'Right Knee Flexion Extension',plotFinalRMSE );
if(saveImagesToFile)
    desc ='Knee';
    saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
    saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
    saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
end

[ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure, rmse_rkaa_noOffset,rmse_rkaa_Offset ] = ...
    showAndPlotFinalResult( avgRightKneeAA, avgacRKAA, [], [], ...
    num,bimraFiles,rightThighDataFiles,'Right Knee Abduction Adduction',plotFinalRMSE );
if(saveImagesToFile)
    desc ='QRKAA';
    saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
    saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
    saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
end

[ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure, rmse_rkie_noOffset,rmse_rkie_Offset ] = ...
    showAndPlotFinalResult( avgRightKneeIE, avgacRKIE, [], [], ...
    num,bimraFiles,rightThighDataFiles,'Right Knee Interior Exterior Rotation',plotFinalRMSE );
if(saveImagesToFile)
    desc ='QRKIE';
    saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
    saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
    saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
end

%% HIP

[ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure, rmse_rhpfe_noOffset,rmse_rhpfe_Offset ] = ...
    showAndPlotFinalResult( avgRightHipFE, avgacRHPFE, [], [], ...
    num,bimraFiles,rightThighDataFiles,'Right Hip Flexion Extension',plotFinalRMSE );
if(saveImagesToFile)
    desc ='QRKIE';
    saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
    saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
    saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
end



[ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure, rmse_rhpaa_noOffset,rmse_rhpaa_Offset ] = ...
    showAndPlotFinalResult( avgRightHipAA, avgacRHPAA, [], [], ...
    num,bimraFiles,rightThighDataFiles,'Right Hip Abduction Adduction',plotFinalRMSE );
if(saveImagesToFile)
    desc ='QRKIE';
    saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
    saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
    saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
end

%% Foot result summary


[ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure,rmse_radp_noOffset,rmse_radp_Offset ] = ...
    showAndPlotFinalResult( avgRightAnkleDP, avgacRAFE, [], [], ...
    num,bimraFiles,rightThighDataFiles,'Right Ankle Dorsi Plantarflex',plotFinalRMSE );
if(saveImagesToFile)
    desc ='Foot';
    saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
    saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
    saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
end

[ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,finalCompareOffsetCorrectFigure,rmse_raie_noOffset,rmse_raie_Offset ] = ...
    showAndPlotFinalResult( avgRightAnkleIE, avgacRAIE, [], [], ...
    num,bimraFiles,rightThighDataFiles,'Right Ankle Internal Rotation',plotFinalRMSE );
if(saveImagesToFile)
    desc ='Foot';
    saveFigToFile(pathToSave,'finalCompareNoOffsetCorrectFigure', desc,finalCompareNoOffsetCorrectFigure);
    saveFigToFile(pathToSave,'avgImuDataFigure', desc,avgImuDataFigure);
    saveFigToFile(pathToSave,'finalCompareOffsetCorrectFigure', desc,finalCompareOffsetCorrectFigure);
end