% function [] = plotGraphs(angle_FE,angle_FE2,angle_rot_mat,angle_joint_axes,angle_joint_centre,angle_FE3, plots,filename1)
function [] = plotGraphs(angle_rot_mat,angle_joint_axes,angle_joint_centre, plots,filename1)
    
    cc = hsv(6);
    
%     if plots(1) == 1
%         figure;grid on;hold on;
%         plot( angle_FE,'color','black', 'LineWidth',2,'Marker', '*');
%         title(sprintf('angle FE For the File %s',filename1),'fontsize',20);
%         xlabel('Timestamp','fontsize',20);
%         ylabel('Knee Joint Angle','fontsize',20);
%         set(gca,'fontsize',20);
%     end
%     
%     if plots(2) == 1
%         figure;grid on;hold on;
%         plot( angle_FE2,'color','black', 'LineWidth',2,'Marker', '*');
%         title(sprintf('angle FE2 For the File %s',filename1),'fontsize',20);
%         xlabel('Timestamp','fontsize',20);
%         ylabel('Knee Joint Angle','fontsize',20);
%         set(gca,'fontsize',20);
%     end
    
    if plots(3) == 1
        figure; grid on;hold on;
        plot( angle_rot_mat,'color','black', 'LineWidth',2,'Marker', '*');
        title(sprintf('Rotation Matrix (Orientation) for the File %s',filename1),'fontsize',20);
        xlabel('Timestamp','fontsize',20);
        ylabel('Knee Joint Angle','fontsize',20);
        set(gca,'fontsize',20);
    end
    
    if plots(4) == 1
        figure; grid on;hold on;
        plot( angle_joint_axes,'color','black', 'LineWidth',2,'Marker', '*');
        title(sprintf('Joint Axes (Gyroscope) for the File %s',filename1),'fontsize',20);
        xlabel('Timestamp','fontsize',20);
        ylabel('Knee Joint Angle','fontsize',20);
        set(gca,'fontsize',20);
    end
    
    if plots(5) == 1
        figure; grid on;hold on;
        plot( angle_joint_centre,'color','black', 'LineWidth',2,'Marker', '*');
        title(sprintf('Joint Center (Accelrometer) for the File %s',filename1),'fontsize',20);
        xlabel('Timestamp','fontsize',20);
        ylabel('Knee Joint Angle','fontsize',20);
        set(gca,'fontsize',20);
    end
    
%     if plots(6) == 1
%         figure; grid on;hold on;
%         plot( angle_FE3,'color','black', 'LineWidth',2,'Marker', '*');
%         title(sprintf('angle FE3 for the File %s',filename1),'fontsize',20);
%         xlabel('Timestamp','fontsize',20);
%         ylabel('Knee Joint Angle','fontsize',20);
%         set(gca,'fontsize',20);
%     end
    
%     for hsto=1:size(heelStrikeandToeff,2)
%         x1 = heelStrikeandToeff(hsto);
%         plot([x1,x1],ylim,'linewidth',2,'color','red');
%     end
%     hold off;
%     
