heelStrikeFig = figure();
hold on; grid on;
plot( imuRightKneeFE,'color','black', 'LineWidth',2);

if(~isempty(HSFoot))
    for hsfi = 1:max(size(HSFoot))
        plot( [HSFoot(hsfi), HSFoot(hsfi)],ylim,'color','blue', 'LineWidth',2);
    end
end

if(~isempty(HSShank))
    for hssi = 1:max(size(HSShank))
        plot( [HSShank(hssi), HSShank(hssi)],ylim,'color','Red', 'LineWidth',2);
    end
end

if(~isempty(HSOptical))
    for hsoi = 1:max(size(HSOptical))
        plot( [HSOptical(hsoi), HSOptical(hsoi)],ylim,'color','Green', 'LineWidth',2);
    end
end
title(sprintf('Heel Strike on Graphs. File: %s \n Foot:Blue Shank:Red Optical:Green',char(rightThighDataFiles(num,:))),...
    'fontsize',20);
hold off;
if(saveImagesToFile)
    saveFigToFile(pathToSave,'heelStrike', 'Heel Strikes',heelStrikeFig);
end
