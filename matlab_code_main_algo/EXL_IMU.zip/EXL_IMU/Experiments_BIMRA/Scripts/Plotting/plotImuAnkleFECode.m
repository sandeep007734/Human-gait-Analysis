if(~isempty(imuRightAnkleFE))
    imuAnkleFigure=figure; grid on;hold on;
    plot( imuRightAnkleFE,'color','black', 'LineWidth',2);
    title(sprintf('Ankle Flexion Extension. File: %s', rightThighDataFiles(num,:)),'FontSize',20);
    hold off;
    if(saveImagesToFile)
        saveFigToFile(pathToSave,'imuAnkleFigure', 'IMUAnkleFE',imuAnkleFigure);
    end
end
