if(~isempty(imuRightKneeAA))
    imuKneeAAFigure=figure; grid on;hold on;
    plot( imuRightKneeAA,'color','black', 'LineWidth',2);
    title(sprintf('Knee Abduction Adduction. File: %s', rightThighDataFiles(num,:)),'FontSize',20);
    hold off;
    if(saveImagesToFile)
        saveFigToFile(pathToSave,'imuKneeAAFigure', 'IMUKneeAA',imuKneeAAFigure);
    end
end
