if(~isempty(imuRightKneeFE))
    imuKneeFEFigure=figure; grid on;hold on;
    plot( imuRightKneeFE,'color','black', 'LineWidth',2);
    title(sprintf('Knee Flexion Extension. File: %s', rightThighDataFiles(num,:)),'FontSize',20);
    hold off;
    if(saveImagesToFile)
        saveFigToFile(pathToSave,'imuKneeFEFigure', 'IMUKneeFE',imuKneeFEFigure);
    end
end
