if(~isempty(imuRightKneeIE))
    imuKneeIEFigure=figure; grid on;hold on;
    plot( imuRightKneeIE,'color','black', 'LineWidth',2);
    title(sprintf('Knee Iternal External. File: %s', rightThighDataFiles(num,:)),'FontSize',20);
    hold off;
    if(saveImagesToFile)
        saveFigToFile(pathToSave,'imuKneeIEFigure', 'IMUKneeIE',imuKneeIEFigure);
    end
end
