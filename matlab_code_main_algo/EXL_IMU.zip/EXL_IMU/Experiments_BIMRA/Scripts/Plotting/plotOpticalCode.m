bimradataFig = figure();
grid on;
hold on;
plot( jrkDataZ,'color','black', 'LineWidth',2);
legendstr='jrkDataZ';

for i=1:size(HSOptical,2)
    plot([HSOptical(i),HSOptical(i)],ylim,'color','red', 'LineWidth',2);
    legendstr = char(legendstr,strcat('Heel Strike ',num2str(i)));
end

for i=1:size(TOOptical,2)
    plot([TOOptical(i),TOOptical(i)],ylim,'color','blue', 'LineWidth',2);
    legendstr = strvcat(legendstr,strcat('Toe Off ',num2str(i)));
end


if(isempty(opticalMarkerIdx))
    title(sprintf('jrkDataZ plot for BIMRA file name: %s\n Folder: %s\n Peak is missing in Optical data',...
        bimraFiles(num,:),bimraFolder),'fontsize',16);
else
    plot([opticalMarkerIdx,opticalMarkerIdx],ylim,'color','green', 'LineWidth',2);
    legendstr = strvcat(legendstr,strcat('Marker ',num2str(i)));
    title(sprintf('jrkDataZ plot for BIMRA file name: %s\n Folder: %s\n Peak is present in Optical data',...
        bimraFiles(num,:),bimraFolder),'fontsize',16);
end
legend(legendstr,'Location','northeast');
hold off;

saveFigToFile(pathToSave,'bimradataFig', 'Optical Data',bimradataFig);