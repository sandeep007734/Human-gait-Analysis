 toeOffFig = figure();
        hold on; grid on;
        
        plot( imuRightKneeFE(1,:),'color','black', 'LineWidth',2);
        %             plot( angle_joint_axes_aligned,'color','blue', 'LineWidth',2);
        if(rightFootDataPresent)
            if(size(TOFoot,1)>0)
                for hsfi = 1:size(TOFoot,2)
                    plot( [TOFoot(hsfi), TOFoot(hsfi)],ylim,'color','blue', 'LineWidth',2);
                end
            end
        end
        
        if(size(TOShank,1)>0)
            for hssi = 1:size(TOShank,2)
                plot( [TOShank(hssi), TOShank(hssi)],ylim,'color','Red', 'LineWidth',2);
            end
        end
        
        if(~isempty(TOOptical))
            for hsoi = 1:size(TOOptical,2)
                plot( [TOOptical(hsoi), TOOptical(hsoi)],ylim,'color','Green', 'LineWidth',2);
            end
        end
        title(sprintf('Toe off on Graphs. File: %s \n Foot:Blue Shank:Red Optical:Green',char(rightThighDataFiles(num,:))),'fontsize',20);
        hold off;
        saveFigToFile(pathToSave,'toeOffFig', 'Toe Offs in Data',toeOffFig);
