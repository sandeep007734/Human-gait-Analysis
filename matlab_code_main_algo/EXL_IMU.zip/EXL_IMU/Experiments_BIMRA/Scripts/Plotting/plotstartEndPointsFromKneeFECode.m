 startEndPointsFromKneeFEFig = figure; grid on;hold on;
%         plot( imuRightKneeFE,'color','black', 'LineWidth',2);
        plot( gyro_s_foot(1,:),'color','black', 'LineWidth',2);
        plot([startDataPoint,startDataPoint],ylim,'color','red', 'LineWidth',2);
        plot([imuMarkerIdx,imuMarkerIdx],ylim,'color','green', 'LineWidth',2);
        plot([endDataPoint,endDataPoint],ylim,'color','red', 'LineWidth',2);
        legend('Input Data','Start Point','Peak', 'End Point','Location','northeast');
        title(sprintf('Knee FE\nStart, Peak and End Limit of the Data. File: %s', char(rightThighDataFiles(num,:))),'FontSize',20);
        hold off;
        
        saveFigToFile(pathToSave,'startEndPointsFromKneeFEFig', 'PeakinRightKneeFE',startEndPointsFromKneeFEFig);
