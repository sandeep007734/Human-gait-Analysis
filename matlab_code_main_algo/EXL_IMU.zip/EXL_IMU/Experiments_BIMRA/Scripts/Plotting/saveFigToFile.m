function [  ] = saveFigToFile(pathToSave,filename, desc,figureToSave);
    
    if(isempty(figureToSave))
%         disp('Cannot save an empty image');
        return;
    end
    if(exist(pathToSave,'dir')== 0)
        mkdir(pathToSave);
    end
    saveas(figureToSave,strcat(pathToSave,desc,'_',filename,'.jpg'));
    
    
    %     if(finalCompareOffsetCorrect~=-1)
    %         saveas(finalCompareOffsetCorrect,strcat(pathToSave,'_',vname(finalCompareOffsetCorrect)),'jpg');
    %     end
    %     if(finalCompareNoOffsetCorrect~=-1)
    %         saveas(finalCompareNoOffsetCorrect,strcat(pathToSave,'_final_compare_no_offset_correction.jpg'),'jpg');
    %     end
    %     if(bimradataFig~=-1)
    %         saveas(bimradataFig,strcat(pathToSave,'_bimra_data.jpg'),'jpg');
    %     end
    %     if(avgImuDataFig~=-1)
    %         saveas(avgImuDataFig,strcat(pathToSave,'_avg_imu.jpg'),'jpg');
    %     end
    %     if(heelStrike~=-1)
    %         saveas(heelStrike,strcat(pathToSave,'_heel_strike.jpg'),'jpg');
    %     end
    %     if(startAndEndPoints~=-1)
    %         saveas(startAndEndPoints,strcat(pathToSave,'_start_and_end_points.jpg'),'jpg');
    %     end
    
    
end

