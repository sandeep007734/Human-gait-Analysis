function [ finalCompareNoOffsetCorrectFigure,avgImuDataFigure,...
    finalCompareOffsetCorrectFigure, rmseNoOffsetCorrection, rmseOffsetCorrection ]...
    = showAndPlotFinalResult( avgIMUData, avgBIMRArawData, avgacBIMRAData, acmBIMRAData,...
    num,bimraFile,imuDataFile,desc,plotFinalRMSE )

%% Setting up
finalCompareNoOffsetCorrectFigure=[];
avgImuDataFigure=[];
finalCompareOffsetCorrectFigure=[];
rmseNoOffsetCorrection = [];
rmseOffsetCorrection = [];

opticalDataPresent=1;

%% WE need a valid IMU data otherwise there is no point in going forward.
if(isempty(avgIMUData))
    fprintf('showAndPlotFinalResult: Invalid IMU Data for %s . Aborting\n',desc);
    return;
end

showWithoutOffset = 0;
if(showWithoutOffset)
    minRMSE = [];
    %% Calculat the RMSE base on the data present
    fprintf('RMSE between the JRK and the IMU data before height Adjustment\n');
    if(~isempty(avgBIMRArawData))
        minRMSE = calcRMSE(avgIMUData,avgBIMRArawData);
        fprintf('RMSE Average IMU and Average Optical Raw \n%s %f\n',desc,minRMSE);
    elseif(~isempty(avgacBIMRAData))
        minRMSE = calcRMSE(avgIMUData,avgacBIMRAData);
        fprintf('RMSE Average IMU and Average Optical \n%s %f\n',desc,minRMSE);
    elseif(~isempty(acmBIMRAData))
        minRMSE = calcRMSE(avgIMUData,acmBIMRAData);
        fprintf('RMSE Average IMU and Mean\n Optical \n%s %f\n',desc,minRMSE);
    else
        disp('No Optical Data. RMSE cannot be calculated');
        opticalDataPresent=0;
    end
    
    rmseNoOffsetCorrection = minRMSE;
    %% Plot the most relevant plot, and the RMSE asscoiated. The offsets are not corrected
    if(plotFinalRMSE)
        finalCompareNoOffsetCorrectFigure = figure();
        grid on;
        hold on;
        plot( avgIMUData,'color','blue', 'LineWidth',2);
        %     if(opticalDataPresent)
        if(~isempty(avgBIMRArawData))
            plot( avgBIMRArawData,'color','black', 'LineWidth',2);
            title(sprintf('%s\n No Offset Correction. IMU vs Optical Raw\n BIMRA Filename: %s\n IMU Filename: %s \n RMSE is %.1f degrees',...
                desc,bimraFile(num,:),imuDataFile(num,:),minRMSE),'fontsize',20);
            legend('IMU','Optical Raw','Location','northeast');
        elseif(~isempty(avgacBIMRAData))
            plot( avgacBIMRAData,'color','black', 'LineWidth',2);
            title(sprintf(' %s\nNo Offset Correction. IMU vs Optical Average\n BIMRA Filename: %s\n IMU Filename: %s\n RMSE is %.1f degrees',...
                desc,bimraFile(num,:),imuDataFile(num,:),minRMSE),'fontsize',20);
            legend('IMU','Optical Average','Location','northeast');
        elseif(~isempty(acmBIMRAData))
            plot( acmBIMRAData,'color','black', 'LineWidth',2);
            title(sprintf(' %s\nNo Offset Correction. IMU vs Optical Mean\n BIMRA Filename: %s\n IMU Filename: %s\n RMSE is %.1f degrees',...
                desc,bimraFile(num,:),imuDataFile(num,:),minRMSE),'fontsize',20);
            legend('IMU','Optical Mean','Location','northeast');
        else
            title(sprintf('%s\nNo Optical Data Present IMU Filename: %s\n',desc,char(imuDataFile(num,:))),'fontsize',20);
            legend('IMU','Location','northeast');
        end
        
        hold off;
    end
    
end
%% Correct OffSet
% This is needed to match the starting point of the data from both
% of the sensors.

%TODO: Find a justification regarding why this is happening.
% This is happening because in the Optical system before the
% walking trials a standing trail is done, in which the person just
% stands. This calculates the baseline of the user. Like what is
% the Flexion Extension angle when the person is standing and it is
% then used as the baseline for the concurrent walking trials.
% Well this is just a theory. May be there is some other
% explanation.


fprintf('RMSE between the JRK and the IMU data after height Adjustment\n');
if(~isempty(avgBIMRArawData))
    [ avgIMUData, avgBIMRArawData, minRMSE ] = adjustHeight( avgIMUData, avgBIMRArawData );
    fprintf('RMSE Average IMU and Average Optical Raw \n%s %f\n',desc,minRMSE);
elseif(~isempty(avgacBIMRAData))
    [ avgIMUData, avgacBIMRAData, minRMSE ] = adjustHeight( avgIMUData, avgacBIMRAData );
    fprintf('RMSE Average IMU and Average Optical \n%s %f\n',desc,minRMSE);
elseif(~isempty(acmBIMRAData))
    [ avgIMUData, acmBIMRAData, minRMSE ] = adjustHeight( avgIMUData, acmBIMRAData );
    fprintf('RMSE Average IMU and Mean Optical \n%s %f\n',desc,minRMSE);
else
    disp('No Optical data present. No Offset correction is needed. Aborting');
    opticalDataPresent=0;
    minRMSE=[];
    %     return;
end
rmseOffsetCorrection = minRMSE;

%% Plot the data and the RMSE with offset correction.

if(plotFinalRMSE)
    finalCompareOffsetCorrectFigure = figure();
    grid on;
    hold on;
    plot( avgIMUData,'color','blue', 'LineWidth',2);
    if(~isempty(avgBIMRArawData))
        plot( avgBIMRArawData,'color','black', 'LineWidth',2);
        title(sprintf('%s\n Offset Correction. IMU vs Optical Raw\n BIMRA Filename: %s\n IMU Filename: %s \n RMSE is %.1f degrees',...
            desc,bimraFile(num,:),imuDataFile(num,:),minRMSE),'fontsize',20);
        legend('IMU','Optical Raw','Location','northeast');
    elseif(~isempty(avgacBIMRAData))
        plot( avgacBIMRAData,'color','black', 'LineWidth',2);
        title(sprintf(' %s\n Offset Correction. IMU vs Optical Average\n BIMRA Filename: %s\n IMU Filename: %s\n RMSE is %.1f degrees',...
            desc,bimraFile(num,:),imuDataFile(num,:),minRMSE),'fontsize',20);
        legend('IMU','Optical Average','Location','northeast');
    elseif(~isempty(acmBIMRAData))
        plot( acmBIMRAData,'color','black', 'LineWidth',2);
        title(sprintf(' %s\n Offset Correction. IMU vs Optical Mean\n BIMRA Filename: %s\n IMU Filename: %s\n RMSE is %.1f degrees',...
            desc,bimraFile(num,:),imuDataFile(num,:),minRMSE),'fontsize',20);
        legend('IMU','Optical Mean','Location','northeast');
    else
        title(sprintf('%s\n Optical Data Present IMU Filename: %s\n',desc,imuDataFile(num,:)),'fontsize',20);
        legend('IMU','Location','northeast');
    end
    
    hold off;
end


end


