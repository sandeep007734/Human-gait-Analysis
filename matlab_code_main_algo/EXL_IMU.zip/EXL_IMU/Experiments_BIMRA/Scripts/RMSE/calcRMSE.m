function [ RMSE ] = calcRMSE( y, yhat)
    RMSE = sqrt(mean((y - yhat).^2));  % Root Mean Squared Error
    
end

