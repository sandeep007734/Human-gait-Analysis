% This function is used during the mesh creation. It is used to calculate
% the Square summation error for a particular jval.
function[squareSummation] = calcSSE(gyro_s_knee,gyro_s_shank,phi1_val,theta1_val,phi2_val,theta2_val)
    %% CALC
   
    % Arguments for which the funcions need to be minimized. Ψ(φ1,φ2, θ1, θ2)
    syms phi1 theta1 phi2 theta2;
    
    %%%
    % The spherical coordinates representation of the j1 and j2
    j1 = [cos(phi1)*cos(theta1); cos(phi1)*sin(theta1); sin(phi1)];
    j2 = [cos(phi2)*cos(theta2); cos(phi2)*sin(theta2); sin(phi2)];
    
    %%%
    % The angluar velocity split into its x,y and z coordinates
    syms g1x g1y g1z g2x g2y g2z;
    g1 = [g1x; g1y; g1z];
    g2 = [g2x; g2y; g2z];
    
    l1 = cross(g1, j1);
    l2 = cross(g2, j2);
    %%%
    % Normalizing over the all the axes.
%     norm_l1 = sqrt( (l1(1,1)^2) + (l1(2,1)^2) + (l1(3,1)^2) );
%     norm_l2 = sqrt( (l2(1,1)^2) + (l2(2,1)^2) + (l2(3,1)^2) );
%     e = norm_l1 - norm_l2;

    e = norm(l1)-norm(l2);
    x_val = [phi1_val; theta1_val; phi2_val; theta2_val];

    squareSummation = 0;
    for i=1:size(gyro_s_knee,2)
        g1_val = gyro_s_knee(:,i);
        g2_val = gyro_s_shank(:,i);
        
        e_val = calib_calc_e(x_val(1), x_val(2), x_val(3), x_val(4),...
            g1_val(1), g1_val(2), g1_val(3),...
            g2_val(1), g2_val(2), g2_val(3));
        
        squareSummation = squareSummation + e_val^2;    
    end
    
    squareSummation = squareSummation/size(gyro_s_knee,2);
    squareSummation = sqrt(squareSummation);
    
% squareSummation
    
    