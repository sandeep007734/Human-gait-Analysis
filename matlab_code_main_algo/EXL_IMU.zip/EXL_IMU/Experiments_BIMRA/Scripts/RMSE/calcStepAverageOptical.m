function [ avgacrkfe ] = calcStepAverageOptical( data,HSOptical )

%% Run it

% data = structMdxData.acrafe;
% HSOptical = structMdxData.HSOptical;

if(isempty(data))
    avgacrkfe = [];
    return;
end
if(size(data,2)==203)
     firstStep = data(1:101);
    secondStep = data(103:203);
    
    avgStep = (firstStep+secondStep)/2;
    avgacrkfe = avgStep;
elseif(size(data,2)==202)
    firstStep = data(1:(find(data==0)-1));
    secondStep = data(find(data==0)+1:end);
    
    %need to pad zeros to the smaller on
    diff = size(firstStep,2) - size(secondStep,2);
    if(diff < 0)
        firstStep = interpolateData(firstStep,size(secondStep,2));
    elseif (diff >0)
        secondStep = interpolateData(secondStep,size(firstStep,2));
        
    end
    avgStep = (firstStep+secondStep)/2;
    avgacrkfe = avgStep;
else
    avgacrkfe=[];
end
%         if(max(size(avgacrkfe))~=101)
% avgacrkfe = interpolateData(avgacrkfe,100);

%         end
end

