function [ avgFEJrk ] = calcStepAverageRaw( data,HSOptical )
    %%
    if(isempty(data))
        avgFEJrk = [];
        return;
    end
    
    if(size(HSOptical,2)==3)
        
        firstStepJrk = data(HSOptical(1):HSOptical(2));
        secondStepJrk = data(HSOptical(2):HSOptical(3));
        
        firstStepJrk = interpolateData(firstStepJrk,101);
        secondStepJrk = interpolateData(secondStepJrk,101);
        
        avgFEJrk = (firstStepJrk+secondStepJrk)/2;
        
    elseif(size(HSOptical,2)==2)
        avgFEJrk = data(HSOptical(1):HSOptical(2));
    end
    
    if(max(size(avgFEJrk))~=101)
        avgFEJrk = interpolateData(avgFEJrk,101);
    end
end

