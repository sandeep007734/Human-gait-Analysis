function [ avgDataasHellStrike ] = calcuateAverageIMUData( inputData, HSData )
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here

if(isempty(inputData))
    avgDataasHellStrike = [];
    return;
end

if(1==2)
    inputData=imuRightKneeFE;
    HSData = HSFoot;
end

standardStepSize=101;
if(size(HSData,2)>3)
    HSData=HSData(1:3);
end
if(size(HSData,2)==3)
    
    firstStepKneeFE = inputData(HSData(1):HSData(2));
    secondStepKneeFE = inputData(HSData(2):HSData(3));
    
    if(isempty(firstStepKneeFE) || isempty(firstStepKneeFE))
        avgDataasHellStrike = [];
        return;
    end
    
    firstStepKneeFE = interpolateData(firstStepKneeFE,standardStepSize);
    secondStepKneeFE = interpolateData(secondStepKneeFE,standardStepSize);
    firstStepKneeFE = interpolateData(firstStepKneeFE,standardStepSize);
    secondStepKneeFE = interpolateData(secondStepKneeFE,standardStepSize);
    
    firstStepKneeFE = firstStepKneeFE(1:standardStepSize);
    secondStepKneeFE = secondStepKneeFE(1:standardStepSize);
    
    avgDataasHellStrike = (firstStepKneeFE+secondStepKneeFE)/2;
    
    % Make the average step from the two systems of the same length.
    
    avgDataasHellStrike = interpolateData(avgDataasHellStrike,standardStepSize);
    
else
    disp('There are too less many Heel Strikes')
    avgDataasHellStrike=[];
    return;
    %             TODO CHECK THIS
end

end

