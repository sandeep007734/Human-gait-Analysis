function [ outData1, outData2, minRMSE ] = adjustHeight( inpData1, inpData2 )

    
    avg1 = mean(inpData1);
    avg2 = mean(inpData2);
    
    diff = abs(avg1-avg2);
    if(avg1 > avg2)
        outData1 = inpData1;
        outData2 = inpData2+diff;
    else
        outData1 = inpData1+diff;
        outData2 = inpData2;
    end
    
    minRMSE = sqrt(mean((outData1-outData2).^2));
    
    
%     if(size(inpData1,2) > 101)
%         inpData1 = inpData1(1:101);
%     end
%     
%     if(size(inpData2,2) > 101)
%         inpData2 = inpData2(1:101);
%     end
%     
%     if((sum((inpData1 == -1))>0) || (sum((inpData2 == -1))>0))
%         outData1 = inpData1;
%         outData2 = inpData2;
%         minRMSE=-1;
%         return;
%     end
%     
%     maxOne = max(inpData1);
%     maxTwo = max(inpData2);
%     
%     diff = abs(maxTwo-maxOne);
%     mtrx = -diff:(.1*diff):(diff);
%     rmses = zeros(size(mtrx));
%     
%     if(maxOne < maxTwo)
%         for i=1:size(mtrx,2)
%             rmses(i) = sqrt(mean(((inpData1+mtrx(i))-inpData2).^2));
%         end
%         [minRMSE, minRMSEIdx] = min(rmses);
%         outData1 = inpData1+mtrx(minRMSEIdx);
%         outData2 = inpData2;
%     else
%         for i=1:size(mtrx,2)
%             rmses(i) = sqrt(mean(((inpData2+mtrx(i))-inpData1).^2));
%         end
%         [minRMSE, minRMSEIdx] = min(rmses);
%         outData1 = inpData1;
%         outData2 = inpData2+mtrx(minRMSEIdx);
%     end
end

