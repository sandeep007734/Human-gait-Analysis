% This function tries to combine the different Knee flexion extension
% values obtained from different sources.
function [angle_FE, angle_FE2, angle_FE3] =  applyFilter(angle_joint_axes,angle_rot_mat,angle_joint_centre)
    
    %% Initialise parameters.
    data_size = size(angle_joint_axes,2);
    angle_FE = nan(1, data_size);
    H = [1 1]';
    
    % Main Loop
    for t = 1:data_size
        angle_FE(1,t) = angle_rot_mat(1,t);
        K = [0.3 0.01];
        % Update the filter state.
        angle_FE(1,t) = angle_FE(1,t) + K*([angle_joint_axes(1,t);angle_joint_centre(1,t)]  - H*angle_FE(1,t));
    end
    
    %     for it = 2:size(angle_FE,2)
    %         angle_FE(1,it) = angle_FE(1,it-1)+angle_FE(1,it) ;
    %     end
    
    %% Initialise parameters.
    data_size = size(angle_joint_axes,2);
    angle_FE2 = nan(1, data_size);
    H = 1;
    
    % Main Loop
    for t = 1:data_size
        angle_FE2(1,t) = angle_rot_mat(1,t);
        K = 0.03;
        % Update the filter state.
        angle_FE2(1,t) = angle_FE2(1,t) + K*(angle_joint_centre(1,t)  - H*angle_FE2(1,t));
        
    end
    
    
   
    
    %% Another angle_FE3
    maxJoint = max(angle_joint_axes);
    maxRot = max(angle_rot_mat);
    fact = maxJoint/maxRot;
    fact=1;
    modRot = angle_rot_mat*fact;
    
    data_size = size(angle_joint_axes,2);
    angle_FE3 = nan(1, data_size);
    lambda = 0.03;
    deltaT = 1; % 0.02 sec
    angle_FE3(1,1) = angle_joint_axes(1,1);
%     disp('Default FE3 filtering mode');
    for t = 2:data_size
        angle_FE3(1,t) = lambda*modRot(1,t) +(1-lambda)*(angle_FE3(1,(t-deltaT))+...
            angle_joint_axes(1,t)-angle_joint_axes(1,(t-deltaT)));
    end
    
%     disp('done filtering');