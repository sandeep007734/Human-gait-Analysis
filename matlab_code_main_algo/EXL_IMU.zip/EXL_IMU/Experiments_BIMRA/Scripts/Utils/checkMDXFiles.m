%% This is the main run of the code.

% Clear everythign from all the past runs and make sure that we are at the
% correct position.
clear all;
clear all;
clear all; 
cd '/home/sandeep/IMU/EXL_IMU/Experiments_BIMRA';

%% Driver Code
% Select the Id of the subject for which to process the data.
%1 for Prof Gopi, 2 for Sandeep, 3 for Litizia, 4 for Sopihia
dataFileId = 3;
% There are more than one calibration file. Select the one which is to be
% selected.
% 1 for one plane, 2 for random
calibId=1;

% 0 for knee joint, 1 for ankle joint
% This is also used to select the appropriate
% calibration file. Thigh + Shank and Shank + Foot
% the SHANK JOINT algo is NOT working properly.
forFoot=0;
checkMdx = 1;
% Retrieving the corresponding data file based on the setting.
[folder,bimraFolder,calibrationFile,calibrationDataFile,bimraFile,dataFileThigh,dataFileShank,dataFileFoot]=...
    getDataFiles(dataFileId,calibId,forFoot,checkMdx);

% Check whether we got the foot data. If not make sure that it is not used
% in the future calculations.
% Foot data will be present if we have placed a sensor on the foor during
% the experiments. Typically when 3 sensors are placed on one leg.
rightFootDataPresent=1;
if(size(dataFileFoot,1)==0)
    rightFootDataPresent=0;
end




%%
% Number of experiment files present. (Walks done).
noOfFiles = size(bimraFile,1);

% The experiment are capped at 11 walks. This can be changed depending upon
% the need.
maxIter=11;
if noOfFiles < maxIter
    maxIter = noOfFiles;
end

% Custom control. Set it to 1 to run only one walk. Set which walk to run
% inside the main loop custom control.
% maxIter=1;

%% Run the Main Part. This is were all the magic happens
for num = 1:maxIter
    fprintf('\n*********** Iteration: %d ****************\n',num);
    %%% If maxItem is set to one then it will only run for one walk. The ID of the walk can be set here.;
    if(maxIter==1)
        disp('Custom control is on in the MainDriverCode')
        if(dataFileId==4) % Sophia
            num=1;
        end
        if(dataFileId==3) % Letizia
            num=1;
        end
        if(dataFileId==1) % Gopinath Sir
            num=1;
        end
    end
    
    %This makes sure that the accessed file is within the limits.
    if(num > noOfFiles)
        disp('Accessing index more than files present');
        break;
    end
    % ===========================
    
    
    
    %% Process MDX and JRKData
    
    % JRK data is what is used by the BIMRA algorithms to calculate the
    % Knee flexion extension angle. The values along the z axis, is
    % used for this purpose.
    
    addpath('/home/sandeep/IMU/EXL_IMU/Experiments_BIMRA/processMDXFiles');
    [jrkDataZ,HSOptical,TOOptical,opticalMarkerIdx, acmrkfe,avgStepJrk,avgacrkfe]=getMDXData(num,bimraFile,bimraFolder,0);
    
    %         return;
    if(jrkDataZ==-1)
        fprintf('getMDX returned and error.\n')
        continue;
    end
    
    if(opticalMarkerIdx==-1)
        disp('There is no Marker present in the BIMRA data. CANNOT sync the two systems');
    end
end

