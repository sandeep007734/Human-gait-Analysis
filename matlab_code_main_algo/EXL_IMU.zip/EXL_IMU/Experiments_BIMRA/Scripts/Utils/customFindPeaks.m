function [ cuspeakVal, scuspeakIdx ] = customFindPeaks(angluralRateXComp, minPeakHeight,minPeakDistnace )
%%

peakVal = -1;
peakIdx = -1;

%Row to c
needChange = 0;
%     [posPeaks posPeaksIdx] = findpeaks(testData,'MinPeakHeight',minPeakHeight);
if(size(angluralRateXComp,2)>1)
    sizeOfData = size(angluralRateXComp,2);
else
    sizeOfData = size(angluralRateXComp,1);
    needChange = 1;
end

prev = min(angluralRateXComp)-10;
isIncreasing = 0;


for ti  = 1:sizeOfData
    curr = angluralRateXComp(ti);
    if(curr > prev)
        isIncreasing =1;
    end
    if(curr<prev && prev >= minPeakHeight && isIncreasing)
        if(peakVal==-1)
            peakVal = prev;
            peakIdx = (ti-1);
        else
            peakVal = [peakVal,prev];
            peakIdx = [peakIdx,(ti-1)];
        end
        
        isIncreasing = 0;
        %             plot([(ti-1),(ti-1)],ylim,'color','red', 'LineWidth',1);
    end
    prev = curr;
end

%%
%%%    Filter Distance
cuspeakVal = -1;
cuspeakIdx = -1;

while(true)
    %
    if(sum(peakVal)==0)
        break;
    end
    
    [mval midx]=max(peakVal);
    midx = peakIdx(midx);
    
    if(cuspeakIdx==-1)
        cuspeakIdx = midx;
    else
        cuspeakIdx = [cuspeakIdx,midx];
    end
    
    nearby = find(peakIdx>=(midx-minPeakDistnace) & peakIdx<=(midx+minPeakDistnace));
    
    if(isempty(nearby))
        break;
    end
    
    for ni=1:size(nearby,2)
        nearby(ni) = peakIdx(nearby(ni));
    end
    
    c = ismember(peakIdx, nearby);
    peakVal(find(c))=0;
end

scuspeakIdx = sort(cuspeakIdx);
scuspeakIdx(find(scuspeakIdx<=0))=[];

if(isempty(scuspeakIdx))
    cuspeakVal=[];
    scuspeakIdx=[];
    return;
end

for ci = 1:max(size(scuspeakIdx))
    if(cuspeakVal==-1)
        cuspeakVal = angluralRateXComp(scuspeakIdx(ci));
    else
        cuspeakVal = [cuspeakVal,angluralRateXComp(scuspeakIdx(ci))];
    end
end
if(needChange)
    scuspeakIdx = scuspeakIdx';
    cuspeakVal = cuspeakVal';
else
    scuspeakIdx = sort(cuspeakIdx);
end


%     [posPeaks posPeaksIdx] = findpeaks(testData,'MinPeakHeight',minPeakHeight,'MinPeakDistance',minPeakDistnace);
%          T = table(scuspeakIdx,posPeaksIdx)

%     %%% plot
%     %     end
%     figure;
%     hold on; grid on;
%     plot(testData,'color','black', 'LineWidth',2);
%
%     for ci=1:size(scuspeakIdx,2)
%         plot([scuspeakIdx(ci),scuspeakIdx(ci)],ylim,'color','blue', 'LineWidth',2);
%     end
%
%     for pi=1:size(posPeaksIdx,1)
%         plot([posPeaksIdx(pi),posPeaksIdx(pi)],ylim,'color','red', 'LineWidth',2);
%     end
%
%
%     hold off;

end

