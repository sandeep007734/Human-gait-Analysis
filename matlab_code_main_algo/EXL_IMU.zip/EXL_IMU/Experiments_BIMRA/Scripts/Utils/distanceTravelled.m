  vel_n=[];
    pos_n=[];
    if(rightFootDataPresent)
        [ vel_n, pos_n ] = getDistance( gyro_s_foot(:,rawPeakIdx:end),acc_s_foot(:,rawPeakIdx:end) );
        HSData = HSFoot;
        
    end
    
    if(~isempty(vel_n))
        %     distanceFigure = figure();
        yAxisPos = pos_n(2,:);
        %     hold on; grid on;
        %     plot(yAxisPos,'color','black', 'LineWidth',2);
        heelStrikeLength = 0;
        imuStride = [];
        for hsfi = 2:size(HSData,2)
            %         fprintf('Right Stride Length (HS to HS): %f cm\n',(yAxisPos(HSFoot(hsfi))-yAxisPos(HSFoot(hsfi-1)))*100);
            distancediff = (yAxisPos(HSData(hsfi)-rawPeakIdx)-yAxisPos(HSData(hsfi-1)-rawPeakIdx));
            imuStride = [imuStride,distancediff];
            heelStrikeLength = heelStrikeLength+distancediff;
            
        end
        
        fprintf('Stride Compare (cm)\n\n')
        if(isempty(dseqRSTRIDE))
            dseqRSTRIDE = zeros(1,max(size(imuStride)));
        end
        imuStride =imuStride*100;
        dseqRSTRIDE = dseqRSTRIDE*100;
        rightStrideCompare = table(imuStride',dseqRSTRIDE',...
            'VariableNames',{'IMU_Stride_Right_Leg' 'Optical_Stride_Right_Leg' });
        
        strideError = abs(imuStride-dseqRSTRIDE);
        rightStrideCompareError = table(strideError',...
            'VariableNames',{'Stride_Error'});
        
        disp(rightStrideCompare);
        disp(rightStrideCompareError);
        
        writetable(rightStrideCompare,strcat(pathToSave,'Stride.txt'),'Delimiter',',');
        writetable(rightStrideCompareError,strcat(pathToSave,'StrideError.txt'),'Delimiter',',');
        
        sideWaysDistance = abs(pos_n(1,end));
        forwardDistance = abs(pos_n(2,end));
        elevationGained = abs(pos_n(3,end));
        
        fprintf('Distance Travelled (Total Data) (m)\n\n')
        distanceTavelled = table(forwardDistance',sideWaysDistance',elevationGained',...
            'VariableNames',{'Forward_Distance' 'Sideways_Distance' 'Elevaton_Gained' });
        distanceTavelled.Properties.VariableUnits = {'m' 'm'  'm'};
        writetable(distanceTavelled,strcat(pathToSave,'DistanceTravelled.txt'),'Delimiter',',');
        disp(distanceTavelled);
        
    end