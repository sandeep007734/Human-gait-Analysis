if(~isempty(gyro_s_thigh))
    gyro_s_thigh = gyro_s_thigh(:,startDataPoint:endDataPoint);
    gyro_s_derv_thigh = gyro_s_derv_thigh(:,startDataPoint:endDataPoint);
    acc_s_thigh = acc_s_thigh(:,startDataPoint:endDataPoint);
    quarternion_thigh = quarternion_thigh(:,startDataPoint:endDataPoint);
end

if(~isempty(gyro_s_shank))
    gyro_s_shank = gyro_s_shank(:,startDataPoint:endDataPoint);
    gyro_s_derv_shank = gyro_s_derv_shank(:,startDataPoint:endDataPoint);
    acc_s_shank = acc_s_shank(:,startDataPoint:endDataPoint);
    quarternion_shank = quarternion_shank(:,startDataPoint:endDataPoint);
end

if(~isempty(gyro_s_foot))
    gyro_s_foot = gyro_s_foot(:,startDataPoint:endDataPoint);
    gyro_s_derv_foot = gyro_s_derv_foot(:,startDataPoint:endDataPoint);
    acc_s_foot = acc_s_foot(:,startDataPoint:endDataPoint);
    quarternion_foot = quarternion_foot(:,startDataPoint:endDataPoint);
end

timestamp=[startDataPoint:endDataPoint];


