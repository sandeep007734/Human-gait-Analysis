function [  peakIdx ] = findIMUMarker( peaksData )
    
%     The data expected in the KNee Flexion Extension angle. As this is the
%     data which is used in the optical system to get the marker position.
    
%% Run this
    

    
%     showPlot=1;
%     peaksData = imuRightKneeFE;
%     clc;
    
    peaksData = abs(peaksData);
    sizeOfData = max(size(peaksData));
    stepSize = fix(max(size(peaksData))/10);
    maxRatio=-1;
    prev=1;
    iter = 0;
    
    peakPercentage = .2;
    
 
    for i=stepSize:stepSize:sizeOfData
        curr = i;
        currData = peaksData(prev:curr);
        currRatio = var(currData)/mean(currData);

        if(currRatio > maxRatio)
            maxRatio = currRatio;
            %             plot([peakIdx,peakIdx],ylim,'linewidth',2,'color','red');
            [maxVal, maxIdx] = max(currData);
            peakIdx = maxIdx+iter*stepSize;
        end
        prev = curr;
        iter = iter+1;
    end
    
    %%
    %     hold off;
    if(max(size(findpeaks(peaksData,'MinPeakHeight',peaksData(peakIdx)/2))==1))
       return; 
    end
    
    % Minimun threshold on the peaks
    if(peakPercentage* mean(findpeaks(peaksData,'MinPeakHeight',peaksData(peakIdx)/2)) < ...
        (peaksData(peakIdx)- mean(findpeaks(peaksData,'MinPeakHeight',peaksData(peakIdx)/2))))
    else
        fprintf('findPeak: No Peak detected which is 20 percent of more height than the mean of the top peaks\n');
        peakIdx = 0;
    end
    
    if(showPlot)
        figure; hold on; grid on;
        plot(peaksData,'color','black', 'LineWidth',1,'Marker', '*');
        plot([peakIdx,peakIdx],ylim,'linewidth',2,'color','red');
        
        legend('Input Data','Peak','Location','northeast');
        title('Graph showing Marker, Start point and End point. IMU Data','fontsize',20);
        
        hold off;
    end
    
    
    
    
    
    
    
end

