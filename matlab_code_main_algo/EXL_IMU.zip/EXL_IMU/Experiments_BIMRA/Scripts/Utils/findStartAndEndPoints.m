function [ startIdx,endIdx,rawPeakIdx ] = findStartAndEndPoints( inputData )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%% Run it
showPlot=0;

% inputData(find(inputData<0))=0;

sizeOfData = max(size(inputData));
% % stepSize = fix(max(size(inputData))/100);
% varData = var(inputData);


%%
for i =1:sizeOfData
    x = var(inputData(1:i));
    if(x>=.01)
        startIdx=i;
        break;
    end
end

rInputData = flip(inputData);
for i =1:sizeOfData
    x = var(rInputData(1:i));
    if(x>=.01)
        endIdx=i;
        break;
    end
end


%%


endIdx = sizeOfData-endIdx;

peakInput = inputData(startIdx:end);
peakInput(find(peakInput<0.0))=0;
meanData = mean(peakInput);
sizeOfData = max(size(peakInput));
stepSize = fix(max(size(peakInput))/10);
maxRatio=-1;
prev=1;
iter = 0;

for i=stepSize:stepSize:sizeOfData
    curr = i;
    currData = peakInput(prev:curr);
    currRatio = var(currData)/mean(currData);
    
    if(currRatio > maxRatio)
        maxRatio = currRatio;
        [maxVal, maxIdx] = max(currData);
        rawPeakIdx = maxIdx+iter*stepSize;
        break;
    end
    prev = curr;
    iter = iter+1;
end

rawPeakIdx = rawPeakIdx+startIdx;
rawPeakIdx = rawPeakIdx+10;


if(showPlot)
    figure; hold on; grid on;
    plot(inputData,'color','black', 'LineWidth',2);
    
    plot([startIdx,startIdx],ylim,'linewidth',2,'color','green');
    plot([rawPeakIdx,rawPeakIdx],ylim,'linewidth',2,'color','red');
    plot([endIdx,endIdx],ylim,'linewidth',2,'color','blue');
    
    legend('Input Data','Start Point','Raw Peak IDx', 'End Point','Location','northeast');
    title('Graph showing Start point, Marker and End point. IMU Data','fontsize',20);
    
    hold off;
end







end

