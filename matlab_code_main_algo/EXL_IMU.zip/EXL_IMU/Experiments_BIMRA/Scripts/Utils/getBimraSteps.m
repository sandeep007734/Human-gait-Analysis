function [step] = getBimraSteps(walkData)
    %%
    debug=0;
    if(debug==1)
        disp('Debug on in new get step');
        clc
        walkData= bimraData;
        %         walkData= angle_FE;
    end
    
    
    timeStamp = [1:size(walkData,2)];
    maxVal = max(walkData);
    minVal = min(walkData);
    avgVal = mean(walkData);
    middleVal = (maxVal+minVal)/2;
    
    % Finding Peaks in the original Data
    [peaksVal,peaksIdx] = findpeaks(walkData);
    peaksIdx(peaksVal < middleVal)=[];
    peaksVal(peaksVal < middleVal)=[];
    
    %     % Remove Close Idx
    %     prevIdx = peaksIdx(1,1);
    %     preVal = peaksVal(1,1);
    %     for i=2:size(peaksIdx,2)
    %         currIdx = peaksIdx(1,i);
    %         currVal = peaksVal(1,i);
    %
    %         if(currIdx-prevIdx < 50)
    %             if(currVal > preVal)
    %                 peaksIdx(1,i-1)=1;
    %             else
    %                 peaksIdx(1,i)=1;
    %             end
    %         else
    %             prevIdx = currIdx;
    %             preVal = currVal;
    %         end
    %     end
    %
    %     peaksIdx(peaksIdx==1)=[];
    
    %     % Getting the step width
    %     stepWidth=peaksIdx(1,2)-peaksIdx(1,1);
    %     startIdx = (peaksIdx(1,1)-stepWidth);
    %
    %     %Truncating the Data.
    actualStepData = walkData;
    %     peaksIdx = peaksIdx-startIdx;
    
    %Inverse of Data
    inverseData = 1.01*max(actualStepData) - actualStepData;
    
    
    %-----------------------------------------
    %finding the bottoms
    % Finding Peaks in the Inverse Data
    [InvpeaksVal,InvpeaksIdx] = findpeaks(inverseData);
    % peaksIdx(peaksVal < middleVal)=[]
    % peaksVal(peaksVal < middleVal)=[];
    
    %     % Remove Close Idx----------------
    %     InvprevIdx = InvpeaksIdx(1,1);
    %     InvpreVal = InvpeaksVal(1,1);
    %
    %     for i=2:size(InvpeaksIdx,2)
    %         InvcurrIdx = InvpeaksIdx(1,i);
    %         InvcurrVal = InvpeaksVal(1,i);
    %
    %         if(InvcurrIdx-InvprevIdx < 50)
    %             if(InvcurrVal > InvpreVal)
    %                 InvpeaksIdx(1,i-1)=1;
    %             else
    %                 InvpeaksIdx(1,i)=1;
    %                 InvprevIdx = InvcurrIdx;
    %                 InvpreVal = InvcurrVal;
    %             end
    %         else
    %             InvprevIdx = InvcurrIdx;
    %             InvpreVal = InvcurrVal;
    %         end
    %     end
    %
    %     InvpeaksIdx(InvpeaksIdx==1)=[];
    %     % Remove Close Idx----------------
    
    
    %     % removing outof range intrest points
    %     smallIdx = InvpeaksIdx<peaksIdx(1,1);
    %     InvpeaksIdx(smallIdx(2:end))=[];
    %
    %     bigIdx = InvpeaksIdx>peaksIdx(1,end);
    %     bigIdx(1:size(bigIdx,2)-sum(bigIdx)+2)=0;
    %     InvpeaksIdx(bigIdx)=[];
    
    %-----------------------------------------
    
    %Intrested Indexes
    intIdx = sort([peaksIdx,InvpeaksIdx]);
    if (actualStepData(intIdx(2)) > middleVal)
        intIdx = intIdx(3:end);
    end
    
    intIdx = intIdx(1:3:end);
    
    if(debug)
%         
        h = figure;
        grid on;
        hold on;
        plot(actualStepData,'color','Black', 'LineWidth',2,'Marker', '*');
        refline(0,middleVal);
        % % Plotting Peaks
        % for i=1:size(peaksIdx,2)
        %     x1 = timeStamp(1,peaksIdx(1,i));
        %     plot([x1,x1],ylim)
        % end
        %
        % %Plotting Bottoms
        % for i=1:size(InvpeaksIdx,2)
        %     x1 = timeStamp(1,InvpeaksIdx(1,i));
        %     plot([x1,x1],ylim)
        % end
        
        %Plotting Both
        for i=1:size(intIdx,2)
            x1 = timeStamp(1,intIdx(1,i));
            plot([x1,x1],ylim)
        end
        title(sprintf('For the File'));
        hold off;
    end
    
    proceed =1;
    
    if(proceed)
        step=actualStepData(intIdx(1):intIdx(2));
        
        if(debug)
%             
            h = figure;
            grid on;
            hold on;
            plot(step,'color','Black', 'LineWidth',2,'Marker', '*');
            refline(0,middleVal);
            hold off;
        end
    end
end
