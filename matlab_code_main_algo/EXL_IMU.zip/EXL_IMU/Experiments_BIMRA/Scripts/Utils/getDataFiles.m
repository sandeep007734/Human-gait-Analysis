function[folder,bimraFolder,bimraFile,...
        rightKneeRawCalib, rightKneeProcessedCalib,...
        rightFootRawCalib, rightFootProcessedCalib,...
        rightThighData,rightShankData,rightFootData]=getDataFiles(experimentId, calibType,checkMDXDataMode, isJson, expName,calibMode)
    
    
    %% JSON Process Area
    
    if(isJson)
        
        mainFolder = 'Experiments_BIMRA_2/';
        folder = strcat(mainFolder,expName);
        folder = strcat(folder,'/');
        bimraFolder = [];
        bimraFile=[];
        
        fname = strcat(folder,'info.json');
        fid = fopen(fname);
        raw = fread(fid,inf);
        str = char(raw');
        fclose(fid);
        
        data = JSON.parse(str);
        
        %         Knee Calibration Data
        if(isempty(data.rightKneeJoint.calibrationData))
            rightKneeRawCalib = [];
        else
            rightKneeRawCalib = [data.rightKneeJoint.calibrationData(1);data.rightKneeJoint.calibrationData(2)];
        end
        
        %              Ankle Calibration Data
        if(isempty(data.rightAnkleJoint.calibrationData))
            rightFootRawCalib = [];
        else
            rightFootRawCalib = [data.rightAnkleJoint.calibrationData(1);data.rightAnkleJoint.calibrationData(2)];
        end
        if(calibType==1)
            rightKneeProcessedCalib = strcat(folder,'calibration_onePlane','_rightKnee');
            rightFootProcessedCalib = strcat(folder,'calibration_onePlane','_rightAnkle');
        else
            rightKneeProcessedCalib = strcat(folder,'calibration_randomPlane','_rightKnee');
            rightFootProcessedCalib = strcat(folder,'calibration_randomPlane','_rightAnkle');
        end
        
        % Processing the walk files now.
        
        rightThighData =  [];
        rightShankData=[];
        rightFootData = [];
        for wd=1:max(size(data.walkData))
            if(max(size(data.walkData{1,wd}.walkFiles)) > 0)
                rightThighData = [rightThighData; data.walkData{1,wd}.walkFiles(1)];
            end
            if(max(size(data.walkData{1,wd}.walkFiles))>1)
                rightShankData = [rightShankData; data.walkData{1,wd}.walkFiles(2)];
            end
            if(max(size(data.walkData{1,wd}.walkFiles))>2)
                rightFootData = [rightFootData; data.walkData{1,wd}.walkFiles(3)];
            end
        end
        return;
    end
    
    %%
    
    %This file is used to get the name of the data files of the experiments
    %done. Along with the file name it also passes some other information
    %which to be used during the processing of the files.
    
    % BIMRA sometimes wont start collecting data point from the beginning
    % of the trials because of missing markers or presence of the some
    % ghost markers. This will result in starting of the datpoints at some
    % later stage.
    
    if (experimentId == 1)
        %% Gopi Sir
        mainFolder = 'Experiments_BIMRA_1/';
        folder = strcat(mainFolder,'Gopinath/');
        bimraFolder = strcat(mainFolder,'3dGopinath/');
        
        rightKneeRawCalib = ['S0_0008.txt';'S1_0008.txt'];
        rightKneeProcessedCalib = strcat(folder,'calibration.mat');
        rightFootRawCalib = [];
        rightFootProcessedCalib=[];
        
        %Mapping of the files from the two EXML IMU sensors and the Gait Lab
        rightThighData = ['S0_0007.txt';'S0_0012.txt';'S0_0013.txt';'S0_0015.txt';'S0_0016.txt';'S0_0017.txt'];
        rightShankData = ['S1_0007.txt';'S1_0012.txt';'S1_0013.txt';'S1_0015.txt';'S1_0016.txt';'S1_0017.txt'];
        rightFootData=[]; % Data not available
        bimraFile = ['0156~ab~Walking~01.mdx';'0156~ab~Walking~05.mdx';'0156~ab~Walking~06.mdx';'0156~ab~Walking~08.mdx';'0156~ab~Walking~09.mdx';'0156~ab~Walking~10.mdx'];
        
        
    elseif(experimentId == 2)
        %% Sandeep
        mainFolder = 'Experiments_BIMRA_1/';
        folder = strcat(mainFolder,'Sandeep/');
        bimraFolder = strcat(mainFolder,'3dSandeep/');
        
        rightKneeRawCalib = ['S0_0019.txt';'S1_0019.txt'];
        rightKneeProcessedCalib = strcat(folder,'calibration.mat');
           rightFootRawCalib = [];
        rightFootProcessedCalib=[];
        
        %Mapping of the files from the two EXML IMU sensors and the Gait Lab
        rightThighData = ['S0_0021.txt';'S0_0023.txt';'S0_0024.txt';'S0_0025.txt';'S0_0026.txt';'S0_0027.txt';'S0_0029.txt';'S0_0030.txt'];
        rightShankData = ['S1_0021.txt';'S1_0023.txt';'S1_0024.txt';'S1_0025.txt';'S1_0026.txt';'S1_0027.txt';'S1_0029.txt';'S1_0030.txt'];
        rightFootData = [];
        bimraFile = ['0157~ab~Walking~01.mdx';'0157~ab~Walking~02.mdx';'0157~ab~Walking~03.mdx';'0157~ab~Walking~04.mdx';'0157~ab~Walking~05.mdx';'0157~ab~Walking~06.mdx';'0157~ab~Walking~08.mdx';'0157~ab~Walking~09.mdx'];
        
    elseif(experimentId == 3)
        %% Letizia
        mainFolder = 'Experiments_BIMRA_2/';
        folder = strcat(mainFolder,'Letizia11/');
        bimraFolder = strcat(mainFolder,'3dLetizia/');
        
        if(calibType==1)
            rightKneeRawCalib = ['S0_0001.txt';'S1_0001.txt'];
            rightKneeProcessedCalib = strcat(folder,'calibration_onePlane','.mat');
            
            rightFootRawCalib = ['S1_0001.txt';'S2_0001.txt'];
            rightFootProcessedCalib = strcat(folder,'calibration_onePlane','_ankle','.mat');
        else
            rightKneeRawCalib = ['S0_0002.txt';'S1_0002.txt'];
            rightKneeProcessedCalib = strcat(folder,'calibration_random','.mat');
            
            rightFootRawCalib = ['S1_0002.txt';'S2_0002.txt'];
            rightFootProcessedCalib = strcat(folder,'calibration_random','_ankle','.mat');
        end
        
        
        
        %Mapping of the files from the two EXML IMU sensors and the Gait Lab
        rightThighData = ['S0_0008.txt';'S0_0010.txt';'S0_0011.txt'];
        rightShankData = ['S1_0008.txt';'S1_0010.txt';'S1_0011.txt'];
        rightFootData = ['S2_0008.txt';'S2_0010.txt';'S2_0011.txt'];
        
        
        if(checkMDXDataMode)
            bimraFile = ['0184~aa~Walking~02.mdx'; '0184~aa~Walking~03.mdx';'0184~aa~Walking~04.mdx';'0184~aa~Walking~05.mdx';
                '0184~aa~Walking~06.mdx';'0184~aa~Walking~07.mdx';'0184~aa~Walking~08.mdx';'0184~aa~Walking~09.mdx';];
        else
            bimraFile = ['0184~aa~Walking~05.mdx'; '0184~aa~Walking~07.mdx';'0184~aa~Walking~08.mdx'];
        end
        
    elseif(experimentId == 4)
        %% Sofia
        mainFolder = 'Experiments_BIMRA_2/';
        folder = strcat(mainFolder,'Sofia7/');
        bimraFolder = strcat(mainFolder,'3dSofia/');
        
        if(calibType==1)
            rightKneeRawCalib = ['S0_0013.txt';'S1_0013.txt'];
            rightKneeProcessedCalib = strcat(folder,'calibration_onePlane_',calibMode,'.mat');
            
            rightFootRawCalib = ['S1_0013.txt';'S2_0013.txt'];
            rightFootProcessedCalib = strcat(folder,'calibration_onePlane_',calibMode,'_ankle','.mat');
        else
            rightKneeRawCalib = ['S0_0014.txt';'S1_0014.txt'];
            rightKneeProcessedCalib = strcat(folder,'calibration_random','.mat');
            
            rightFootRawCalib = ['S1_0014.txt';'S2_0014.txt'];
            rightFootProcessedCalib = strcat(folder,'calibration_random','_ankle','.mat');
        end
        
        %Mapping of the files from the two EXML IMU sensors and the Gait Lab
        rightThighData = ['S0_0018.txt';'S0_0019.txt';'S0_0020.txt';'S0_0021.txt';'S0_0022.txt';'S0_0023.txt';'S0_0024.txt'];
        rightShankData = ['S1_0018.txt';'S1_0019.txt';'S1_0020.txt';'S1_0021.txt';'S1_0022.txt';'S1_0023.txt';'S1_0024.txt'];
        rightFootData = ['S2_0018.txt';'S2_0019.txt';'S2_0020.txt';'S2_0021.txt';'S2_0022.txt';'S2_0023.txt';'S2_0024.txt'];
        
        
        
        if(checkMDXDataMode)
            bimraFile = ['0185~aa~Walking~01.mdx';...
                '0185~aa~Walking~02.mdx';'0185~aa~Walking~03.mdx';'0185~aa~Walking~04.mdx';...
                '0185~aa~Walking~05.mdx';'0185~aa~Walking~06.mdx';'0185~aa~Walking~07.mdx';
                '0185~aa~Walking~08.mdx';'0185~aa~Walking~09.mdx';'0185~aa~Walking~10.mdx'];
        else
            bimraFile = ['0185~aa~Walking~03.mdx';...
                '0185~aa~Walking~04.mdx';'0185~aa~Walking~05.mdx';'0185~aa~Walking~06.mdx';...
                '0185~aa~Walking~07.mdx';'0185~aa~Walking~08.mdx';'0185~aa~Walking~09.mdx'];
        end
        
        
    elseif(experimentId ==5)
         %% Satish
        mainFolder = 'Experiments_BIMRA_3/';
        folder = strcat(mainFolder,'satish/');
        bimraFolder = strcat(mainFolder,'3dsatish/');
        
        if(calibType==1)
            rightKneeRawCalib = ['S0_0001.txt';'S1_0001.txt'];
            rightKneeProcessedCalib = strcat(folder,'calibration_onePlane','.mat');
            
            rightFootRawCalib = ['S1_0001.txt';'S2_0001.txt'];
            rightFootProcessedCalib = strcat(folder,'calibration_onePlane','_ankle','.mat');
        else
            rightKneeRawCalib = ['S0_0001.txt';'S1_0001.txt'];
            rightKneeProcessedCalib = strcat(folder,'calibration_random','.mat');
            
            rightFootRawCalib = ['S1_0001.txt';'S2_0001.txt'];
            rightFootProcessedCalib = strcat(folder,'calibration_random','_ankle','.mat');
        end
        
        %Mapping of the files from the two EXML IMU sensors and the Gait Lab
        rightThighData = ['S0_0002.txt';'S0_0003.txt';'S0_0004.txt';'S0_0005.txt';'S0_0006.txt';'S0_0007.txt';'S0_0008.txt'];
        rightShankData = ['S1_0002.txt';'S1_0003.txt';'S1_0004.txt';'S1_0005.txt';'S1_0006.txt';'S1_0007.txt';'S1_0008.txt'];
        rightFootData = ['S2_0002.txt';'S2_0003.txt';'S2_0004.txt';'S2_0005.txt';'S2_0006.txt';'S2_0007.txt';'S2_0008.txt'];
        
        
        
        bimraFile =  [];
        
         elseif(experimentId ==6)
         %% Satish
        mainFolder = 'Experiments_BIMRA_3/';
        folder = strcat(mainFolder,'mamatha/');
        bimraFolder = strcat(mainFolder,'3dmamatha/');
        
        if(calibType==1)
            rightKneeRawCalib = ['S0_0001.txt';'S1_0001.txt'];
            rightKneeProcessedCalib = strcat(folder,'calibration_onePlane','.mat');
            
            rightFootRawCalib = ['S1_0001.txt';'S2_0001.txt'];
            rightFootProcessedCalib = strcat(folder,'calibration_onePlane','_ankle','.mat');
        else
            rightKneeRawCalib = ['S0_0001.txt';'S1_0001.txt'];
            rightKneeProcessedCalib = strcat(folder,'calibration_random','.mat');
            
            rightFootRawCalib = ['S1_0001.txt';'S2_0001.txt'];
            rightFootProcessedCalib = strcat(folder,'calibration_random','_ankle','.mat');
        end
        
        %Mapping of the files from the two EXML IMU sensors and the Gait Lab
        rightThighData = ['S0_0002.txt';'S0_0003.txt';'S0_0004.txt';'S0_0005.txt';'S0_0006.txt';'S0_0007.txt';'S0_0008.txt';'S0_0009.txt';'S0_0010.txt';'S0_0011.txt'];
        rightShankData = ['S1_0002.txt';'S1_0003.txt';'S1_0004.txt';'S1_0005.txt';'S1_0006.txt';'S1_0007.txt';'S1_0008.txt';'S1_0009.txt';'S1_0010.txt';'S1_0011.txt'];
        rightFootData = ['S2_0002.txt';'S2_0003.txt';'S2_0004.txt';'S2_0005.txt';'S2_0006.txt';'S2_0007.txt';'S2_0008.txt';'S2_0009.txt';'S2_0010.txt';'S2_0011.txt'];
        
        
        
        bimraFile =  [];
        
    end
end