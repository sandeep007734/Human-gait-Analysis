function [ thighData, shankData, ankleData, size_data ] = getDataFilesAndSize( thighFile, shankFile, ankleFile,rightFootDataPresent )
    %UNTITLED Summary of this function goes here
    %   Detailed explanation goes here
    
     % Import the data from the corresponding experiments file.
     
    thighDataStruct = importdata(thighFile);
    shankDataStruct = importdata(shankFile);
    if(rightFootDataPresent)
        ankleData = importdata(ankleFile);
    else
        ankleData=[];
    end
    
    %%% Removing artifacts of the previous experiments from the data
    
    % During the experiments the devices, sometimes tend to broadcast the
    % residue data from the previous experiments. Because of this the ID
    % does not start from 1. Here we discard any such data and make sure it
    % starts at 1 and all the sensors data have the same length.
    
    tempThighData = thighDataStruct.data (1:end, :);
    tempShankData = shankDataStruct.data(1:end, :);
    if(rightFootDataPresent)
        tempAnkleData = ankleData.data(1:end, :);
    end
    
    [startIdx1,startIdx2,endIdx1,endIdx2] = matchData(tempThighData,tempShankData);
    
    thighData = thighDataStruct.data(startIdx1:endIdx1, :);
    shankData = shankDataStruct.data(startIdx2:endIdx2, :);
    
    % TODO this parts need work. As of now only the thigh and the shank
    % data is in sync. Need to make sure all three of them are in sync.
    
    if(rightFootDataPresent)
        [startIdx1,startIdx2,endIdx1,endIdx2] = matchData(thighData,tempAnkleData);
    end
    %     thighData = thighData(startIdx1:endIdx1, :);
    %     shankData = thighData(startIdx1:endIdx1, :);
    if(rightFootDataPresent)
        ankleData = ankleData.data(startIdx2:endIdx2, :);
    end
    
    %%% Getting the size of the data
    
    % This section wont be necessary once the previous section is fixed.
    
    if(rightFootDataPresent)
        size_data = min([size(thighData,1) size(shankData,1) size(ankleData,1)]);
    else
        size_data = min([size(thighData,1) size(shankData,1)]);
    end
    
end

