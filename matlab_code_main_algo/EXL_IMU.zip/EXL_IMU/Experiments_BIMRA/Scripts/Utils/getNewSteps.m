function [avgStepMax, avgStepMin] = getNewSteps(walkData,withDebug)
    %%
    %     withDebug=1;
    %     
    %     walkData= angle_joint_axes;
    %     disp('Debug on in new get step');
    
    
    showPlot = 0;
    
    debug=withDebug;  
    
    timeStamp = [1:size(walkData,2)];
    maxVal = max(walkData);
    minVal = min(walkData);
    avgVal = mean(walkData);
    middleVal = (maxVal+minVal)/2;
    
    % Finding Peaks in the original Data
    [peaksVal,peaksIdx] = findpeaks(walkData);
    peaksIdx(peaksVal < middleVal)=[];
    peaksVal(peaksVal < middleVal)=[];
    
    % Remove Close Idx
    prevIdx = peaksIdx(1,1);
    preVal = peaksVal(1,1);
    for i=2:size(peaksIdx,2)
        currIdx = peaksIdx(1,i);
        currVal = peaksVal(1,i);
        
        if(currIdx-prevIdx < 50)
            if(currVal > preVal)
                peaksIdx(1,i-1)=1;
            else
                peaksIdx(1,i)=1;
            end
        else
            prevIdx = currIdx;
            preVal = currVal;
        end
    end
    
    peaksIdx(peaksIdx==1)=[];
    
    % Getting the step width
    stepWidth=peaksIdx(1,2)-peaksIdx(1,1);
    startIdx = max(1,(peaksIdx(1,1)-stepWidth));
    
    %Truncating the Data.
    actualStepData = walkData(startIdx:end);
    peaksIdx = peaksIdx-startIdx;
    
    %Inverse of Data
    inverseData = 1.01*max(actualStepData) - actualStepData;
    
    
    %-----------------------------------------
    %finding the bottoms
    % Finding Peaks in the Inverse Data
    [InvpeaksVal,InvpeaksIdx] = findpeaks(inverseData);
    % peaksIdx(peaksVal < middleVal)=[]
    % peaksVal(peaksVal < middleVal)=[];
    
    % Remove Close Idx----------------
    InvprevIdx = InvpeaksIdx(1,1);
    InvpreVal = InvpeaksVal(1,1);
    
    for i=2:size(InvpeaksIdx,2)
        InvcurrIdx = InvpeaksIdx(1,i);
        InvcurrVal = InvpeaksVal(1,i);
        
        if(InvcurrIdx-InvprevIdx < 40)
            if(InvcurrVal > InvpreVal)
                InvpeaksIdx(1,i-1)=1;
            else
                InvpeaksIdx(1,i)=1;
                InvprevIdx = InvcurrIdx;
                InvpreVal = InvcurrVal;
            end
        else
            InvprevIdx = InvcurrIdx;
            InvpreVal = InvcurrVal;
        end
    end
    
    InvpeaksIdx(InvpeaksIdx==1)=[];
    %--------------------------
    
    % Remove Out of Range Values
    smallIdx = InvpeaksIdx<peaksIdx(1,1);
    InvpeaksIdx(smallIdx(2:end))=[];
    
    bigIdx = InvpeaksIdx>peaksIdx(1,end);
    bigIdx(1:size(bigIdx,2)-sum(bigIdx)+2)=0;
    InvpeaksIdx(bigIdx)=[];
    
    %-----------------------------------------
    
    %Intrested Indexes
    intIdx = sort([peaksIdx,InvpeaksIdx]);
    
    %Get the heel strike points APPROX
    if (actualStepData(intIdx(2)) > middleVal)
        intIdx = intIdx(3:end);
    end
    intIdx = intIdx(1:3:end);
    
    % Remove Drift
    actualStepData = removeDrift(actualStepData,1);
    
    
    %Plot
    disp('Plot shown from getNewSteps');
    if(showPlot)
        %         
        h = figure;
        grid on;
        hold on;
        plot(actualStepData,'color','Black', 'LineWidth',2,'Marker', '*');
        set(gca,'fontsize',20);
        refline(0,middleVal);
        for i=1:size(intIdx,2)
            x1 = timeStamp(1,intIdx(1,i));
            plot([x1,x1],ylim,'linewidth',2);
        end
        xlabel('Data Points','fontsize',20);
        ylabel('Knee Joint Angle (Degrees)','fontsize',20);
        title('Knee Joint Angle for two Steps for a Normal Person','fontsize',30);
    end
    
    %%
    proceed =1;
    
    if(proceed)
        %Getting Steps
        maxStepSize = max(intIdx - [0,intIdx(1:end-1)]);
        minStepSize = min(intIdx - [0,intIdx(1:end-1)]);
        noOfStep = size(intIdx,2)-1;
        
        stepDataMax = zeros(noOfStep,maxStepSize-1);
        stepDataMin = zeros(noOfStep,minStepSize);
        
        for i=1:size(intIdx,2)-1
            currData= actualStepData(intIdx(1,i):intIdx(1,i+1));
            
            IntercurrDataMax = interp1(1:1:size(currData,2), currData, 1:size(currData,2)/...
                (maxStepSize):size(currData,2));
            
            IntercurrDataMin = interp1(1:1:size(currData,2), currData, 1:size(currData,2)/...
                (minStepSize):size(currData,2));
            
            if(0)
                disp((sprintf('Orig: %d NewMax: %d NewMin: %d\n',size(currData),size(IntercurrDataMax), size(IntercurrDataMin))));
            end
            stepDataMax(i,:)=IntercurrDataMax(1:maxStepSize-1);
            stepDataMin(i,:)=IntercurrDataMin(1:minStepSize);
        end
        
        %avgStep
        if(noOfStep>=3)
            midIdx=round(noOfStep/2);
            fIdx=midIdx-1;
            eIdx=midIdx+1;
            
            avgStepMax=(stepDataMax(fIdx,:)+stepDataMax(midIdx,:)+stepDataMax(eIdx,:))/3;
            avgStepMin=(stepDataMin(fIdx,:)+stepDataMin(midIdx,:)+stepDataMin(eIdx,:))/3;
            
        else
            avgStep=0;
            for i=1:noOfStep
                avgStepMax=avgStep+stepDataMax(i,:);
                avgStepMin=avgStep+stepDataMin(i,:);
            end
            avgStepMax = avgStepMax/noOfStep;
            avgStepMin = avgStepMin/noOfStep;
        end
        
        if(showPlot)
            %             
            h = figure;
            grid on;
            hold on;
            plot(avgStepMax,'color','Black', 'LineWidth',2,'Marker', '*');
            plot(avgStepMin,'color','Blue', 'LineWidth',2,'Marker', '*');
        end
        
        
        
    end
end
