%% Introduction
% We compare the result calculated using the IMU data to the results
% calculated by the Optical System at BIMRA. We are currently focussing on
% Knee Flexion Extension, Ankle Flexion Extension, Heel Strike, Toe off and
% Distance travelled by the subject.
% Clear everythign from all the past runs and make sure that we are at the
% correct position.
clear all;
clear all;
clear all;
close all;


% Here we define the values of the various tuning parameters which will be
% used during the evaluation of the results. Such as which experiment to
% run, whether to use all the walks or just one, location of the raw data
% etc.

experimentId = 4;       %1 for Prof Gopi, 2 for Sandeep, 3 for Litizia, 4 for Sopihia and so on
compareWithBimra = 1;
if(experimentId==4 || experimentId==3)
    peakPresent=1;
else
    peakPresent=0;
end

calibrationType=1;      % There are more than one calibration file. Select the one which is to be selected. 1 for one plane, 2 for random

plotAll = -1;    % Plot al figures?
saveImagesToFile = 0;   % Whether to save the images to the file.
% Fine Control: which Plots to Plot

plotCalibrationPlots=0;
plotOptical = 0;
plotstartRawIdandEnd  = 0;
plotstartEndPointsFromKneeFE = 0;
plotacmRKFEandacRKFE = 0;
plotHS = 0;
plotTO =0;
plotImuKneeFE =0;
plotAlignFigure = 0;
plotFinalRMSE = 1;
plotAxesChange = 0;

if(plotAll ~= -1)
    plotstartEndPointsFromKneeFE = plotAll;
    plotOptical = plotAll;
    plotacmRKFEandacRKFE = plotAll;
    plotFinalRMSE = plotAll;
    plotHS = plotAll;
    plotTO=plotAll;
    plotAlignFigure = plotAll;
    plotImuKneeFE =plotAll;
    plotstartRawIdandEnd = plotAll;
    plotAxesChange = plotAll;
end



PELVIS=1;
KNEE=2;
ANKLE=3;

% Print extra message in the debug mode
global isDebug;
isDebug=0;

% This is set to 1 by checkMDX function, which is used to verify the MDX
% files.
checkMdx=0;

% This setting is related to phone app
% Retrieving the corresponding data file based on the setting.
isJson = 0;
expName = 'phoneData';

maxTrialAllowed=11;


% Calibration configuration
num_of_iterations =50;
threshold = 0.00001;
scale_factor=1;
calibMode = 'unstable';

runCalibrationAnyWay=0;
useWalkasCalibration=1;

% TODO calculate the orientation of the Joint axis automatically
% Some manual changes to correct the direction of the axis of the axes
% obtained during the calibration process.
% makeChanges = 1;
%% Start the Experiment

disp('Reading the IMU data files');

% Get the relvant files for the experiment
[folder,bimraFolder,bimraFiles,...
    rightKneeRawCalibFiles,rightKneeProcessedCalibFile,...
    rightFootRawCalibFiles,rightFootProcessedCalibFile,...
    rightThighDataFiles,rightShankDataFiles,rightFootDataFiles]=...
    getDataFiles(experimentId,calibrationType,checkMdx,isJson,expName,calibMode);


[ rightThighDataPresent,rightShankDataPresent,rightFootDataPresent,proceRightKneeJoint,processRightFootJoint,noOfWalkingTrials ] = ...
    checkDataPresence( rightThighDataFiles,rightShankDataFiles,rightFootDataFiles,maxTrialAllowed );

if(isempty(bimraFiles) || (compareWithBimra==0))
    dseqRSTRIDE=[];
end

fprintf('Total Number of Walking Trials %d\n',noOfWalkingTrials);
