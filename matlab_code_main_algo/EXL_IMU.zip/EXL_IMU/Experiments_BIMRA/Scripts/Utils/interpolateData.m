function [ outputData ] = interpolateData( inputData, newSize )
    isDebug = 0;
    
    %Extrapolating the data
    if(isempty(inputData))
        outputData=[];
        return;
    end
    outputData = interp1(1:1:max(size(inputData)), inputData, 1:max(size(inputData))/...
        (newSize+1):max(size(inputData)));
    if(max(size(outputData))==102)
        outputData = outputData(1:101);
    end
    if(isDebug)
        disp(max(size(inputData)));
        disp(newSize);
        disp(max(size(outputData)));
    end
end

