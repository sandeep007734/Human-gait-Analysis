%% Function Load Data
% Funtion Load data, as the name tells loads the data from the raw sensor
% data. It also calculates the Time Derivates of the Gyro Values usig the
% Third order approximation

%%%
% Input: Data and the Size of the data
% Output: Timesatmp, Accelerometer Data, Gyroscrope Data, Time Derivative
% of the Gyroscope Data and the Quaternions


    %%%
    % Quaternions provide a convenient mathematical notation for represneting
    % orientations and rotations of objects in three dimensions.
    % Compared to Euler angles they are simpler to compose and avoid the problem of gimbal lock.
    % Compared to rotation matrices they are more numerically stable and may be more efficient.
    % A gyroscope is a device that uses Earth’s gravity to help determine orientation.
    % measure the rate of rotation around a particular axis

function [timestamp,acc_s,gyro_s,gyro_s_derv_data,quarternion] = loadData(data,size_data)

    
    if(size_data==0)
        timestamp=[];
        acc_s=[];
        gyro_s=[];
        gyro_s_derv_data=[];
        quarternion=[];
        
        return;
   
    end
%%
%
% <html>
% <h3> Format of the data as received from the sensors.</h3>
% </html>

%%%
% <html>
% <p><i>ProgrNum,PacketType,AccX,AccY,AccZ,GyrX,GyrY,GyrZ,MagX,MagY,MagZ,Q0,Q1,Q2,Q3,Vbat</i></p>
% </html>

%%%
% The first of the field contains the timestamp as given from the sensors, then it contains the accelerometer data followed by the Gyroscope data and the Quaternions.
% Quaternions are calculated by the sensors itself.

timestamp = data(:,1);
acc_s = data(:, 3:5)';
gyro_s = data(:, 6:8)';

%%%
% Some of the data points need to be modified as per the guidelines given in
% the documents.

% acc_s(:,1)

quarternion = data(:, 12:15)';
acc_s = (156.91)*acc_s/32768;
gyro_s = ((1000*(gyro_s/32768))*(pi/180));

% acc_s(:,1)'
% gyro_s = (1250*gyro_s/32768*pi/180);

%%%
% An approx derivatives of the Gyroscope of the numerical is not possible.
% So an approximation is made using the Thirs order approximation.
%%
deltaT = 2; % In terms of second it means 0.01, i.e. hundreth sample per sec.
gyro_s_derv_data = nan(3, size_data-4*deltaT);
startIdx = (1+2*deltaT);
endIdx = size_data-(2*deltaT);
for i = startIdx:endIdx
    gyro_s_derv_data (:,i-startIdx+1) = (gyro_s(:,i-2*deltaT) - (8*gyro_s(:,i-deltaT)) + (8*gyro_s(:,i+deltaT))...
        - gyro_s(:,i+2*deltaT))/ (12*deltaT);
end

%%%
% There will be some entries in the derviative data which cannot be defined.
% The entries in the beginning and the entries in the end. They need to be
% removed so that in laer part we dont get errors.
% Another way will be to put zeroes where they are not defined. Either case
% is fine with not much change into the final result.
% Fix the timestamp according to the new data points present.
gyro_s = gyro_s (:, startIdx:endIdx);
acc_s = acc_s (:, startIdx:endIdx);
quarternion = quarternion(:, startIdx:endIdx);
timestamp = timestamp(1:size(acc_s,2),1);

