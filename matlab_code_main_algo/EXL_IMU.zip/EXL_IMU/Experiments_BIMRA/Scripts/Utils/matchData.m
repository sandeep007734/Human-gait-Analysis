%The purpose of this functiuon is to figure out the actual start and the
%end of the data in the two files.
%Some time while recording some of the residual data from the past
%recordings creep into, which this functions remove based on the time stamp

%Because of the residues, it is possible that the some of the timestamps
%might be missing from one or both of the files. So we have to shift the
%data accordingly


function [startIdx1,startIdx2,endIdx1,endIdx2] = matchData(tdata,tdata2)
    
    
    %% Run it
    %     disp('Cutom INPUT on in match data, please turn it off for production runs');
%     tdata = tempThighData;
%     tdata2=tempShankData;
    
    % fixing the start index
    %     minVal = min(tdata(1,1),tdata2(1,1));
    %     minVal = min(1,tdata2(1,1));
    %     minVal = min(tdata(1,1),1);
    
    minVal = 1;
    %
    
    startIdx1 = find(tdata(:,1)==minVal,1,'first');
    startIdx2 = find(tdata2(:,1)==minVal,1,'first');
    
    while(isempty(startIdx1)||isempty(startIdx2))
        minVal=minVal+1;
        startIdx1 = find(tdata(:,1)==minVal,1,'first');
        startIdx2 = find(tdata2(:,1)==minVal,1,'first');
    end
    
    % fixing the end index
    minVal = min(tdata(end,1),tdata2(end,1));
    
    endIdx1 = find(tdata(:,1)==minVal,1,'last');
    endIdx2 = find(tdata2(:,1)==minVal,1,'last');
    
    
end