function [startIdx1,startIdx2,endIdx1,endIdx2] = newMatchData(tdata,tdata2)
    %UNTITLED4 Summary of this function goes here
    %   Detailed explanation goes here
    
    disp(tdata(1,1));
    disp(tdata2(1,1));
    
    startIdx1=1;
    startIdx2=1;
    
    endIdx1 = size(tdata,2);
    endIdx2 = size(tdata2,2);
end

