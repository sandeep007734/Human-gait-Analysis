function [ mainStartPoint, peakEnd, dataStart,dataEnd ] = newfindStartAndEndPoints(inputData)
    %% Change
    
    %% Run it
    
   
    
    showPlot =0;
%     inputData= gyro_s_ankle(1,:);
    inpSum = cumsum(abs(inputData));
        
    diffInp = diff(inpSum);
    
    conIds = find(diffInp >= mean(diffInp));
    diffIds = diff(conIds);
    [idVal, idValIDx] = max(diffIds);
    
    valIds = find(diffIds == 1);
    
    
    
    data=[];
    
    
    df = figure; hold on; grid on;
    
    
    
    %         plot([1,1],ylim,'color','red', 'LineWidth',2,'Marker', '*');
    data = [data,1];
    last = 0;
    for j=1:size(valIds,2)
        if(j >1)
            vdiff = conIds(valIds(j)) - conIds(valIds(j-1)) ;
        else
            vdiff=max(diff(valIds));
        end
        if(vdiff >= max(diff(valIds)))
            %              plot([conIds(valIds(j)),conIds(valIds(j))],ylim,'color','red', 'LineWidth',2,'Marker', '*');
            data = [data,conIds(valIds(j))];
        end
    end
    
    %     end
    
    [val vIdx] = sort(diff(data));
    
    mainStartPoint = data(vIdx(size(vIdx,2)));
    peakEnd = data(vIdx(size(vIdx,2)-1));
    dataStart = data(vIdx(size(vIdx,2)-2));
    dataEnd =data(vIdx(size(vIdx,2)-3));
    
    if((dataEnd-dataStart)<100)
        dataStart = peakEnd;
    end
    
    if(showPlot)
        plot(diffInp,'color','blue', 'LineWidth',1,'Marker', '*');
        plot(inputData,'color','black', 'LineWidth',1,'Marker', '*');
        
        plot([mainStartPoint,mainStartPoint],ylim,'color','red', 'LineWidth',2,'Marker', '*');
        plot([peakEnd,peakEnd],ylim,'color','green', 'LineWidth',2,'Marker', '*');
        plot([dataStart,dataStart],ylim,'color','blue', 'LineWidth',2,'Marker', '*');
        plot([dataEnd,dataEnd],ylim,'color','black', 'LineWidth',2,'Marker', '*');
        
        title('Graph showing Marker, Start point and End point. IMU Data','fontsize',20);
        hold off;
    end
    
    
    %      if(showPlot)
    %         df = figure; hold on; grid on;
    %         plot(inputData,'color','black', 'LineWidth',1,'Marker', '*');
    %         plot([mainStartPoint,mainStartPoint],ylim,'color','red', 'LineWidth',2,'Marker', '*');
    %         plot([peakEnd, peakEnd],ylim,'color','red', 'LineWidth',2,'Marker', '*');
    %         plot([dataStart,dataStart],ylim,'color','red', 'LineWidth',2,'Marker', '*');
    %          plot([dataEnd,dataEnd],ylim,'color','red', 'LineWidth',2,'Marker', '*');
    %         title('Graph showing Marker, Start point and End point. IMU Data','fontsize',20);
    %         hold off;
    %      end
    
    
    
end

