function [avgacRKFE,avgacrkaa,avgacrkie, avgAnglex,avgAngley,avgAnglez,imuRKneeAA ] = ...
    quaternionsAngles( quarternion_thigh,quarternion_shank,showDataGraphs,joint, HSFoot,HSShank,structMdxData )

%% Run this
% 
%   joint=2;
%   showDataGraphs=1;
% % oldSP=0;

diffin=0;

thighAnglex = 2*acosd(quarternion_thigh(2,:));
shankAnglex = 2*acosd(quarternion_shank(2,:));

thighAngley = 2*asind(quarternion_thigh(3,:));
shankAngley = 2*asind(quarternion_shank(3,:));

thighAnglez = 2*asind(quarternion_thigh(4,:));
shankAnglez = 2*asind(quarternion_shank(4,:));


imuRKneeAA=[];
if(joint==2)
    diffAnglex = shankAnglex-thighAnglex;       % Knee FE
    diffAngley = (shankAngley);
    %     diffAnglez = shankAnglez-thighAnglez;
    diffAnglez = shankAnglez;
    
    imuRKneeAA = diffAngley;
   
elseif(joint==3)
    diffAnglex = thighAnglex-shankAnglex;
    diffAngley = shankAngley;
    diffAnglez = shankAnglez;
end


% if(~isempty(HSFoot) && ~isempty(HSShank))
%     if(mean(diff(HSFoot)) > mean(diff(HSShank)))
%         [ avgAnglex ] = calcuateAverageIMUData( diffAnglex, HSFoot+diffin );
%         [ avgAngley ] = calcuateAverageIMUData( diffAngley, HSFoot+diffin );
%         [ avgAnglez ] = calcuateAverageIMUData( diffAnglez, HSFoot+diffin );
%     else
%         [ avgAnglex ] = calcuateAverageIMUData( diffAnglex, HSShank+diffin );
%         [ avgAngley ] = calcuateAverageIMUData( diffAngley, HSShank+diffin );
%         [ avgAnglez ] = calcuateAverageIMUData( diffAnglez, HSShank+diffin );
%     end
% else
%     if(~isempty(HSFoot))
%         [ avgAnglex ] = calcuateAverageIMUData( diffAnglex, HSFoot+diffin );
%         [ avgAngley ] = calcuateAverageIMUData( diffAngley, HSFoot+diffin );
%         [ avgAnglez ] = calcuateAverageIMUData( diffAnglez, HSFoot+diffin );
%     elseif(~isempty(HSShank))
%         [ avgAnglex ] = calcuateAverageIMUData( diffAnglex, HSShank+diffin );
%         [ avgAngley ] = calcuateAverageIMUData( diffAngley, HSShank+diffin );
%         [ avgAnglez ] = calcuateAverageIMUData( diffAnglez, HSShank+diffin );
%     else
%         avgAnglex=[];
%         avgAngley=[];
%         avgAnglez=[];
%     end
% end

% xData = avgAnglex;
% yData = -avgAngley;
% zData = avgAnglez;

xData = diffAnglex;
yData = diffAngley;
zData = diffAnglez;

if(isempty(structMdxData))
    
    if(showDataGraphs==1)
        close all;
        figure; grid on;hold on;
        plot( xData,'color','black', 'LineWidth',2);
        title(sprintf('X Axis'),'fontsize',16);
        hold off;
        
        %         figure; grid on;hold on;
        %         plot( yData,'color','black', 'LineWidth',2);
        %         title(sprintf('Y Axis'),'fontsize',16);
        %         hold off;
        
        figure; grid on;hold on;
        plot( zData,'color','black', 'LineWidth',2);
        title(sprintf('Z Axis'),'fontsize',16);
        hold off;
    end
    
    avgacRKFE=[];
    avgacrkaa=[];
    avgacrkie=[];
else
    
    if(joint==2)
        acRKFE = structMdxData.acRKFE;
        acrkaa = structMdxData.acRKAA;
        acrkie = structMdxData.acRKIE;
    elseif(joint==3)
        acRKFE = structMdxData.acRAFE;
        acrkaa = [];
        acrkie = structMdxData.acRAIE;
    end
    
    if(~isempty(acRKFE) && max(size(acRKFE))==203)
        avgacRKFE = (acRKFE(1:101)+acRKFE(103:203))/2;
    else
        avgacRKFE=structMdxData.acmRKFE;
    end
    if(~isempty(acrkaa) && max(size(acrkaa))==203 )
        avgacrkaa = (acrkaa(1:101)+acrkaa(103:203))/2;
    else
        avgacrkaa=structMdxData.acmRKAA;
    end
    if(~isempty(acrkie)&& max(size(acrkie))==203 )
        avgacrkie = (acrkie(1:101)+acrkie(103:203))/2;
    else
        avgacrkie=structMdxData.acmRKIE;
    end
    
    if(showDataGraphs==1)
        close all;
        %         figure; grid on;hold on;
        %         plot( avgAnglex,'color','black', 'LineWidth',2);
        %         plot( avgacRKFE,'color','blue', 'LineWidth',2);
        %         title(sprintf('X Axis'),'fontsize',16);
        %         hold off;
        
        figure; grid on;hold on;
        plot( avgAngley,'color','black', 'LineWidth',2);
        plot( avgacrkie,'color','blue', 'LineWidth',2);
        title(sprintf('Y Axis','Right Knee Interior Exterior'),'fontsize',16);
        hold off;
        %         figure; grid on;hold on;
        %         plot( avgAnglez,'color','black', 'LineWidth',2);
        %         plot( avgacrkaa,'color','blue', 'LineWidth',2);
        %         title(sprintf('Z Axis. Right Knee Abduction Adduction'),'fontsize',16);
        %         hold off;
        
        
    end
    
end

%%

end

%         plot( imuRightKneeFE,'color','black', 'LineWidth',2);
%         if(~isempty(HSFoot))
%             for hsfi = 1:max(size(HSFoot))
%                 plot( [HSFoot(hsfi), HSFoot(hsfi)],ylim,'color','blue', 'LineWidth',2);
%             end
%         end
%           if(~isempty(HSOptical))
%             for hsfi = 1:max(size(HSOptical))
%                 plot( [HSOptical(hsfi), HSOptical(hsfi)],ylim,'color','red', 'LineWidth',2);
%             end
%         end
%          plot( diffAnglez,'color','black', 'LineWidth',2);