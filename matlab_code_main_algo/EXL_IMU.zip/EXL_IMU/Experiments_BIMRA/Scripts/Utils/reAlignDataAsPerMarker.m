function [ imuMarkerIdx,opticalMarkerIdx,imuInputData,bimraRawData]=...
    reAlignDataAsPerMarker( imuMarkerIdx,opticalMarkerIdx,imuInputData,bimraRawData,fileName,plotAlignFigure,saveImagesToFile...
    ,HSFoot,HSShank,HSOptical,plotDesc)



 diffinData = abs(opticalMarkerIdx - imuMarkerIdx);
    zm = zeros(1,diffinData);
    if(imuMarkerIdx < opticalMarkerIdx)
        % The optical data has more points, so adjust the IMU data
        % accordingly.
        imuInputData = [zm , imuInputData];
        minSize = min(max(size(imuInputData)),max(size(bimraRawData)));
        imuInputData = imuInputData(1:minSize);
        bimraRawData = bimraRawData(1:minSize);

        
    else
        % add zeros to the Optical
        bimraRawData = [zm, bimraRawData];
    end
    
    if(plotAlignFigure)
        plotAlignFigureCode(bimraRawData,imuInputData,fileName,saveImagesToFile,HSFoot,HSShank,HSOptical,plotDesc);
    end

end

