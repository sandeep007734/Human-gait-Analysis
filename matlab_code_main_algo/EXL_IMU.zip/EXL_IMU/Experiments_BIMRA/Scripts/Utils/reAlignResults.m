% Aligning the IMU data and the system data using the marker from
% both of the systems. It just adds zero to the data where the
% marker appears first.
if(validBimraData && compareWithBimra && ~isempty(opticalMarkerIdx) && ~isempty(imuMarkerIdx))
    disp('Realigning the Data');
    diffinData = abs(opticalMarkerIdx - imuMarkerIdx);
    zm = zeros(1,diffinData);
    if(imuMarkerIdx < opticalMarkerIdx)
        
        % adjust the heel strike and toe off values accordingly
        HSFoot = HSFoot+diffinData;
        TOFoot = TOFoot+diffinData;
        HSShank = HSShank+diffinData;
        TOShank = TOShank+diffinData;
    else
        
        % adjust the heel strike and toe off values accordingly
        HSOptical = HSOptical + diffinData;
        TOOptical = TOOptical+diffinData;
    end
    
    if(~isempty(imuRightKneeFE))
        [ imuMarkerIdx,opticalMarkerIdx,imuRightKneeFE,jrkDataZ]=...
            reAlignDataAsPerMarker( imuMarkerIdx,opticalMarkerIdx,imuRightKneeFE,jrkDataZ,rightThighDataFiles(num,:),plotAlignFigure,saveImagesToFile...
            ,HSFoot,HSShank,HSOptical,'Right Knee FE');
        
        HSFoot(find(HSFoot > max(size(imuRightKneeFE))))=[];
        HSShank(find(HSShank > max(size(imuRightKneeFE))))=[];
        TOFoot(find(TOFoot > max(size(imuRightKneeFE))))=[];
        TOShank(find(TOShank > max(size(imuRightKneeFE))))=[];
    end
    
    if(~isempty(imuRightAnkleDP))
        [ imuMarkerIdx,opticalMarkerIdx,imuRightAnkleDP,aRAFE]=...
            reAlignDataAsPerMarker( imuMarkerIdx,opticalMarkerIdx,imuRightAnkleDP,aRAFE,rightThighDataFiles(num,:),plotAlignFigure,saveImagesToFile...
            ,HSFoot,HSShank,HSOptical,'Right Ankle Dors  Plantarflex (FE)');
        
    end
    
    if(~isempty(imuRightKneeAA))
        [ imuMarkerIdx,opticalMarkerIdx,imuRightKneeAA,jrkDataY]=...
            reAlignDataAsPerMarker( imuMarkerIdx,opticalMarkerIdx,imuRightKneeAA,jrkDataY,rightThighDataFiles(num,:),plotAlignFigure,saveImagesToFile...
            ,HSFoot,HSShank,HSOptical,'Right Knee Abduction Adduction (Valgus Varus)');
        
    end
    
    if(~isempty(imuRightKneeIE))
        [ imuMarkerIdx,opticalMarkerIdx,imuRightKneeIE,tmp]=...
            reAlignDataAsPerMarker( imuMarkerIdx,opticalMarkerIdx,imuRightKneeIE,jrkDataX,rightThighDataFiles(num,:),plotAlignFigure,saveImagesToFile...
            ,HSFoot,HSShank,HSOptical,'Right Knee Internal External Rotation');
    end
    
    disp('reAlignResults:" CHANGE HIP FE COMPARE BIMRA COUTERPART');
    if(~isempty(imuRightHipFE))
        [ imuMarkerIdx,opticalMarkerIdx,imuRightHipFE,tmp]=...
            reAlignDataAsPerMarker( imuMarkerIdx,opticalMarkerIdx,imuRightHipFE,jrkDataX,rightThighDataFiles(num,:),plotAlignFigure,saveImagesToFile...
            ,HSFoot,HSShank,HSOptical,'Right Hip Internal Flexion Extensio Rotation');
    end
    
    if(~isempty(imuRightAnkleIE))
        [ imuMarkerIdx,opticalMarkerIdx,imuRightAnkleIE,tmp]=...
            reAlignDataAsPerMarker( imuMarkerIdx,opticalMarkerIdx,imuRightAnkleIE,jrkDataX,rightThighDataFiles(num,:),plotAlignFigure,saveImagesToFile...
            ,HSFoot,HSShank,HSOptical,'Right Ankle Internal External Rotation');
    end
    if(~isempty(imuRightHipAA))
        [ imuMarkerIdx,opticalMarkerIdx,imuRightHipAA,tmp]=...
            reAlignDataAsPerMarker( imuMarkerIdx,opticalMarkerIdx,imuRightHipAA,jrkDataX,rightThighDataFiles(num,:),plotAlignFigure,saveImagesToFile...
            ,HSFoot,HSShank,HSOptical,'Right Hip abduction adduction');
        
    end
    
else
    % We cannot sync the data.
    if(compareWithBimra)
        disp('Cannot sync the data as there is some problem with the bimra data');
    else
        disp('No Need to Realign, Comparing with BIMRA data is SWITCHED OFF');
    end
    minSize = max(size(imuRightKneeFE));
    
end