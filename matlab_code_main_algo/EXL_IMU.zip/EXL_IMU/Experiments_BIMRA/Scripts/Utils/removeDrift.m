function [dFreeDataTwo] = removeDrift(inputData,showPlot)
    %% run
    %     disp('Local active in removeDrift');
    %     integ2 = angle_joint_axes(heelStrikeandToeff(1):heelStrikeandToeff(size(HSandTO,2)));
    %     showPlot = 1;
    %
%     
%     inputData = imuRightKneeFE(imuMarkerIdx:end);
%     showPlot=1;
%     close all;
    
    timestamp = [1:max(size(inputData))];
    
    %     % IIR
    %     % Butterworth Filter, Given a order, and the cutoff frequency.
    %     %     [b,a] = butter(4,0.83333333);
    %     [b,a] = butter(5,.99);
    %     dFree = filter(b,a,dFreePrev);
    
    
    %1st differentiate
    
    dfDiffOne  = diff(inputData)./diff(timestamp);
    dfDiffOne = [0,dfDiffOne];
    dfDiffTwo  = diff(dfDiffOne)./diff(dfDiffOne);
    dfDiffTwo = [0,dfDiffTwo];
    
    dfInteOne = cumtrapz(timestamp(1:size(dfDiffTwo,2)),dfDiffTwo);
    dfInteTwo = cumtrapz(timestamp(1:size(dfInteOne,2)),dfInteOne);
    
    dfInteTwo = dfInteTwo + inputData(1,1);
    
    n1 = max(dfInteOne)/mean(inputData);
    n2 = max(dfInteTwo)/mean(inputData);
    
    diversionOne = dfInteOne./n1;
    diversionTwo = dfInteTwo./n2;
    
    if(diversionOne(end) < diversionOne(1))
        dFreeDataOne = inputData(1:size(dfInteOne,2)) + diversionOne;
    else
        dFreeDataOne = inputData(1:size(dfInteOne,2)) - diversionOne;
    end
    
    if(diversionTwo(end)< diversionTwo(1))
        dFreeDataTwo = inputData(1:size(dfInteTwo,2)) + diversionTwo;
    else
        dFreeDataTwo = inputData(1:size(dfInteTwo,2)) - diversionTwo;
    end
    
    dFreeDataThree = (dFreeDataOne+dFreeDataTwo)./2;
    
    if(showPlot)
        figure;
        hold on; grid on;
        %         plot(timestamp(1:size(dfDiffOne,2)),(dfDiffOne),'color','Green', 'LineWidth',2,'Marker', '*');
        %         plot(timestamp(1:size(dfDiffTwo,2)),(dfDiffTwo),'color','Black', 'LineWidth',2,'Marker', '*');
        
%         plot(timestamp(1:size(dfDiffTwo,2)),(dfInteOne./n1),'color','Green', 'LineWidth',2,'Marker', '*');
%         plot(timestamp(1:size(dfDiffTwo,2)),(dfInteTwo./n2),'color','Red', 'LineWidth',2,'Marker', '*');
        
                plot(timestamp(1:size(inputData,2)),(inputData),'color','Blue', 'LineWidth',2,'Marker', '*');
        
%                 plot(timestamp(1:size(dFreeDataOne,2)),(dFreeDataOne),'color','Red', 'LineWidth',2,'Marker', '*');
                plot(timestamp(1:size(dFreeDataTwo,2)),(dFreeDataTwo),'color','Green', 'LineWidth',2,'Marker', '*');
                plot(timestamp(1:size(dFreeDataThree,2)),(dFreeDataThree),'color','Black', 'LineWidth',2,'Marker', '*');
        ylabel('Angle Thigh');
        xlabel('TimeStamp');
        %         legend('Input Data','Drift Free One','Drift Free Two','Drift Free Three','Location','northeast');
% %         title('Drift in Z axes. Thigh Angle');%
        hold off;
    end
    
    
