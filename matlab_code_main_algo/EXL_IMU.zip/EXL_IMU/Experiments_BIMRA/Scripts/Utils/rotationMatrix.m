function [angle_rot_mat] = rotationMatrix(gyro_s_knee,quarternion_knee,quarternion_shank,makeChanges,calibrationDataFile)
    
    %% Getting the angle from the angle rotation matrix
    
    load(calibrationDataFile);
    % load('calibration.mat');
    
    if makeChanges ==1
        j1_valf = - j1_valf;
        j2_valf = -j2_valf;
    end
    
    angle_rot_mat = nan(1, size(gyro_s_knee,2));
    for i=1:size(gyro_s_knee,2)
        
        [roll, pitch, yaw] = quat2angle(quarternion_knee(:,i)','XYZ');
        roll2=roll;
        pitch2=pitch;
        yaw2=yaw;
        
        
        %Some modification based on the Orientation of the sensors
        % TODO: Need to automate this.
        if makeChanges == 1
            %yaw = -yaw
            %pitch = -pitch
%             roll = -roll;
        end
        R1 = [cos(pitch)*cos(yaw) (sin(roll)*sin(pitch)*cos(yaw))-(cos(roll)*sin(yaw)) (cos(roll)*sin(pitch)*cos(yaw))+(sin(roll)*sin(yaw));
            cos(pitch)*sin(yaw)  (sin(roll)*sin(pitch)*sin(yaw))+(cos(roll)*cos(yaw))  (cos(roll)*sin(pitch)*sin(yaw))-(sin(roll)*cos(yaw));
            -sin(pitch) sin(roll)*cos(pitch) cos(roll)*cos(pitch)];
        
        [roll, pitch, yaw] = quat2angle(quarternion_shank(:,i)','XYZ');
        
        
        %Some modification based on the Orientation of the sensors
        % TODO: Need to automate this
        if makeChanges == 1
            %yaw = -yaw
            %pitch = -pitch
%             roll = -roll;
        end
        
        if(i>3300)
            fig = figure; hold on; grid on;
            disp(sprintf('Y: %f, P: %f, R: %f\n',radtodeg(yaw),radtodeg(pitch),radtodeg(roll)));
            drawCuboid([15 20 20   12 18 5   radtodeg(yaw2) radtodeg(pitch2) radtodeg(roll2)], 'FaceColor', 'g');
            drawCuboid([45 40 40   12 18 5   radtodeg(yaw) radtodeg(pitch) radtodeg(roll)], 'FaceColor', 'r');
            axis equal;
            axis([0 60 0 60 0 60])
            view(3);
            grid on;
            title(sprintf('This is %d',i));
            xlabel('X Axis: Roll');
            ylabel('Y Axis: Pitch');
            zlabel('Z Axis: Yaw');
            pause(.01);
            if(i ~= size(gyro_s_knee,2))
                clf(fig);
            end
        end
        
        R2 = [cos(pitch)*cos(yaw) (sin(roll)*sin(pitch)*cos(yaw))-(cos(roll)*sin(yaw)) (cos(roll)*sin(pitch)*cos(yaw))+(sin(roll)*sin(yaw));
            cos(pitch)*sin(yaw)  (sin(roll)*sin(pitch)*sin(yaw))+(cos(roll)*cos(yaw))  (cos(roll)*sin(pitch)*sin(yaw))-(sin(roll)*cos(yaw));
            -sin(pitch) sin(roll)*cos(pitch) cos(roll)*cos(pitch)];
        
        
        a = R1*cross(j1_valf,[2,0,0]');
        b = R2 *cross(j2_valf,[2,0,0]');
        
        angle_rot_mat(i) = radtodeg(atan2(norm(cross(a,b)), dot(a,b)));
    end
    angle_rot_mat = -(angle_rot_mat - angle_rot_mat(1));
    
    %% plot
    
    % figure;
    % hold on;
    % grid on;
    % plot(angle_rot_mat);
