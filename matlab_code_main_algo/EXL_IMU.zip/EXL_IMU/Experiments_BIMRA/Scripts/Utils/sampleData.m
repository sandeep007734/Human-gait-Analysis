if(sample_rate >1)
    
    gyro_s_thigh = gyro_s_thigh(:, 1:sample_rate:end);
    gyro_s_shank = gyro_s_shank(:, 1:sample_rate:end);
    if(isFootDataPresent)
        gyro_s_ankle = gyro_s_ankle(:, 1:sample_rate:end);
    end
    gyro_s_derv_thigh = gyro_s_derv_thigh(:, 1:sample_rate:end);
    gyro_s_derv_shank = gyro_s_derv_shank(:, 1:sample_rate:end);
    if(isFootDataPresent)
        gyro_s_derv_ankle = gyro_s_derv_ankle(:, 1:sample_rate:end);
    end
    
    acc_s_thigh = acc_s_thigh(:, 1:sample_rate:end);
    acc_s_shank = acc_s_shank(:, 1:sample_rate:end);
    if(isFootDataPresent)
        acc_s_ankle = acc_s_ankle(:, 1:sample_rate:end);
    end
    
    timestamp=timestamp(1:sample_rate:end);
    
end
