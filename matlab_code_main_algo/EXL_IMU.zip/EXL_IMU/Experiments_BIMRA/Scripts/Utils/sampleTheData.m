
    
    gyro_s_thigh = gyro_s_thigh(:, 1:sample_rate:end);
    gyro_s_shank = gyro_s_shank(:, 1:sample_rate:end);
    if(rightFootDataPresent)
        gyro_s_foot = gyro_s_foot(:, 1:sample_rate:end);
    end
    gyro_s_derv_thigh = gyro_s_derv_thigh(:, 1:sample_rate:end);
    gyro_s_derv_shank = gyro_s_derv_shank(:, 1:sample_rate:end);
    if(rightFootDataPresent)
        gyro_s_derv_foot = gyro_s_derv_foot(:, 1:sample_rate:end);
    end
    
    acc_s_thigh = acc_s_thigh(:, 1:sample_rate:end);
    acc_s_shank = acc_s_shank(:, 1:sample_rate:end);
    if(rightFootDataPresent)
        acc_s_foot = acc_s_foot(:, 1:sample_rate:end);
    end
    
    timestamp=timestamp(1:sample_rate:end);
    

