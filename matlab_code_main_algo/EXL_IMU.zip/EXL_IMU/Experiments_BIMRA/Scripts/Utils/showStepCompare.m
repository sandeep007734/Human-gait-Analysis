function[]=showStepCompare(workWith, filename, saveToFile,bimraFile,bimraFolder,num,name,withDebug)
    
    disp(strcat('For: ',name));
    %% Get Average Step for our sensors
    %                 avgStep = getSteps(workWith,filename1,1,0);
    debug = 0;
    [avgStepmax,avgStepMin] = getNewSteps(workWith,withDebug);
    
    if(debug)

        h=figure;
        hold on; grid on;
        plot(workWith,'color','Blue', 'LineWidth',3,'Marker', '*');
        set(gca,'fontsize',20);
        set(h,'units','normalized','outerposition',[0 0 1 1]);
        xlabel('Data Points','fontsize',20);
        ylabel('Knee Joint Angle (Degrees)','fontsize',20);
        title('Knee Joint Angle for two Steps for a Normal Person','fontsize',30);
        hold off;
    end
    
    avgStep = avgStepMin;
    %
    %% Bimra Data
    debug=0;
    if(debug)
        num=1;
    end
    
    bimraDataFile = '_dir/acmRKFE_data';
    bimraScaleFactor = '_dir/acmRKFE_scalefactor';
    isMean=1;
    
    bimraDataFile = '_dir/acRKFE_data';
    bimraScaleFactor = '_dir/acRKFE_scalefactor';
    isMean=0;
    
    bimraFilename = bimraFile(num,:);
    dataFileName = strcat(bimraFolder,bimraFilename,bimraDataFile);
    bimraData = importdata(dataFileName);
    
    %removing zero by average
    bimraData((find(bimraData == 0))) = (bimraData(find(bimraData == 0)+1)+bimraData(find(bimraData == 0)-1))/2;
    %divide by scale factor
    scaleFactor = importdata(strcat(bimraFolder,bimraFilename,bimraScaleFactor));
    bimraData = bimraData/scaleFactor;
    
    if(debug)
%         
        h=figure;
        hold on; grid on;
        plot(bimraData,'color','Blue', 'LineWidth',3,'Marker', '*');
        set(gca,'fontsize',20);
        set(h,'units','normalized','outerposition',[0 0 1 1]);
        xlabel('Data Points','fontsize',20);
        ylabel('Knee Joint Angle (Degrees)','fontsize',20);
        title('Knee Joint Angle for two Steps for a Normal Person','fontsize',30);
        hold off;
    end
    
    if(isMean)
        avgStepBimra = bimraData(1:2:end);
    else
        avgStepBimra = getBimraSteps(bimraData);
    end
    
    
    
    
    
    %% Plot them
    h = figure('units','normalized','outerposition',[0 0 1 1]);
    %         set(h,'Visible','off');
    hold on; grid on;
    
    %Extrapolating the data
    avgStepBimraInter = interp1(1:1:size(avgStepBimra,2), avgStepBimra, 1:size(avgStepBimra,2)/...
        (size(avgStep,2)+1):size(avgStepBimra,2));
    fprintf('Bimra Size %d, avgStep Size %d, bimraInerpolate Size %d ',size(avgStepBimra,2),size(avgStep,2),size(avgStepBimraInter,2));
    
    plot(avgStep,'color','red', 'LineWidth',2,'Marker', 's');
    plot(avgStepBimraInter,'color','blue', 'LineWidth',2,'Marker', 'd');
    
    smallIdx = min(size(avgStepBimraInter,2),size(avgStep,2));
    
    rmse = sqrt(sum((avgStepBimraInter(1:smallIdx)-avgStep(1:smallIdx)).^2)/size(avgStep(1:smallIdx),2));
    
    title(sprintf('Average Step Comparison of %s and %s.\n RMSE: %f using %s',...
        filename,bimraFilename,rmse,name),'fontsize',20);
    xlabel('Sample Points','fontsize',20);
    ylabel('Knee Joint Angle','fontsize',20);
    legend('IMU Sensors','BIMRA acmRKFE','Location','northeast');
    set(gca,'fontsize',20);
    set(h,'units','normalized','outerposition',[0 0 1 1]);
    
    if(saveToFile)
        saveas(h,strcat(strtok(filename,'.'),'_compare_acmrkfe.jpg'),'jpg');
    end
    hold off;
    
end
