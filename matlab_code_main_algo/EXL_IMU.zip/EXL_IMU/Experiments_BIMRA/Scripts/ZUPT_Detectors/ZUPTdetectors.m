function [ shoe, mv, mag, are, minAre, fsIdx, feIdx ] = ZUPTdetectors( gyroData, accData, W )
    %% Load data
%         W=10;
    
%     z = figure;
%     figure(z);
%     set(z,'Visible','off');
%     grid on;
%     hold on;
%     plot(gyroData,'color','Red', 'LineWidth',2,'Marker', '*');
%     %
    
    s = size(gyroData,2);
    n = floor(s/W);
    
    shoe=nan(1,n);
    mv=nan(1,n);
    mag=nan(1,n);
    are=nan(1,n);
    
    sIdx = 1;
    
    for i=1:n
        eIdx = i*W;
        %         if(i==n)
        %             eIdx = size(gyroData,2);
        %         end
        
%         plot([eIdx,eIdx],ylim,'linewidth',2,'color','black');
        
        gyro = gyroData(sIdx:eIdx);
        acc = accData(sIdx:eIdx);
        
        sIdx = eIdx+1;
        
        meanGyro = mean(gyro);
        meanAcc = mean(acc);
        
        wSize = size(gyro,2);
        
        varGyro = var(gyro);
        varAcc = var(acc);
        
        g= 9.81;
        
        %%% shoe
        
        t1 = acc-g*(meanAcc/meanAcc*meanAcc);
        t1 = t1*t1';
        % t1 = t1.^2;
        t1 = t1/varAcc;
        
        t2 = gyro*gyro';
        % t2 = gyro.^2;
        t2 = t2/varGyro;
        
        vshoe = sum((t1+t2))/wSize;
        shoe(1,i) = vshoe;
        
        %%% MV Moving Variance Detector
        vmv = ((acc-meanAcc)*(acc-meanAcc)')/(varAcc*wSize);
        mv(1,i)=vmv;
        
        %%% MAG  Acceleration Magnitude Detector
        vmag = ((acc-g)*(acc-g)')/(varAcc*wSize);
        mag(1,i) = vmag;
        
        %%% ARE  Angular Rate Energy Detector
        vare = (gyro*gyro')/(varGyro*wSize);
        are(1,i) = vare;
        
    end
    
    stats = shoe;
    
    minAre = min(stats);
%     minAre = minAre(1,1);
    minIdx =find(stats==minAre);
    minIdx = minIdx(1,1);
    if(minIdx==n)
        fsIdx = wSize*(minIdx-1);
        feIdx = s;
    elseif(minIdx==1)
        fsIdx = 1;
        feIdx = wSize;
    else
        fsIdx = wSize*(minIdx-1);
        feIdx = wSize*(minIdx);
    end
    
    if(feIdx>s)
        feIdx=s;
    end
%     hold off;
    
    % disp(sprintf('Data size is %d, total div is %d minIDx is %d sidx is %d eidx is %d',s,n,minIdx,fsIdx,feIdx));
end

