function [ val ] = calib_calc_e( phi1, theta1, phi2, theta2, g1x, g1y, g1z, g2x, g2y, g2z )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
val = ((g1y*cos(phi1)*cos(theta1) - g1x*cos(phi1)*sin(theta1))^2 + (g1x*sin(phi1)...
- g1z*cos(phi1)*cos(theta1))^2 + (g1y*sin(phi1) - g1z*cos(phi1)*sin(theta1))^2)^(1/2)...
- ((g2y*cos(phi2)*cos(theta2) - g2x*cos(phi2)*sin(theta2))^2 + (g2x*sin(phi2)...
- g2z*cos(phi2)*cos(theta2))^2 + (g2y*sin(phi2) - g2z*cos(phi2)*sin(theta2))^2)^(1/2);


end

