function [rmse_x_knee, rmse_x_ankle  ] = handleCalibration( rightKneeRawCalibFiles,rightFootRawCalibFiles,rightThighDataFiles,rightShankDataFiles,rightFootDataFiles, num,...
    useWalkasCalibration,rightKneeProcessedCalibFile,runCalibrationAnyWay, folder,rightFootDataPresent,...
    rightFootProcessedCalibFile,num_of_iterations, threshold,scale_factor,showDataGraphs)


%addpath('/home/sandeep/IMU/EXL_IMU/Experiments_BIMRA/Scripts');

%% Calibration of the Sensors.
% Calibration process basically gives us a rough estimate of the positon of
% the sensors with respect to the joints, which will be used later in
% determining the various Gait Parameters, such as Knee Flexion Extension,
% Ankle Flexion Extension etc. This is the most costly step in the execution of the code, so make sure
% to run it when this is absolutely necessary.
rmse_x_knee = [];
rmse_x_ankle = [];

if(useWalkasCalibration)
    rightKneeRawCalibFiles = [rightThighDataFiles(num,:);rightShankDataFiles(num,:)];
    if(~isempty(rightFootDataFiles))
        rightFootRawCalibFiles = [rightShankDataFiles(num,:);rightFootDataFiles(num,:)];
    else
        rightFootRawCalibFiles=[];
    end
    disp('=======================Using walk as calibration=======================');
end

% Check if the calibration file exists.
% If not then run the calibration code else just use the saved result.
if (exist(rightKneeProcessedCalibFile, 'file') == 2 && (runCalibrationAnyWay==0))
    disp('Calibration File Found for Knee Joint');
else
    disp('Doing Knee Calibration');
    joint = 'Knee';   % Unused for now, add _knee to save the calib result as j1_valf_knee
    [rmse_x_knee] = doCalibration(folder,rightKneeRawCalibFiles,rightKneeProcessedCalibFile,...
        num_of_iterations,threshold,scale_factor,joint,showDataGraphs);
    %         disp('Calibration Done');
end


% showDataGraphs = 0;
if(rightFootDataPresent)
    %    Check the calibration of the foot sensors
    if (exist(rightFootProcessedCalibFile, 'file') == 2 && (runCalibrationAnyWay==0))
        disp('Calibration File Found for Ankle Joint');
    else
        if(~isempty(rightFootRawCalibFiles))
            disp('Doing Ankle Calibration');
            joint = 'Ankle';   % Unused for now, add _knee to save the calib result as j1_valf_knee
            [rmse_x_ankle] = doCalibration(folder,rightFootRawCalibFiles,rightFootProcessedCalibFile,...
                num_of_iterations,threshold,scale_factor,joint,showDataGraphs);
        else
            disp('Files Missins Internal');
        end
    end
else
    disp('No Foot Files');
end




end

