
function [structMdxData]=getMDXData(bimraFileName,bimraFolder)

%% Specify the features that needs to be read and what modifications needs to be applied to them.
%     disp('CUSTOM CONTROL ON IN GETMDXDATA');
%      bimraFileName = bimraFiles(4,:)    ;


outVars = {'acmRKFE','acRKFE','jrkDataZ',...
    'HSOptical','TOOptical',...
    'acmRAFE','acRAFE','aRAFE','dseqRSTRIDE',...
    'acmRKAA','acRKAA','acmRKIE','acRKIE','acRAIE','acmRAIE',...
    'acRHPFE','acmRHPFE','acRHPAA','acmRHPAA','acRHPIE','acmRHPIE'};

dataFiles = {'acmRKFE_data','acRKFE_data','jRK_data',...
    'eRHS_data','eRTO_data',...
    'acmRAFE_data','acRAFE_data','aRAFE_data','dseqRSTRIDE_data',...
    'acmRKAA_data','acRKAA_data','acmRKIE_data','acRKIE_data','acRAIE_data','acmRAIE_data',...
    'acRHPFE_data','acmRHPFE_data','acRHPAA_data','acmRHPAA_data','acRHPIE_data','acmRHPIE_data'};

scaleFactorFiles = {'acmRKFE_scalefactor','acRKFE_scalefactor','jRK_scalefactor',...
    'eRHS_scalefactor','eRTO_scalefactor',...
    'acmRAFE_scalefactor','acRAFE_scalefactor','aRAFE_scalefactor','dseqRSTRIDE_scalefactor',...
    'acmRKAA_scalefactor','acRKAA_scalefactor','acmRKIE_scalefactor',...
    'acRKIE_scalefactor','acRAIE_scalefactor','acmRAIE_scalefactor',...
    'acRHPFE_scalefactor','acmRHPFE_scalefactor','acRHPAA_scalefactor','acmRHPAA_scalefactor','acRHPIE_scalefactor','acmRHPIE_scalefactor'};

dataFiles = char(dataFiles);

scaleFactorFiles = char(scaleFactorFiles);

bimraDataStartPoint = 'jRK_start';

% bimraFolder = 'Experiments_BIMRA_2/3dSofia/';

%%% Read the features from the files and make suitable changes

structMdxData = struct;

for di=1:max(size(outVars))
    fld= outVars{di};
    dataFileName = strcat(bimraFolder,bimraFileName,'_dir/',dataFiles(di,:));
    scaleFileName = strcat(bimraFolder,bimraFileName,'_dir/',scaleFactorFiles(di,:));
    try
        structMdxData.(fld) = importdata(dataFileName);
        scaleFactor = importdata(scaleFileName);
        structMdxData.(fld) = structMdxData.(fld)/scaleFactor;
    catch
        structMdxData.(fld)=[];
    end
end

try
    dataFileName = strcat(bimraFolder,bimraFileName,'_dir/',bimraDataStartPoint);
    startPoint = importdata(dataFileName);
catch
    startPoint=0;
end
%%%

structMdxData.acmRKFE = structMdxData.acmRKFE(2:2:end);
structMdxData.acmRAFE = structMdxData.acmRAFE(2:2:end);
structMdxData.acmRHPFE = structMdxData.acmRHPFE(2:2:end);


structMdxData.HSOptical = fix((structMdxData.HSOptical*100-startPoint));
structMdxData.TOOptical = fix((structMdxData.TOOptical*100-startPoint));

%tmp = structMdxData.jrkDataZ;
structMdxData.jrkDataX = structMdxData.jrkDataZ(1:3:end);
structMdxData.jrkDataY = structMdxData.jrkDataZ(2:3:end);
structMdxData.jrkDataZ = structMdxData.jrkDataZ(3:3:end);

%%% Get the marker position
if(isempty(structMdxData.jrkDataZ))
    disp('Bimra RAW Data is Missing');
    % structMdxData.opticalMarkerIdx=[];
    
else
    % normal peak in the graph.
    [markerMax, structMdxData.opticalMarkerIdx] = max(structMdxData.jrkDataZ);
    [pval, pidx] = findpeaks(structMdxData.jrkDataZ(structMdxData.opticalMarkerIdx:end),'NPeaks',2,'MinPeakHeight',markerMax*.8);
    
    
    if((structMdxData.opticalMarkerIdx > min(min(structMdxData.HSOptical),min(structMdxData.TOOptical))) || (markerMax < mean(pval)*(1.2)))
        structMdxData.opticalMarkerIdx=[]; % No marker present in the data.
    end
end
%%% Calculate the Optical Raw Average

%     structMdxData.avgFEJrk  = calcStepAverageRaw( structMdxData.jrkDataZ,structMdxData.HSOptical );
%     structMdxData.avgaRAFE  = calcStepAverageRaw( structMdxData.aRAFE,structMdxData.HSOptical );

%%% calculate the Optical Average

structMdxData.avgacRKFE = calcStepAverageOptical( structMdxData.acRKFE,structMdxData.HSOptical );
structMdxData.avgacRKAA = calcStepAverageOptical( structMdxData.acRKAA,structMdxData.HSOptical );
structMdxData.avgacRKIE = calcStepAverageOptical( structMdxData.acRKIE,structMdxData.HSOptical );

structMdxData.avgacRAFE = calcStepAverageOptical( structMdxData.acRAFE,structMdxData.HSOptical );
% structMdxData.avgacRAAA = calcStepAverageOptical( structMdxData.acRAAA,structMdxData.HSOptical );
structMdxData.avgacRAIE = calcStepAverageOptical( structMdxData.acRAIE,structMdxData.HSOptical );

structMdxData.avgacRHPFE = calcStepAverageOptical( structMdxData.acRHPFE,structMdxData.HSOptical );
structMdxData.avgacRHPAA = calcStepAverageOptical( structMdxData.acRHPAA,structMdxData.HSOptical );
structMdxData.avgacRHPIE = calcStepAverageOptical( structMdxData.acRHPIE,structMdxData.HSOptical );

%%
end