        % Online angle_joint_axes calculation
        % TODO the error seesm to be higher in the online version. Please fix
        % it.
        if(false)
            imuRightKneeFE  = [];
            prevJointAxisAngle = 0;
            for i=2:size(gyro_s_thigh,2)
                forAnkle = 0;
                [ currJointAxisAngle ] = onlineJointCenterAndAxes( j1_valf_knee, j2_valf_knee,prevJointAxisAngle,...
                    gyro_s_thigh(:,i-1),gyro_s_shank(:,i-1),makeChanges,forAnkle );
                
                imuRightKneeFE = [imuRightKneeFE, currJointAxisAngle];
                prevJointAxisAngle = currJointAxisAngle;
                
            end
            imuRightKneeFE = imuRightKneeFE(2:end);
            endDataPoint = endDataPoint-2;
        end
