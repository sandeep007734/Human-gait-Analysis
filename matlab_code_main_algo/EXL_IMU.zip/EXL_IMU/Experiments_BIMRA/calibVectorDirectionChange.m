%% Run

A = rand(3, 2)*2 - 1;
figure(1); clf;

j1_valf = j1_valf_x;
j2_valf = j2_valf_x;
forAnkle=0;
change = [j1_valf,j2_valf];
if(abs(j1_valf(1)) < abs(j1_valf(3)))
    j1_valf = flip(j1_valf);
    j2_valf = flip(j2_valf);
end
if(forAnkle)
    if(j1_valf(1)>0)
        j1_valf(1) =  -j1_valf(1);
    end
    if(j1_valf(2)<0)
        j1_valf(2) =  -j1_valf(2);
    end
    if(j1_valf(3)>0)
        j1_valf(3) =  -j1_valf(3);
    end
    
    
    if(j2_valf(1)>0)
        j2_valf(1) =  -j2_valf(1);
    end
    if(j2_valf(2)<0)
        j2_valf(2) =  -j2_valf(2);
    end
    if(j2_valf(3)>0)
        j2_valf(3) =  -j2_valf(3);
    end
else
    if(j1_valf(1)<0)
        j1_valf(1) =  -j1_valf(1);
    end
    if(j1_valf(2)<0)
        j1_valf(2) =  -j1_valf(2);
    end
    if(j1_valf(3)>0)
        j1_valf(3) =  -j1_valf(3);
    end
    
    
    if(j2_valf(1)<0)
        j2_valf(1) =  -j2_valf(1);
    end
    if(j2_valf(2)>0)
        j2_valf(2) =  -j2_valf(2);
    end
    if(j2_valf(3)>0)
        j2_valf(3) =  -j2_valf(3);
    end
end
change = [change,j1_valf,j2_valf];
drawVector(change, {'a1', 'b1','a2','b2'});

view(60,10)
title('Plot 3D vectors with drawVector()')
