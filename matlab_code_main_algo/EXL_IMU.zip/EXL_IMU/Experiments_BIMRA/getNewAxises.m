function [ y_new, z_new] = getNewAxises(x_new)

%% run it
addpath(genpath('.'));
showPlot = 0;


disp('LOCAL CHANGES IN GETNEWAXISES');
showPlot = 1;
x_new = [.4,.3,.7];
% x_new = modifyCalibVector(x_new,x_new,0);
x_new= x_new/norm(x_new);
close all;


x_axis = [1;0;0];
y_axis = [0;1;0];
z_axis = [0;0;1];

a = x_axis;
b = x_new;

rotAngleAndAxis= vrrotvec(a,b);
m = vrrotvec2mat(rotAngleAndAxis);

x_new_check = m*x_axis;
y_new = m*y_axis;
z_new = m*z_axis;

x_new_check = x_new_check/norm(x_new_check);
y_new = y_new/norm(y_new);
z_new = z_new/norm(z_new);

if(showPlot)
    drawVector(x_new,{'j1'});
    hold on;
%     drawVector(x_new_check,{'A'});
%     hold on;
    drawVector(y_new,{'B'});
    hold on;
    drawVector(z_new,{'C'});
    hold off;
    
    fprintf('%f , %f, %f\n',dot(x_new_check, y_new),...
dot(x_new_check, z_new),...
dot(z_new, y_new));

end


end