
%% Intialize the Parameters and select the Experiment
if(isunix)
    cd '/home/sandeep/IMU/EXL_IMU/Experiments_BIMRA';
    addpath(genpath('/home/sandeep/IMU/EXL_IMU/Experiments_BIMRA/Scripts'));
else
    cd 'D:\gait-analysis-matlab-code\EXL_IMU\Experiments_BIMRA';
    addpath(genpath('D:\gait-analysis-matlab-code\EXL_IMU\Experiments_BIMRA\Scripts'));
end

initVars();
%% Custom control. Set it to 1 to run only one walk. Set which walk to run
% inside the main loop custom control.
noOfWalkingTrials=1;
%% Calculate the Gait Parameters
% Steps involved in the process:
% if(noOfWalkingTrials > 1)
kneeFERMSEarr = zeros(noOfWalkingTrials,1);
ankleDPRMSEarr = zeros(noOfWalkingTrials,1);
hipFERMSEarr = zeros(noOfWalkingTrials,1);

HSShankOptical = zeros(noOfWalkingTrials,1);
HSShankFoot = zeros(noOfWalkingTrials,1);
HSFootOptical = zeros(noOfWalkingTrials,1);

TOShankOptical = zeros(noOfWalkingTrials,1);
TOShankFoot = zeros(noOfWalkingTrials,1);
TOFootOptical = zeros(noOfWalkingTrials,1);


kneeFE=[];
% end
for num = 1:noOfWalkingTrials
    %%
    %If maxItem is set to one then it will only run for one walk. The ID of the walk can be set here.;
    if(noOfWalkingTrials==1)
        disp('Running the code for a single walk. Debug Purpose')
        if(isJson==1)
            num=1;
        elseif(experimentId==4) % Sophia
            num=3;
        elseif(experimentId==3) % Letizia
            num=1;
        elseif(experimentId==1) % Gopinath Sir
            num=1;
        elseif(experimentId==5) % Satish
            num=7;
        elseif(experimentId==2) % Sandeep
            num=4;
        elseif(experimentId==6) % Mamtha
            num=2;
        end
    end
    
    
    %%
    %This makes sure that the accessed file is within the limits.
    if(num > size(rightThighDataFiles,1))
        disp('Accessing index more than files present');
        break;
    end
    % ===========================
    [ rightThighFile, rightShankFile,rightAnkleFile,corresPondingBimraFile ] = getWorkingFileNames( folder, rightThighDataFiles,rightShankDataFiles,...
        rightFootDataFiles,num,bimraFolder,bimraFiles,compareWithBimra);
    
    %% Display the filename, for the ease of the user.
    fprintf('\n\nWalk number: %d\n',num);
    fprintf('Running for the IMU file: %s and corresponding BIMRA file: %s \n',rightThighFile,corresPondingBimraFile);
    %% ======================== CALIBRATION ============
    %         runCalibrationAnyWay = 1;
    %     if(~isempty(rightKneeProcessedCalibFile))
    %         rightKneeProcessedCalibFile = strcat(rightKneeProcessedCalibFile,'_walk_',num2str(num),'.mat');
    %     end
    %     if(~isempty(rightFootProcessedCalibFile))
    %         rightFootProcessedCalibFile = strcat(rightFootProcessedCalibFile,'_walk_',num2str(num),'.mat');
    %     end
    [rmse_x_knee, rmse_x_ankle  ]  = handleCalibration(rightKneeRawCalibFiles,rightFootRawCalibFiles,rightThighDataFiles,...
        rightShankDataFiles,rightFootDataFiles, num,...
        useWalkasCalibration,rightKneeProcessedCalibFile,runCalibrationAnyWay, folder,rightFootDataPresent,...
        rightFootProcessedCalibFile,num_of_iterations, threshold,scale_factor,plotCalibrationPlots);
    
    if(~isempty(rightKneeProcessedCalibFile))
        load(char(rightKneeProcessedCalibFile));
    end
    
    if(~isempty(rightFootProcessedCalibFile))
        load(char(rightFootProcessedCalibFile));
    end
    
    %     if((rmse_x_knee > 3) || (rmse_x_ankle > 3))
    %         fprintf('ERROR: CALIBRATION ERROR IS TOO HIGH. ABORTING as this can cause errors further down the code flow. \n');
    %         continue;
    %     end
    
    pathToSave = strcat(folder,num2str(num),'_result/');
    if(exist(pathToSave,'dir')== 0)
        mkdir(pathToSave);
    end
    
    %%
    %Load the sensors data from the file.
    [ rightThighData, rightShankData, rightAnkleData, size_data ] = ...
        getDataFilesAndSize( rightThighFile, rightShankFile, rightAnkleFile,rightFootDataPresent );
    
    %% **************Removal of two markers special case*****************
    
    if(experimentId==4 && num==2) % Sophia
        disp('TRUNCATING DATA TO REMOVE THE MARKERS MANUALLY 160')
        rightThighData =   rightThighData(258:max(size(rightThighData)),:);
        rightShankData =   rightShankData(258:max(size(rightShankData)),:);
        rightAnkleData =   rightAnkleData(258:max(size(rightAnkleData)),:);
        size_data = size_data-258;
    end
    
    %% Load the Thigh data from the Sensors
    [timestamp,acc_s_thigh,gyro_s_thigh,gyro_s_derv_thigh,quarternion_thigh] = loadData(rightThighData,max(size(rightThighData)));
    % Load the Shank data from the Sensors
    [timestamp,acc_s_shank,gyro_s_shank,gyro_s_derv_shank,quarternion_shank] = loadData(rightShankData,max(size(rightShankData)));
    % Load the Foot data from the Sensors
    [timestamp,acc_s_foot,gyro_s_foot,gyro_s_derv_foot,quarternion_foot] = loadData(rightAnkleData,max(size(rightAnkleData)));
    
    fprintf('Size of the data loaded: %d\n',max(max(size(acc_s_foot)),max(size(acc_s_shank))));
    
    %% SAMPLING of Data
    %Sampling rate 1 does nothng to the data.
    sample_rate = 1;
    fprintf('Sampling Rate: %d \n\n',sample_rate);
    sampleTheData();
    
    %% Process BIMRA FILE
    if(~isempty(bimraFiles) && compareWithBimra)
        processBimraFile();
    else
        if(compareWithBimra)
            fprintf('Optical Data is missing for this particular experiment\n');
        else
            fprintf('Not Processing BIMRA files as comparison with is off in init\n');
        end
        compareWithBimra = 0;
        validBimraData=0;
        structMdxData=[];
    end
    
    %% PROCESSING THE PEAK AND THE MARKER INFORMATION IN THE RAW DATA
    if(rightFootDataPresent && (compareWithBimra||peakPresent))
        processPeakData();
    else
        disp('Not Processing Peaks Info')
        startDataPoint = 1;
        rawPeakIdx=1;
        endDataPoint = min(max(size(gyro_s_thigh)),max(size(gyro_s_shank)));
        if(~isempty(gyro_s_foot))
            endDataPoint  =  min(endDataPoint, max(size(gyro_s_foot)));
        end
    end
    
    %% Remove Extra end points
    filterEndPoints();
    endDataPoint = max(size(gyro_s_thigh));
    rawPeakIdx = rawPeakIdx - startDataPoint + 1;
    oldSP = startDataPoint;
    startDataPoint = 1;
    %% THIS IS WERE ALL THE MAGIC HAPPENS
    % All the GAIT Related Angles are calculated here
    imuRightKneeFE = [];
    imuRightAnkleDP = [];
    imuRightKneeAA = [];
    imuRightKneeIE = [];
    imuRightHipFE = [];
    imuRightAnkleIE=[];
    
    RightKneeFE();
    RightKneeAA();
    RightKneeIE();
    
    RightAnkleDP();
    RightAnkleIE();
    
    RightHipFE();
    RightHipAA();
    %     RightHipIE(); %% Need Pelvis Sensor for this.
    
    if(~isempty(imuRightKneeIE))
        imuRightKneeIE =     removeDrift(imuRightKneeIE,0);
        imuRightKneeIE =     removeDrift(imuRightKneeIE,0);
        imuRightKneeIE =     removeDrift(imuRightKneeIE,0);
        imuRightKneeIE =     removeDrift(imuRightKneeIE,0);
        imuRightKneeIE =     removeDrift(imuRightKneeIE,0);
        imuRightKneeIE =     removeDrift(imuRightKneeIE,0);
    end
    
    
    %     return;
    %% FIND MARKER and end point IN Knee FE IMU data
    if(~isempty(imuRightKneeFE) && peakPresent)
        imuMarkerIdx = findIMUMarker( imuRightKneeFE );
        %         imuMarkerIdx = imuMarkerIdx;
        %         endDataPoint = max(size(imuRightKneeFE))-find(flip(imuRightKneeFE)>0,1)+0;
    else
        imuMarkerIdx=1;
    end
    fprintf('IMU peak detected at: %d \n',imuMarkerIdx);
    
    %% =================== Clean up calculated Angles =========
    % ADD ANGLE HERE
    if(~isempty(imuRightKneeFE))
        imuRightKneeFE = imuRightKneeFE(1:endDataPoint);
    end
    if(~isempty(imuRightAnkleDP))
        imuRightAnkleDP = imuRightAnkleDP(1:endDataPoint);
    end
    if(~isempty(imuRightKneeAA))
        imuRightKneeAA = imuRightKneeAA(1:endDataPoint);
    end
    
    
    if(plotImuKneeFE)
        plotImuKneeFECode();
        plotImuAnkleFECode();
        plotImuKneeAACode();
        plotImuKneeIECode();
        plotImuRightHipFE();
    end
    %         return;
    
    %% PLOT START END AND MARKER
    %Plotting the starting and the end point which is calculated
    % automatically.
    % TODO This is not full proof and the user check is
    % required whether the calculated start and end points are correct.
    if(plotstartEndPointsFromKneeFE)
        plotstartEndPointsFromKneeFECode();
    end
    
    %% Calculate HS and TO
    RightLegHSTOShank();
    RightLegHSTOFoot();
    % HSFoot HSShank TOFoot TOShank
    
    %% Quaternions
    if(true)
        showQuaterPlot = 0;
        [avgacrkfe,avgacrkaa,avgacrkie] = ...
            quaternionsAngles( quarternion_thigh,quarternion_shank,showQuaterPlot,KNEE, HSFoot,HSShank,structMdxData );
        if(~isempty(quarternion_foot))
            [avgacrafe,avgacraaa,avgacraie] = ...
                quaternionsAngles( quarternion_shank,quarternion_foot,showQuaterPlot,ANKLE, HSFoot,HSShank,structMdxData );
        end
    end
    %         return;
    %% ================REALGIN THE RESULTS BASED ON THE MARKER IN THE DATA=====================
    % * Realign all the results (Knee FE, Ankle FE, HS and TO) according to the marker detected.
    if(peakPresent)
        reAlignResults();
    else
        disp('No Peak so no realigning of data.');
    end
    
    %% SUMMARY OF HEEL STRIKE AND TOE OFF DETECTED, AMONG SHANK FOOT AND OPTICAL
    if(validBimraData && compareWithBimra)
        isSynced = opticalMarkerIdx;
    else
        HSOptical=[];
        TOOptical=[];
        isSynced=[];
    end
    [ HSShank_Optical, HSShank_Foot, HSFoot_Optical,...
        TOShank_Optical, TOShank_Foot, TOFoot_Optical] = HSandTOSummary( HSFoot,TOFoot,...
        HSShank,TOShank,HSOptical,TOOptical,isSynced, pathToSave);
    
    %% PLOTTING HEEL STRIKE AND TOE OFFS
    if(plotHS)
        plotHSCode();
    end
    if(plotTO)
        plotTOCode();
    end
    
    %% CALCULATE AVERAGE OF RESULTS FOR FINAL COMPARIOSN
    % Calculating the average IMU Step using the Heel Strike data captured using the IMU raw data.
    % TODO DECIDE WHICH TO USE BASED ON DIFFERENCE
    getAverageData();
    
    %% PLOTTING FINAL RMSE PLOTS
    if(1)
        plotFinalRMSECode();
    end
    
    if(~isempty(rmse_rkfe_Offset))
        kneeFERMSEarr(num) = rmse_rkfe_Offset;
    else
        kneeFERMSEarr(num) = -1;
    end
    
    if(~isempty(rmse_radp_Offset))
        ankleDPRMSEarr(num) = rmse_radp_Offset;
    else
        ankleDPRMSEarr(num) = -1;
    end
    
    if(~isempty(rmse_rhpfe_Offset))
        hipFERMSEarr(num) = rmse_rhpfe_Offset;
    else
        hipFERMSEarr(num) = -1;
    end
    
    %%=====================
    
    
    if(~isempty(HSShank_Optical))
        HSShankOptical(num) = HSShank_Optical;
    end
    if(~isempty(HSShank_Foot))
        HSShankFoot(num) = HSShank_Foot;
    end
    if(~isempty(HSFoot_Optical))
        HSFootOptical(num) = HSFoot_Optical;
    end
    
    if(~isempty(TOShank_Optical))
        TOShankOptical(num) = TOShank_Optical;
    end
    if(~isempty(TOShank_Foot))
        TOShankFoot(num) = TOShank_Foot;
    end
    if(~isempty(TOFoot_Optical))
        TOFootOptical(num) = TOFoot_Optical;
    end
    
    
    %% DISTANCE TRAVELLED
    %     distanceTravelled();
    
    %% SAVE THE RESULTS
    %     saveTheRresults();
    
    %% Plot multi
    if(~isempty(avgRightAnkleDP))
        if(isempty( kneeFE))
            kneeFE = avgRightAnkleDP';
        else
            kneeFE = [kneeFE,avgRightAnkleDP'];
        end
    end
end

for i=1:size(kneeFE,2)
    if(kneeFE(1,i) < 0)
        kneeFE(:,i) = kneeFE(:,i) +abs(kneeFE(1,i));
    else
        kneeFE(:,i) = kneeFE(:,i) -abs(kneeFE(1,i));
    end
end

fprintf('\n\n======= SUMMARY OF RESULTS============\n\n');

kneeFERMSEarr(find(kneeFERMSEarr <=0)) = [];
fprintf('Right Knee FE: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(kneeFERMSEarr)), mean(kneeFERMSEarr),std(kneeFERMSEarr));
ankleDPRMSEarr(find(ankleDPRMSEarr <=0)) = [];
fprintf('Right Ankle DP: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(ankleDPRMSEarr)), mean(ankleDPRMSEarr),std(ankleDPRMSEarr));
hipFERMSEarr(find(hipFERMSEarr <=0)) = [];
fprintf('Right Hip FE: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(hipFERMSEarr)), mean(hipFERMSEarr),std(hipFERMSEarr));

fprintf('\n');
HSShankOptical(find(HSShankOptical <=0)) = [];
fprintf('HS Shank Optical: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(HSShankOptical)), mean(HSShankOptical),std(HSShankOptical));
HSShankFoot(find(HSShankFoot <=0)) = [];
fprintf('HS Shank Foot: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(HSShankFoot)), mean(HSShankFoot),std(HSShankFoot));
HSFootOptical(find(HSFootOptical <=0)) = [];
fprintf('HS Foot Optical: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(HSFootOptical)), mean(HSFootOptical),std(HSFootOptical));

TOShankOptical(find(TOShankOptical <=0)) = [];
fprintf('TO Shank Optical: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(TOShankOptical)), mean(TOShankOptical),std(TOShankOptical));
TOShankFoot(find(TOShankFoot <=0)) = [];
fprintf('TO Shank Foot: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(TOShankFoot)), mean(TOShankFoot),std(TOShankFoot));
TOFootOptical(find(TOFootOptical <=0)) = [];
fprintf('TO Foot Optical: Total samples:  %d with a mean and std: %f +- %f \n',...
    max(size(TOFootOptical)), mean(TOFootOptical),std(TOFootOptical));

% save('Results/SophiaHSTO.mat','HSShankOptical','HSShankFoot','HSFootOptical',...
%     'TOShankOptical','TOShankFoot','TOFootOptical')