%% 
% close all;
addpath(genpath('.'));
temp = gyro_s_shank;
temp(1,:)=0;
temp(3,:)=0;
plot(temp(1,:),'linewidth',1,'color','Black');
hold on;
plot(temp(2,:),'linewidth',1,'color','Blue');
hold on;
plot(temp(3,:),'linewidth',1,'color','Red');
legend('x','y','z');
hold off;