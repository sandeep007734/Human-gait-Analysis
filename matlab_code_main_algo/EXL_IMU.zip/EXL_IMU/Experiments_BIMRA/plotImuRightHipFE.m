if(~isempty(imuRightHipFE))
    imuHipFEFigure=figure; grid on;hold on;
    plot( imuRightHipFE,'color','black', 'LineWidth',2);
    title(sprintf('Hip Flexion Extension. File: %s', rightThighDataFiles(num,:)),'FontSize',20);
    hold off;
    if(saveImagesToFile)
        saveFigToFile(pathToSave,'imuHipFEFigure', 'IMUHipFE',imuHipFEFigure);
    end
end
