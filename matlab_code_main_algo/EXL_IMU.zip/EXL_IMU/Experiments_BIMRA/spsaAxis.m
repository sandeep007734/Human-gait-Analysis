%%

j1_valf = j1_valf_x ;
j2_valf = j2_valf_x;
gyro1 = gyro_s_thigh;
gyro2 = gyro_s_shank;

optimize = 1;

% j1_valf=[-0.1777, 0.0698, -0.9816]';
% j2_valf=[0.1983, -0.0116, 0.9801]';

drawVector(j1_valf);
drawnow;
hold on;
minrmse = verifyCalbration(j1_valf,j2_valf,gyro1,gyro2,0);
%%
for i=1:1000
    optimize = xor(optimize,1);
    [j1_valf, j2_valf, rmse] = spsaOptimize(j1_valf,j2_valf,gyro1,gyro2,optimize);
    fprintf('Iter: %d, rmse: %f\n',i,rmse);
    if(rmse < minrmse)
        minrmse = rmse;
        fprintf('j1_valf = [ %f , %f, %f] \n',j1_valf(1),j1_valf(2),j1_valf(3))
        fprintf('j2_valf = [ %f , %f, %f] \n',j2_valf(1),j2_valf(2),j2_valf(3))
        drawVector(j1_valf);
        drawnow;
        hold on;
    end
end

hold off;

%%

