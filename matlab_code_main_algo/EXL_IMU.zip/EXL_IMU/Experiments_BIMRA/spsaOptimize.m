function [j1_valf, j2_valf, rmse] = spsaOptimize(j1_valf,j2_valf,gyro1,gyro2,optimize)
%%
if(optimize)
    theta_def=j1_valf;
else
    theta_def=j2_valf;
end
% theta_def=(def-minval)./range;
% delta=[0.08*ones(1,length(theta_def)-1),0.17]';
% step_size=0.0005;
% checkRange=1;

n=50;		% Iterations
alpha=1;%0.602;
gamma=1/6;%0.101;


p=length(theta_def);
rateOfChange = 0.001;
A=10;
a=rateOfChange*(((A+1)^alpha)/p);
c=0.1;

% thetamax=0.99999;
% thetamin=0.00001;
delta=2*round(rand(p,1))-1;
% delta=delta';
% epsilon=10;

%%
for k=0:n-1
    %%
    %     fprintf('ROUND 1----------------Iteration Number :%d\n',(k+1));
    
    ak=a/(k+1+A)^alpha;
    ck=c/(k+1)^gamma;
    %   currIDx = mod(k,ljCnt)+1;
    
    if(optimize)
        j1_valf=j1_valf+ck*delta;
    else
        j2_valf=j2_valf+ck*delta;
    end
    
    j1_valf = j1_valf/norm(j1_valf);
    j2_valf = j2_valf/norm(j2_valf);
    
    yplus=verifyCalbration(j1_valf,j2_valf,gyro1,gyro2,0);
    
    
    %     fprintf('ROUND 2----------------Iteration Number :%d\n',(k+1));
    
    if(optimize)
        j1_valf=j1_valf-ck*delta;
    else
        j2_valf=j2_valf-ck*delta;
    end
    
    j1_valf = j1_valf/norm(j1_valf);
    j2_valf = j2_valf/norm(j2_valf);
    
    yminus=verifyCalbration(j1_valf,j2_valf,gyro1,gyro2,0);
    
    %% Update
    
    ghat=(yplus-yminus)./(2*ck*delta);
    if(optimize)
        j1_valf=j1_valf-ak*ghat;
    else
        j2_valf=j2_valf-ak*ghat;
    end
    
    j1_valf = j1_valf/norm(j1_valf);
    j2_valf = j2_valf/norm(j2_valf);
    %     theta=theta-ak*ghat;
    
    
    %     #  if(abs(diff(last_perfs)) < epsilon && k > 20)
    %         #	disp('THERE IS NO CHANGE IN THE PERFORMANCE TIME. STOPPING THE SPSA');
    %         #	break;
    %         #   endif
    
end
j1_valf = j1_valf/norm(j1_valf);
j2_valf = j2_valf/norm(j2_valf);

rmse = verifyCalbration(j1_valf,j2_valf,gyro1,gyro2,0);
%Notes:
%If maximum and minimum values on the values of theta can be
%specified, say thetamax and thetamin, then the following two
%lines can be added below the theta update line to impose the
%constraints

%  theta=min(theta,thetamax);
%  theta=max(theta,thetamin);

%The MATLAB feval operation (not used above) is useful in
%yplus and yminus evaluations to allow for easy change of
%loss function.

%Algorithm initialization not shown above (see discussion
%in introduction to MATLAB code).

