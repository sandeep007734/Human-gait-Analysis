function[rmse] =  verifyCalbration(j1_valf,j2_valf,gyro1,gyro2,checkWithModification)
%%
%checkWithModification = 0;
% load(char(rightKneeProcessedCalibFile));
% j1_valf = j1_valf_x;
% j2_valf = j2_valf_x;
% gyro1 = gyro_s_thigh;
% gyro2 = gyro_s_shank;


% j1_valf=[1,0,0]';
% j2_valf=[1,0,0]';

if(checkWithModification)
    j1_valf = flip(j1_valf);
    j2_valf = flip(j2_valf);
    
    if(j1_valf(1)<0)
        j1_valf(1) =  -j1_valf(1);
    end
    if(j1_valf(2)<0)
        j1_valf(2) =  -j1_valf(2);
    end
    if(j1_valf(3)>0)
        j1_valf(3) =  -j1_valf(3);
    end
    
    
    
    if(j2_valf(1)<0)
        j2_valf(1) =  -j2_valf(1);
    end
    if(j2_valf(2)>0)
        j2_valf(2) =  -j2_valf(2);
    end
    if(j2_valf(3)>0)
        j2_valf(3) =  -j2_valf(3);
    end
end


dataSize = max(size(gyro1));
rmse = 0;
for i=1:dataSize
    g1 = gyro1(:,i);
    g2 = gyro2(:,i);
    
    l1 = cross(g1, j1_valf);
    l2 = cross(g2, j2_valf);
    
    % Normalizing over the all the axes.
    norm_l1 = sqrt( (l1(1,1)^2) + (l1(2,1)^2) + (l1(3,1)^2) );
    norm_l2 = sqrt( (l2(1,1)^2) + (l2(2,1)^2) + (l2(3,1)^2) );
    
    % There difference finally gives the e
    e = norm_l1 - norm_l2;
    rmse=rmse+e^2;
    %     disp(e);
end

rmse = rmse/dataSize;
rmse = sqrt(rmse);
% disp(rmse);


end